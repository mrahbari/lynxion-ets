"""
Market Opportunity Watcher for auto-detection system.
Monitors markets continuously and identifies opportunities based on technical conditions.
"""
import os
import threading
import time
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any
from domain.entities.trading_entities import Signal
from domain.value_objects import Symbol
from infrastructure.watchers.watcher_adapters import (
    MarketPulseWatcherAdapter,
    VolatilityWatcherAdapter,
    TrendMTFWatcherAdapter,
    AnomalyMLWatcherAdapter,
    OrderFlowWatcherAdapter
)
from infrastructure.watchers.adapters.cmc_screener import CMCScreener
from shared.logger import EnhancedLogger


class MarketOpportunityWatcher:
    """Watches markets continuously to detect trading opportunities and trigger strategies."""

    def __init__(self, symbols: Optional[List[str]] = None,
                 opportunity_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
                 auto_discover_symbols: bool = False):
        self.auto_discover_symbols = auto_discover_symbols
        self.opportunity_callback = opportunity_callback
        self.logger = EnhancedLogger("MarketOpportunityWatcher")
        self.is_running = False
        self.watchers = {}
        self.last_signals = {}
        self.monitoring_thread = None

        # If no symbols provided and auto-discovery is enabled, discover symbols dynamically
        if auto_discover_symbols and not symbols:
            self.symbols = self._discover_symbols_automatically()
        elif symbols:
            # Convert symbol format if needed (e.g., BTC/USDT -> BTCUSDT)
            converted_symbols = []
            for s in symbols:
                # Convert from BTC/USDT format to BTCUSDT format if slash is present
                if '/' in s:
                    s = s.replace('/', '')
                converted_symbols.append(Symbol(s))
            self.symbols = converted_symbols
        else:
            # Use default symbols from environment variables or fallback to hard-coded defaults
            default_symbols = os.getenv("DEFAULT_WATCHLIST_SYMBOLS", "BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT").split(",")
            self.symbols = [Symbol(s.strip()) for s in default_symbols]

        # Initialize watcher adapters for each symbol
        self._initialize_watchers()

    def _discover_symbols_automatically(self) -> List[Symbol]:
        """Dynamically discover symbols to monitor based on market conditions or other criteria."""
        self.logger.info("🔍 Discovering symbols to monitor automatically...")

        # Try multiple methods to discover symbols, starting with the most comprehensive
        discovered_symbols = self._discover_by_market_cap()

        if not discovered_symbols:
            # Fallback to basic discovery if market cap method fails
            discovered_symbols = self._discover_by_price_activity()

        if not discovered_symbols:
            # Final fallback to default symbols from environment variables
            fallback_symbols_str = os.getenv("FALLBACK_WATCHLIST_SYMBOLS", "BTCUSDT,ETHUSDT,SOLUSDT,XRPUSDT,ADAUSDT,DOGEUSDT,AVAXUSDT,MATICUSDT,DOTUSDT,LINKUSDT")
            fallback_symbols = [s.strip() for s in fallback_symbols_str.split(",")]
            discovered_symbols = fallback_symbols

        self.logger.info(f"✅ Auto-discovered {len(discovered_symbols)} symbols to monitor: {discovered_symbols}")
        return [Symbol(s) for s in discovered_symbols]

    def _discover_by_market_cap(self) -> List[str]:
        """Discover symbols based on market cap from CMC API."""
        try:
            import requests
            import os
            from dotenv import load_dotenv
            load_dotenv()

            cmc_api_key = os.getenv("CMC_API_KEY")
            cmc_listings_url = os.getenv("CMC_LISTINGS_URL", "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest")

            if not cmc_api_key:
                self.logger.warning("CMC_API_KEY not found, skipping market cap discovery")
                return []

            headers = {
                'Accepts': 'application/json',
                'X-CMC_PRO_API_KEY': cmc_api_key,
            }

            params = {
                'start': '1',
                'limit': '50',
                'convert': 'USD'
            }

            try:
                response = requests.get(cmc_listings_url, headers=headers, params=params)
                response.raise_for_status()
                data = response.json()

                if 'data' in data:
                    # Extract symbols from the top coins with filtering
                    excluded_coins_str = os.getenv("CMC_EXCLUDED_COINS", "BTC,ETH,SOL,ADA,DOT,XRP,DOGE,LINK,BNB,AVAX,MATIC,BTCUSDT,ETHUSDT,SOLUSDT,ADAUSDT,DOTUSDT,XRPUSDT,DOGEUSDT,LINKUSDT,BNBUSDT,AVAXUSDT,MATICUSDT")
                    excluded_coins = set(coin.strip().upper() for coin in excluded_coins_str.split(',') if coin.strip())

                    discovered_symbols = []
                    for coin in data['data']:
                        symbol = coin['symbol']
                        # Skip if in excluded list
                        if symbol in excluded_coins:
                            continue

                        # Format as proper trading pair
                        formatted_symbol = f"{symbol}USDT"

                        # Validate the symbol format
                        try:
                            Symbol(formatted_symbol)  # This will validate the format
                            discovered_symbols.append(formatted_symbol)
                            if len(discovered_symbols) >= 10:  # Limit to top 10 for auto-discovery
                                break
                        except ValueError:
                            continue  # Skip invalid symbols
                    return discovered_symbols
                else:
                    self.logger.warning("CMC API returned no data")
                    return []
            except Exception as e:
                self.logger.warning(f"Error fetching from CMC API: {e}")
                return []
        except Exception as e:
            self.logger.warning(f"Error during market cap symbol discovery: {e}")
            return []

    def _discover_by_price_activity(self) -> List[str]:
        """Discover symbols based on price/volume activity from exchange data."""
        try:
            # This would connect to exchange APIs to get recent activity
            # For now, we'll simulate using a placeholder that would connect to exchange data
            # This could use ccxt or other exchange APIs to get recent price/volume spikes
            discovered_symbols = self._get_active_symbols_from_exchange()

            if discovered_symbols:
                return discovered_symbols[:10]  # Limit to top 10

            # If exchange-based discovery fails, return empty list and let fallback happen
            return []
        except Exception as e:
            self.logger.warning(f"Error during activity-based symbol discovery: {e}")
            return []

    def _get_active_symbols_from_exchange(self) -> List[str]:
        """Get active symbols from exchange based on volume and price changes."""
        # In a real implementation, this would connect to exchange APIs
        # to get recent symbols with high volume or price volatility
        try:
            import ccxt
            # Use a public exchange to get top volume symbols
            exchange = ccxt.binance()
            tickers = exchange.fetch_tickers()

            # Filter for USDT pairs and sort by volume
            usdt_pairs = {}
            for symbol, ticker in tickers.items():
                if symbol.endswith('/USDT') and 'quoteVolume' in ticker and ticker['quoteVolume']:
                    usdt_pairs[symbol] = ticker['quoteVolume']

            # Sort by volume and return top symbols
            sorted_symbols = sorted(usdt_pairs.items(), key=lambda x: x[1], reverse=True)
            top_symbols = []
            for pair, volume in sorted_symbols[:15]:  # Get top 15
                # Convert from exchange format to our format
                formatted = pair.replace('/', '').replace('USDT', 'USDT')  # Already in correct format
                if formatted.endswith('USDT'):
                    top_symbols.append(formatted)
                    if len(top_symbols) >= 10:  # Limit to 10
                        break

            return top_symbols
        except Exception as e:
            self.logger.warning(f"Error getting active symbols from exchange: {e}")
            return []

    def _discover_by_trending_searches(self) -> List[str]:
        """Discover symbols based on trending searches or social media activity."""
        # This could integrate with social media APIs or other trending indicators
        # For now, this is a placeholder that would implement such functionality
        try:
            # In a real implementation:
            # - Monitor social media for crypto mentions
            # - Track Google Trends for crypto searches
            # - Monitor crypto news sentiment
            # - Track sudden increases in trading volume across exchanges
            discovered_symbols = []
            return discovered_symbols
        except Exception as e:
            self.logger.warning(f"Error during trending-based symbol discovery: {e}")
            return []

    def _update_symbol_list(self):
        """Dynamically update the list of symbols to monitor based on market conditions."""
        if not self.auto_discover_symbols:
            return  # Only update if auto-discovery is enabled

        # Use activity-based discovery for more timely updates
        current_symbols = [s.value for s in self.symbols]
        new_symbols = self._discover_by_recent_activity()
        new_symbol_values = [s.value for s in new_symbols]

        if current_symbols != new_symbol_values:
            self.logger.info(f"🔄 Symbol list updated: {current_symbols} -> {new_symbol_values}")
            # Here we would need to reinitialize watchers for new symbols
            removed_symbols = set(current_symbols) - set(new_symbol_values)
            added_symbols = set(new_symbol_values) - set(current_symbols)

            # Remove watchers for symbols no longer in the list
            for symbol_str in removed_symbols:
                if symbol_str in self.watchers:
                    # Stop all watchers for this symbol
                    for watcher_name, watcher in self.watchers[symbol_str].items():
                        if hasattr(watcher, 'stop'):
                            watcher.stop()
                    del self.watchers[symbol_str]
                    # Remove from symbols list
                    self.symbols = [s for s in self.symbols if s.value != symbol_str]

                if Symbol(symbol_str) in self.symbols:
                    self.symbols.remove(Symbol(symbol_str))

            # Add watchers for new symbols
            for symbol_str in added_symbols:
                symbol = Symbol(symbol_str)
                if symbol not in self.symbols:  # Avoid duplicates
                    self.symbols.append(symbol)
                    self.watchers[symbol_str] = {
                        'market_pulse': MarketPulseWatcherAdapter(symbol),
                        'volatility': VolatilityWatcherAdapter(symbol),
                        'trend_mtf': TrendMTFWatcherAdapter(symbol),
                        'anomaly_ml': AnomalyMLWatcherAdapter(symbol),
                        'order_flow': OrderFlowWatcherAdapter(symbol),
                        'cmc_watcher': CMCScreener(name=f"CMCWatcher_{symbol.value}", symbol=symbol.value),
                    }
                    # Start new watchers
                    for watcher_name, watcher in self.watchers[symbol_str].items():
                        if hasattr(watcher, 'start'):
                            watcher.start()

            # Update symbol list to match the new discovery
            self.symbols = new_symbols
        else:
            self.logger.debug(f"✅ Symbol list unchanged: {len(current_symbols)} symbols")

    def _discover_by_recent_activity(self) -> List[Symbol]:
        """Discover symbols based on recent market activity like volume surges or price movements."""
        try:
            # This method focuses on recent market activity rather than just market cap
            import ccxt
            import time

            exchange = ccxt.binance()

            # Get recent tickers
            tickers = exchange.fetch_tickers()

            # Filter for active USDT pairs with recent volume and price changes
            active_symbols = []
            for symbol, ticker in tickers.items():
                if not symbol.endswith('/USDT'):
                    continue

                # Check if the ticker has recent data
                if not all(key in ticker for key in ['close', 'high', 'low', 'quoteVolume', 'change', 'changePercentage']):
                    continue

                # Look for symbols with high volume and price movement
                volume = ticker['quoteVolume'] or 0
                price_change_pct = abs(ticker['changePercentage'] or 0)

                # Thresholds for "active" symbols (these values can be tuned)
                min_volume_threshold = 10_000_000  # $10M in volume
                min_change_threshold = 2.0  # 2% price movement

                if volume > min_volume_threshold or price_change_pct > min_change_threshold:
                    formatted_symbol = symbol.replace('/', '')  # Convert BTC/USDT to BTCUSDT
                    active_symbols.append({
                        'symbol': Symbol(formatted_symbol),
                        'volume': volume,
                        'change_pct': price_change_pct,
                        'close': ticker['close']
                    })

            # Sort by a combination of volume and price movement for relevance
            active_symbols.sort(key=lambda x: x['volume'] * (1 + x['change_pct'] / 100), reverse=True)

            # Return top symbols, but ensure we include some stable major coins too
            top_active = [item['symbol'] for item in active_symbols[:7]]  # Top 7 active symbols

            # Add some major coins that might not be trending but are important
            major_coins = [Symbol('BTCUSDT'), Symbol('ETHUSDT')]
            important_symbols = [coin for coin in major_coins if coin not in [item['symbol'] for item in active_symbols]]

            # Combine and limit to 10
            final_symbols = (top_active + important_symbols)[:10]

            self.logger.info(f"📈 Found {len(final_symbols)} active symbols based on recent activity")
            return final_symbols

        except Exception as e:
            self.logger.warning(f"Error during recent activity symbol discovery: {e}")
            # Fallback to basic discovery if activity detection fails
            return self._discover_symbols_automatically()
        
    def _initialize_watchers(self):
        """Initialize watcher adapters for each symbol."""
        for symbol in self.symbols:
            self.watchers[symbol.value] = {
                'market_pulse': MarketPulseWatcherAdapter(symbol),
                'volatility': VolatilityWatcherAdapter(symbol),
                'trend_mtf': TrendMTFWatcherAdapter(symbol),
                'anomaly_ml': AnomalyMLWatcherAdapter(symbol),
                'order_flow': OrderFlowWatcherAdapter(symbol),
                'cmc_watcher': CMCScreener(name=f"CMCWatcher_{symbol.value}", symbol=symbol.value),
            }
            # Start each watcher
            for watcher_name, watcher in self.watchers[symbol.value].items():
                watcher.start()
                
    def start_monitoring(self):
        """Start continuous market monitoring."""
        if self.is_running:
            self.logger.warning("Market opportunity watcher is already running")
            return
            
        self.is_running = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        self.logger.log_auto_detection_status(len(self.symbols), 0, 0)
        
    def stop_monitoring(self):
        """Stop market monitoring."""
        self.is_running = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=2.0)  # Wait up to 2 seconds for thread to finish
            
        # Stop all watchers
        for symbol_watchers in self.watchers.values():
            for watcher in symbol_watchers.values():
                watcher.stop()
                
        self.logger.info("🛑 Market opportunity monitoring stopped")
        
    def _monitoring_loop(self):
        """Main monitoring loop that continuously checks for opportunities."""
        self.logger.info("🔄 Market opportunity monitoring loop started")
        
        while self.is_running:
            try:
                self._check_market_opportunities()
                time.sleep(30)  # Check every 30 seconds
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(30)  # Continue monitoring even if there's an error
                
    def _check_market_opportunities(self):
        """Check each symbol for trading opportunities."""
        for symbol in self.symbols:
            opportunities = self._analyze_symbol(symbol)
            if opportunities:
                self._process_opportunities(symbol, opportunities)
                
    def _analyze_symbol(self, symbol: Symbol) -> Dict[str, Any]:
        """Analyze a symbol using all available watchers."""
        symbol_str = symbol.value
        opportunities = {
            'symbol': symbol_str,
            'timestamp': datetime.now(),
            'signals': {},
            'indicators': {},
            'recommendation': None,
            'confidence': 0.0,
            'strategy_suggestion': None
        }
        
        # Analyze with each watcher
        for watcher_name, watcher in self.watchers[symbol_str].items():
            signal = watcher.analyze(symbol)
            if signal:
                opportunities['signals'][watcher_name] = {
                    'signal_type': signal.signal_type.name,
                    'confidence': float(signal.confidence.value),
                    'score': signal.score,
                    'timestamp': signal.timestamp.isoformat(),
                    'metadata': signal.metadata
                }
                
                # Determine overall recommendation based on signals
                if signal.signal_type.name in ['BUY', 'SELL']:
                    opportunities['recommendation'] = signal.signal_type.name
                    opportunities['confidence'] = max(opportunities['confidence'], float(signal.confidence.value))
                    
                    # Suggest strategy based on signal type and characteristics
                    opportunities['strategy_suggestion'] = self._suggest_strategy_for_signal(signal)
                    
        return opportunities
        
    def _suggest_strategy_for_signal(self, signal: Signal) -> str:
        """Suggest the most appropriate strategy based on signal characteristics."""
        # Determine strategy based on signal source and characteristics
        if 'momentum' in signal.metadata.get('indicator', '').lower():
            return 'momentum_strategy'
        elif signal.metadata.get('volatility') and signal.metadata['volatility'] > 0.5:
            return 'volatility_strategy'
        elif 'trend' in signal.source_engine.lower():
            return 'trend_following'
        elif 'anomaly' in signal.source_engine.lower():
            return 'mean_reversion'
        elif 'order_flow' in signal.source_engine.lower():
            return 'order_flow'
        else:
            return 'balanced_strategy'
            
    def _process_opportunities(self, symbol: Symbol, opportunities: Dict[str, Any]):
        """Process detected opportunities and trigger callback if available."""
        if opportunities['recommendation'] and opportunities['confidence'] > 0.6:  # Only if confidence is high enough
            self.logger.log_opportunity_detected(
                symbol.value,
                opportunities['recommendation'],
                opportunities['confidence'],
                opportunities['strategy_suggestion']
            )

            if self.opportunity_callback:
                try:
                    self.opportunity_callback(opportunities)
                except Exception as e:
                    self.logger.error(f"Error in opportunity callback: {e}")
                    
    def get_status(self) -> Dict[str, Any]:
        """Get current status of the watcher."""
        return {
            'is_running': self.is_running,
            'monitored_symbols': [s.value for s in self.symbols],
            'watchers_count': sum(len(watchers) for watchers in self.watchers.values()),
            'last_signals': {k: list(v.keys()) for k, v in self.last_signals.items()},
            'timestamp': datetime.now().isoformat()
        }