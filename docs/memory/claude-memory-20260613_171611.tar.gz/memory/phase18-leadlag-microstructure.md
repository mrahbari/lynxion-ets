---
name: phase18-leadlag-microstructure
description: "Phase-18 cross-exchange/lead-lag = WEAK_EDGE — real non-OHLCV info found (Binance leads MEXC, dispersion→catch-up IC~0.10) but sub-cost/not deployable; RETIRED slots stay empty"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Phase 18 (2026-06-13, analysis-only, no strategy/param/risk/exec changes, no profitability claim). Tested whether cross-exchange & lead-lag (who moves first) carries predictive info OHLCV lacks. 5 reports docs/reports/phase18/. Commit 34848eb. Data: 1m cross-venue layer data/history/xvenue/{binance_fut,binance_spot,mexc_spot}/ via scripts/fetch_xvenue.py (90d binance, 29d mexc — MEXC only retains ~30d 1m). Harness scripts/phase18_leadlag_analysis.py. Raw docs/reports/phase18/phase18_results.json.

**Classification: WEAK_EDGE (informative but NOT deployable)** — distinct from [[phase17-microstructure-alpha]] flat NO_EDGE.
- T1 cross-asset (BTC→ETH/SOL): k0 corr 0.83-0.88 (contemporaneous, OHLCV-visible), k1 lead ~0.01-0.02 ambiguous → NO new info.
- T2 perp-spot: perp LEADS spot (k1~0.02 vs 0.007), basis mean-reverts (IC −0.01..−0.05), cross-symbol consistent → real non-OHLCV but tiny.
- **T3 cross-exchange: Binance LEADS MEXC (k1~0.03-0.037 vs mexc→binance ~0.006); dispersion→fwd-MEXC catch-up IC ≈ +0.07..+0.11 cross-symbol — STRONGEST, genuinely non-OHLCV signal in whole Ph17-18 program.**

**KEY NUANCE:** real predictive info OHLCV lacks DOES exist (T3 catch-up IC~0.10) — answer to phase question is YES informationally. BUT NOT deployable: dispersion ~0.01-0.025% < spread+0.30% cost; gross expectancy ~0; 0/4 WFO folds; net~−cost all signals/symbols. It's a LATENCY-ARBITRAGE effect inside the cost barrier, needs co-located sub-minute execution this system lacks. Information ≠ deployable edge.

**Replacement DENIED** (T3 fails (a) stable EDGE and (c) cost-adjusted WFO, though passes (b) not-OHLCV + (d) distinct) → RETIRED slots stay EMPTY. **Scope:** bounds minute-scale lead-lag only; sub-minute/tick HFT lead-lag below resolution + outside system reach → NOT claimed (IC~0.10 shows effect is real, not that it's capturable here). READY=0 unchanged.
