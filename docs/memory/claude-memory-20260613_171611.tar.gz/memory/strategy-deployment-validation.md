---
name: strategy-deployment-validation
description: Strategy deployment re-validation — READY=0 SURVIVES correct deployment (design-TF + regime + per-symbol); no edge
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Strategy Deployment Validation (2026-06-13). Tested whether READY=0 survives evaluating each strategy in its INTENDED environment. **It does — emphatically. 0/30 cells meet READY.** This is the EMPIRICAL follow-up to [[strategy-architecture-review]] (which hypothesized misdeployment); the re-eval REJECTS that as exculpatory.

**Phase A (allowed routing fix, NOT param/threshold):** `StrategyConfig.get_strategy_timeframe(name,default)` ignored `name` → returned single global TF. Fixed: added `StrategyConfig.DESIGN_TIMEFRAMES` map + per-strategy routing. Verified each strategy routes to design TF (scalping/sweep_scalper 1m; liquidity/vwap_reversal 5m; breakout/volatility_breakout/mtf_trend 15m; trend_following/mean_reversion/momentum/oi_footprint 1h).

**Phases B-D:** harness `scripts/strategy_deployment_revalidation.py` drives REAL adapters (update_with_market_data→generate_signal) on design-TF data, per-symbol BTC/ETH/SOL independent, regime-conditioned (transparent sma20/50+ATR labeler), metric = net forward-return-per-signal at TF-matched horizon minus 0.30% round-trip cost (existing fee 0.001+slip 0.0005 ×2). Raw: docs/reports/_revalidation_results.json. NOT a full SL/TP backtest — a directional signal-quality-with-cost proxy.

**Result:** 0/30 READY; 2 positive-but-FLIP (overfit noise, volatility_breakout ETH/SOL first-half-only); 19 negative; 9 unjudgeable (n<30 in-regime). Strategies fire only 8-78% of signals in intended regime (confirms misdeployment was real) but in-regime expectancy still negative. No symbol rescues any strategy — BTC/ETH ALSO negative independently (the prior "BTC/ETH-favourable" was un-conditioned/wrong-TF artifact); SOL no longer scapegoat.

**Phase E reclassification:** READY 0; INVALIDATED 5 = trend_following + momentum (directional hypothesis stable-NEGATIVE in-regime, large sample, ~30% win → empirically refuted) + mtf_trend/oi_footprint/sweep_scalper (stubbed core + negative); NEEDS_IMPROVEMENT 5 = breakout/liquidity/volatility_breakout (unstable/small sample) + mean_reversion/vwap_reversal (too selective: 0-7 in-regime signals → unjudgeable); RETIRED 2 = scalping/crypto_breakout. Commit 587125c. 4 deliverables in docs/reports/. Strategy verdict frozen — no logic/params/thresholds changed. Caveat: INVALIDATED = entry signal anti-predictive/edgeless in-regime net of cost per the proxy; salvage would need entry-logic changes (forbidden).
