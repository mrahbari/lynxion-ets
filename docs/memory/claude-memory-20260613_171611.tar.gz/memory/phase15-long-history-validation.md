---
name: phase15-long-history-validation
description: Phase-15 — long history does NOT rehabilitate any strategy; XRP/DOGE/LINK positives collapse; READY=0 stands; 1yr==full-history; RETIRED slots stay empty
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Phase 15 (2026-06-13, analysis-only, NO strategy/threshold/param/risk/exec changes, no profitability claim). Question: is the remaining uncertainty (READY=0, INCONCLUSIVE=4) caused by insufficient history rather than absence of edge? **Answer: NO.** 5 reports docs/reports/phase15/. Commit 550384c.

**Data acquired (longest available, Binance public klines via scripts/fetch_long_history.py):** 1h — XRP 2018-05 (71k bars, ~8y), DOGE 2019-07 (~7y), LINK 2019-01 (~7.4y), BTC/ETH 2017-08 (77k, ~8.8y). 5m (vwap) — XRP/DOGE/LINK 2023-06 (315k, 3y), BTC/ETH 1yr. Harness scripts/phase15_long_history_validation.py (design-TF, per-symbol, regime-conditioned, cost-adj 0.30%, 4-fold WFO). Raw: docs/reports/phase15/phase15_results.json.

**Results:** directional (trend_following/momentum/oi_footprint) NEGATIVE on all 5 symbols (−0.11 to −0.35%/signal), n=4k–11k in-regime (well-powered), win 0.37–0.43, ≤1/4 WFO folds positive → INVALIDATED confirmed. **XRP/DOGE/LINK positives from [[phase12-universe-validation]] COLLAPSE** — they were ~42-day/~1000-bar artifacts, gone already at 1yr scale. Selective (mean_reversion/vwap_reversal) fire 18–75×/60k–315k bars, in-regime n=0–9 (DOGE/LINK vwap=0 over 3y) → INCONCLUSIVE but now KNOWN structural (intrinsic selectivity, NOT coverage — 60–300× more data didn't grow sample).

**KEY (user steer):** user said "1 year is enough, no need to focus on long history" — and evidence AGREES here: 1yr view == full-history view, no sign flips, all negative. So 1yr suffices for THIS verdict. (Contrast [[phase14-funding-information-validation]] where 1yr gave a FALSE POSITIVE — funding was window-sensitive; Phase-15 strategies are not.) Reconcile: use full history when conclusion might be window-sensitive; 1yr fine when 1yr and multi-yr agree.

**Reclass v3:** INVALIDATED +3 confirmed (trend_following/momentum/oi_footprint); INCONCLUSIVE 2 confirmed structural (mean_reversion/vwap_reversal); READY=0 unchanged. Full tally unchanged: READY0/NEEDS1/INCONCLUSIVE4/INVALIDATED5/RETIRED2 — Phase-15 adds certainty, closes "episodic positive"+"needs more data" doubts.

**Replacement (RETIRED slots): DENIED, stay EMPTY.** Conditions 1(archetype gap)/2(uncovered)/5(validated superiority) fail; empty slot (0 PnL/0 risk) strictly dominates every known/unproven-losing candidate (E11 candidates INVALIDATED, OI NO_GO/untestable ~30d, funding only WEAK + cost-unvalidated). oi_footprint never reads OI (vol-spike+momentum proxy); real OI history caps ~30d so long-history OI test impossible regardless.
