---
name: phase19-funding-micro-combined
description: "Phase-19 funding+microstructure combined = WEAK_EDGE; combination reproduces Ph14 funding thread (BTC/ETH bounce, fails SOL, fold-fragile), microstructure does NOT improve it; RETIRED slots stay empty"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Phase 19 (2026-06-13, analysis-only, no strategy/param/risk/exec changes, no profitability claim). Tested whether COMBINING the two weak threads — [[phase14-funding-information-validation]] funding regime + [[phase17-microstructure-alpha]] order flow — yields a deployable edge neither has alone. 4 reports docs/reports/phase19/. Commit 97feae7. Harness scripts/phase19_funding_micro_combined.py (funding 8h events × micro 5m flow, 2218 pts/sym, fwd 4/12/24/72h, cost 0.30%, 4-fold WFO, BTC/ETH/SOL). Raw docs/reports/phase19/phase19_results.json.

**Classification: WEAK_EDGE — combination does NOT beat components.**
- Capitulation combo (extreme-neg funding + sell-flow → long) net@72h: BTC +0.64% (WFO 3/4), ETH +0.40% (2/4) — cost-surviving + theory-aligned (deleverage bounce); but **SOL −1.15%** → fails cross-symbol. NO all-fold-positive cell; BTC/ETH means driven by 1-2 early folds (same back-loaded instability as Ph12/14/15).
- **Microstructure flow does NOT beat funding-only**: vs funding-only@72h, flow helps BTC (+0.12%) but HURTS ETH (−0.41%) and SOL → net subtractive. Positive cells inherited from funding (Ph14), not created by microstructure.
- Exhaustion combo (extreme-pos + buy-flow → short): negative all 3. Flow-only contrarian: negative all 3 (no edge w/o funding). capit+liqexp: BTC-only tiny-n all-positive (n=64), ETH/SOL negative.

**Verdict:** combining two weak signals did NOT create a stronger one — reproduces the WEAK Ph14 funding thread, doesn't strengthen it. WEAK_EDGE (real cost-surviving BTC/ETH signal but inconsistent/SOL-fail/fold-fragile/not-deployable). Replacement DENIED (fails (a) stable edge + (c) WFO/cross-symbol; passes (b) not-OHLCV + (d) distinct) → RETIRED slots stay EMPTY. READY=0 unchanged. Non-OHLCV search (Ph17 flow / Ph18 cross-exchange / Ph19 combined) = no deployable edge anywhere.
