---
name: strategy-replacement-program
description: "Strategy replacement program — 2 candidates built+validated, both INVALIDATED; RETIRED slots stay EMPTY"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Strategy Replacement Program (2026-06-13): authorized to replace the 2 RETIRED slots (scalping, crypto_breakout) with ≤2 new strategies IF evidence justifies. **Outcome: NO replacement justified — RETIRED slots stay EMPTY (rule 12).** Builds on [[strategy-deployment-validation]]. 4 reports: docs/reports/{strategy_candidate_study,new_strategy_implementation,new_strategy_validation,final_strategy_program_verdict}.md.

**Candidate study:** 5 studied, rejected 3 (cross-sectional RS = architecture-incompatible since adapters are per-symbol; Bollinger reversion = duplicate of mean_reversion/vwap; time-of-day = curve-fit risk). Selected 2 distinct a-priori OHLCV-only: **STR** (Short-Term Statistical Reversal, 15m, ranging — fade z-score>2 of 1-bar return) + **DCB** (Donchian Channel Breakout, 1h, breakout — break 20-bar high/low + ATR-expansion gate).

**Implemented (NOT deployed):** `infrastructure/strategies/adapters/short_term_reversal_strategy_adapter.py` (ShortTermReversalStrategyAdapter), `donchian_breakout_strategy_adapter.py` (DonchianBreakoutStrategyAdapter). BaseStrategyAdapter subclasses, a-priori params (no tuning). Added DESIGN_TIMEFRAMES routing (str=15m, donchian=1h). NOT registered in StrategyManager/load_sample_strategies (failed validation). Tests tests/unit/test_replacement_candidates.py 4/4 (mechanism only).

**Validation** (scripts/validate_replacement_candidates.py; design-TF+per-symbol+regime+cross-period+4-fold WFO, net 0.30% cost): both stable-NEGATIVE in-regime on ALL symbols, well-powered (322-546 in-regime sigs). STR: -0.33/-0.30/-0.44% (BTC/ETH/SOL), WFO 0/4 all. DCB: -0.25/-0.14/-0.38%, WFO 0-1/4. Both **INVALIDATED**. Same edgeless-net-of-cost pattern as the whole existing suite → confirms OHLCV-only directional strategies don't clear the ~0.30% cost hurdle on these assets under no-tuning. Commit 3b0660b.

Suite state unchanged: READY 0 / NEEDS_IMPROVEMENT 5 / INVALIDATED 5 / RETIRED 2 (empty). A real new edge would likely need data the architecture lacks (order-book/funding/OI/cross-asset) or relaxed no-tuning — both out of scope, neither assumed to succeed.
