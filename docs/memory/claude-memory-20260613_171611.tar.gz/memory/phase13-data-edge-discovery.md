---
name: phase13-data-edge-discovery
description: Phase-13 data audit — production is OHLCV-only; funding/trade-flow/OI are top future data leads (no profitability claimed)
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Phase 13 (2026-06-13, analysis-only, NO code changes): audited whether the no-edge result is caused by the OHLCV-only data architecture. 5 reports: docs/reports/{data_architecture_audit,unused_data_inventory,market_data_gap_analysis,data_edge_opportunity_matrix,phase13_recommendation}.md. Commit 8d83fa5.

**Architecture:** TWO disjoint paths — (1) watcher→fusion→strategy SELECTION/intent; (2) strategy DECISION = OHLCV-only data_buffer (open/high/low/close/volume/timestamp). Non-OHLCV data NEVER reaches buy/sell. Active ingestion fetches OHLCV spot klines only (ccxt+REST binance/bingx/mexc/phemex; higher TFs resampled from 1m; stored data/history/raw/<tf>/).

**Unused data (key finding):** archived Phase-6 derivatives stack (docs/archive/phase6/ingestion/, un-wired from container) left on disk: `data/history/raw/funding/` = **24 symbols × ~3 years × 8h** (REAL, deep, NEVER used by any strategy); `data/history/raw/open_interest/` = 3 symbols × ~30d hourly (binance caps OI hist ~30d). oi_footprint tested OI → DIRECTIONAL_NO_GO (data/results_storage/edge_oi_footprint_30d.json). CMC screener = real external fetch but fusion-only. funding_rate/orderflow_ws/liquidity/tick watchers INERT (feed _format_market_data_for_watcher only supplies OHLCV+bid/ask, never their inputs). Order-book depth + trade-tape code exists (downloader/rest_client/websocket_router) but persists NOTHING.

**Gap analysis (uniqueness-vs-OHLCV is the key metric):** genuinely-new = funding/OI/liquidations/orderbook/trade-flow/stablecoin/exchange-flows; OHLCV-DERIVED (not new) = breadth/cross-asset. Binding constraint = backtest feasibility: funding (High, on disk), trade-flow (High via binance aggTrades backfill), OI (Low, ~30d cap) backtestable; liquidations (no REST backfill, allForceOrders removed) + order-book (snapshot/stream only) + on-chain flows (not integrated, approval-gated) = backtest-BLOCKED.

**Recommendation ≤3 (future investigation only, NO profitability claim):** 1) Funding Rates (3yr on disk, unused, untested, low effort = re-wire archived stack) — clearest cheap/deep/new/untested lever; 2) Trade Flow/CVD (backfillable, new directional info); 3) Open Interest (high uniqueness but ~30d cap + already failed — only with deeper paid history + fresh regime-conditioned test). Honest conclusion: OHLCV-only IS a real info-limiter, but NOT demonstrated to be the primary cause of READY=0 — and adding data ≠ edge (OI already proved that). Strategy verdict unchanged (READY=0).
