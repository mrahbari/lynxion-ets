---
name: phase17-microstructure-alpha
description: Phase-17 microstructure (order flow/CVD/liquidity/funding×flow) = NO_EDGE; new non-OHLCV data not even incrementally informative for direction; L2+liquidations backtest-blocked
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Phase 17 (2026-06-13, analysis-only, no strategy/param/risk/exec changes, no profitability claim). Pivoted OFF OHLCV to microstructure. Question: does microstructure carry predictive info OHLCV does NOT? **Answer: largely NO.** 5 reports docs/reports/phase17/. Commit a61573c.

**KEY ENABLER:** Binance FUTURES klines carry non-OHLCV order-flow fields that plain OHLCV CSVs discard — field[8]=num_trades, field[9]=taker_buy_base (aggressor buy vol). → derive CVD/aggressor-imbalance + trade-structure liquidity proxy, historical+free+funding-aligned. Data layer scripts/fetch_microstructure.py → data/history/micro/<tf>/; 2yr 5m BTC/ETH/SOL (~213k bars). Harness scripts/phase17_microstructure_analysis.py. Raw docs/reports/phase17/phase17_results.json.

**Results (a-priori features K=6, horizon=6bars/30m, cost 0.30% RT, 4-fold WFO):**
- Flow imbalance (flow_k): forward-return IC ≈ −0.03 cross-symbol (net taker-buy → mild reversal) BUT **58% correlated with OHLCV recent_ret AND weaker than OHLCV IC (−0.045)** → NO incremental directional info; just a noisy proxy for short-term reversal already in OHLCV.
- Liquidity (intensity_z = num_trades zscore): forward-VOLATILITY IC ≈ +0.13 cross-symbol (real, cleanest microstructure signal) BUT weaker than OHLCV realized-vol IC (+0.21) & redundant & non-directional (can't trade |return|).
- Funding×flow: only trivial ±0.01%; one cross-symbol-consistent cell extreme-neg-funding+sell-flow→+0.011% (capitulation bounce, echoes [[phase14-funding-information-validation]]) but ~37× below cost.
- Cost-adjusted directional: EVERY family (flow-follow/contrarian/liquidity-gated) ≈ −0.30% = gross edge ~0, win 0.12–0.26, **0/4 WFO folds, all-negative, all 3 symbols**. Liquidity gating doesn't rescue it.

**Verdict NO_EDGE** (not READY, not WEAK_EDGE). Replacement DENIED (fails: stable edge / not-reducible-to-OHLCV / WFO+cross-symbol) → RETIRED slots stay EMPTY. **Scope caveat:** L2 order-book depth + historical liquidations are backtest-BLOCKED (no integrated history) → Phase-17 can't rule them out, only reports obtainable microstructure (flow+trade-liquidity+funding×flow) shows no incremental edge. Consistent w/ [[phase16-program-closure]]: same no-edge wall, now in a new data paradigm. READY=0 unchanged.
