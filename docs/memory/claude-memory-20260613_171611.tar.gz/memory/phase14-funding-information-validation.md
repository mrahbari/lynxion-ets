---
name: phase14-funding-information-validation
description: "Phase-14 — funding-rate data tested for predictive info; mostly NO_INFORMATION, one WEAK thread (extreme-neg funding bounce BTC/ETH). Supersedes \"funding untested\""
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Phase 14 (2026-06-13, analysis-only, NO strategy/signals/profitability). Tested whether the archived funding data (the #1 "untested lever" from [[phase13-data-edge-discovery]]) contains predictive info beyond OHLCV. 5 reports in docs/reports/phase14/. Commit 8ecb4c7.

**Dataset:** 24 syms × ~3yr × 8h, clean (0 gaps, 0 NaNs); TON=4h cadence+1 gap, FLOW/ZEC have ≤−1.6%/−2.0% tail outliers — all flagged. Funding strongly positive-biased (perp contango, 65–85% positive) and highly persistent (lag-1 autocorr 0.6–0.83) — but persistence predicts *funding*, not *price*.

**Predictive (BTC/ETH/SOL only — others lack 3yr aligned intraday price).** Back-filled 1h price to funding start via `scripts/extend_price_to_funding.py` (BinanceClient paginated). Harness `scripts/funding_information_analysis.py`.

**Result:** funding↔fwd-return correlation ≈0 over 3yr (|IC|≤0.032). Only ONE effect survives: **extreme-negative funding (≤p10) → positive 24h/72h fwd return, sign-consistent across all 4 WFO folds on BTC AND ETH** (oversold/short-crowding bounce, +0.25–0.68% excess) — but FAILS on SOL and magnitude-unstable → classed WEAK_INFORMATION. extreme_pos contrarian hypothesis = NO_INFORMATION (no neg-return signal at all over 3yr). 9/60 effects fold-consistent (≈chance). Classes: 1 WEAK, 2 UNSTABLE, 4 NO_INFORMATION; zero PROMISING.

**KEY METHOD LESSON:** the 1-YEAR price window gave a FALSE POSITIVE — BTC contrarian IC=−0.140@72h — which COLLAPSED to −0.027 over the full 3yr. Window choice nearly produced a fake edge; always use full history. **Why:** short windows alias regime drift as signal. **How to apply:** for any future funding/derivatives info test, run full 3yr + WFO before believing any conditional effect.

**Verdict:** funding NOT worthy as standalone alpha; extreme-neg-funding-on-BTC/ETH is at most a narrow contrarian context lead requiring (a) wider universe, (b) overlapping-window significance testing, (c) cost survival — none done here. Confirms Phase-13's "new data ≠ edge" (like OI/oi_footprint NO_GO). READY=0 unaffected.
