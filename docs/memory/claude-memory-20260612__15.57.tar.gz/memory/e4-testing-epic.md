---
name: e4-testing-epic
description: "User's 'E4' = testing & validation epic (the deferred E6.T5 unit-pyramid work), NOT the INDEX's closed Domain-Model-Unification E4"
metadata: 
  node_type: memory
  type: project
  originSessionId: 069a6e94-95a9-4405-abec-75defb63cf03
---

The user is driving an epic they call **"E4 = testing & validation layer"** — this is NOT the INDEX's E4 (Domain Model Unification, already CLOSED at ingestion). It is effectively the deferred **E6.T5 unit-pyramid backfill**, now scoped to safe non-trading modules. Don't conflate the two.

**Scope rule:** test deterministic, stateless/in-memory, non-trading modules with port fakes + zero I/O. **EXCLUDE the E5-B group** (strategy_manager, fusion_service, probabilistic_position_sizer, strategy_provider, adaptive_retuning, realistic_backtester) — those get golden-gated coverage during E5-B, not here. See [[e6-enforcement-progress]] for the open "agreed coverage threshold" question (still unresolved; defer the global `--cov-fail-under` to the canonical Windows venv).

**Tiered candidate list (all verified import-clean in the WSL venv):**
- Tier1 (pure): `shared/config_helper.py`, `domain/value_objects/money.py`
- Tier2 (deterministic in-memory): `infrastructure/services/symbol_validator.py`, `infrastructure/shared/pending_orders_tracker.py`, `infrastructure/messaging/message_bus_adapter.py`, `infrastructure/monitoring/logging_adapter.py`
- Tier3 (numpy math, seed-determinism): `infrastructure/statistical_validation/{confidence_calibrator,statistical_authority_engine}.py`, `infrastructure/market_regime/regime_detector.py`, `infrastructure/portfolio/portfolio_adapters.py`

**Progress (all local-only, tests/ gitignored):**
- **E4.T1 ✅** — `test_config_helper.py` (config_helper **100%**) + `test_money_value_object.py` (money.py **94%**).
- **E4.T2 ✅** — `test_symbol_validator.py` (symbol_validator **92%**) + `test_pending_orders_tracker.py` (pending_orders_tracker **99%**). Added reusable `approved_symbols_config` factory fixture to `tests/conftest.py`. PendingOrdersTracker is a class-level-state singleton → autouse fixture calls `clear_all_pending_orders()` around each test.
- **E4.T3 ✅** — Tier-3 numpy/stats math: `test_portfolio_adapters.py` (91%), `test_confidence_calibrator.py` (96%, sklearn isotonic deterministic), `test_regime_detector.py` (85%, structural contract on full path), `test_statistical_authority_engine.py` (91%; parametrized over all 6 ComponentType `calculate_*` methods). 36 tests.
- **Full E4 unit suite: 104 tests passing** (T1+T2+T3 + the pre-existing consolidated_adapters). All deterministic, no I/O beyond tmp files.
- Observed-not-fixed (out of scope): `statistical_authority_engine.py` uses deprecated `datetime.utcnow()` (warnings only). Note: per-method `sample_size` semantics differ (e.g. strategy counts only decisions with `return_pct`).
- **E4.T4 ✅** — `test_message_bus_adapter.py` (100%, deeper than conformance: ordering/snapshot/propagation), `test_logging_adapter.py` (89%, fake-logger injection), `test_tracking_adapter.py` (87%, 3-fake delegation across all 13 methods). 11 tests.
- **E4.T5 ✅** — `test_position_sizing_engine_adapter.py` (delegation via swapped `_service` fake) + `test_data_integrity_checker.py` (64%; pandas missing-candle-ratio core). 9 tests.
- **E4.T6 ✅** — `test_randomness_exposure_firewall.py` (48%; watcher+engine branches deep + all-6-method smoke). 10 tests.

**EPIC STATUS: safe-module unit pyramid COMPLETE across the full candidate list — 15 modules, ~129 new tests (full tests/unit = 141 passed).** Coverage: most 85–100%; lower = randomness_exposure_firewall 48% (4 of 6 check_* methods only smoke-tested — main remaining gap) and data_integrity_checker 64% (generate_integrity_report + 1h/1m branches untested).

**Pre-existing failures (NOT mine, NOT regressions):** `tests/unit/test_settings_loader.py` + `test_settings_schema_mirror.py` (10 tests) fail on dep-drift (pydantic v2 vs pinned) — fixed only in the canonical Windows venv.

**If continuing:** deepen randomness_firewall (fusion/strategy/broker/broker_close), cover remaining stat-validation services (historical_data_tracker, decision_defensibility_validator), then the global `--cov-fail-under` ratchet in the canonical venv. Still excludes E5-B group.

**Coverage tooling gotcha:** pytest-cov `--cov=<dotted.module>` raises ImportError in this venv (path/startup timing); use the **directory form** `--cov=shared --cov=domain` instead. Full-suite coverage still needs the canonical Windows venv (dep drift). See [[repo-uses-windows-venv]].
