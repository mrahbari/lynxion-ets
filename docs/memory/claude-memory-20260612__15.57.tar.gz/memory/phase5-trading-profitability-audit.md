---
name: phase5-trading-profitability-audit
description: "Phase-5 trading-profitability audit verdict, key findings, and the epics/tasks produced"
metadata: 
  node_type: memory
  type: project
  originSessionId: 64f0cb60-7248-4ae1-afe6-c6169da88e19
---

Phase-5 trading-profitability/live-readiness audit completed 2026-06-10 (read-only). Deliverables in `tasks/phase5-evaluate/`: `phase5-trading-profitability-audit-report.md` (main, 15 areas + scorecard + top-20 risks + roadmap), `phase5-epics-overview.md`, and 5 epic files `phase5-E-P5.1..5.5`.

**Verdict: Research Ready** (not Paper/Live ready). Scorecard mean ≈1.9/5.

Non-obvious findings worth keeping (each verified against source):
- **Two divergent live paths.** `--auto-detect` (RunAutoDetectionUseCase → AutoDetectionOrchestrator) wires the full watcher→engine→fusion→strategy event pipeline via `architecture_orchestrator.start()`→`setup_signal_processing`. The DEFAULT production path (RunLiveTradingUseCase → ProductionTradingOrchestrator) BYPASSES watchers/engine/fusion and runs one named strategy via `LiveExecutionEngine.execute_strategy`. See `interface/cli/trading_system_production.py:71-85`.
- Engine→fusion is NOT dead code (an earlier exploration claim was wrong); it runs in the auto-detect path.
- Only OHLCV data exists — no order book/tick/funding/OI. All "microstructure" (sweep/absorption/OI-footprint) are proxies or stubs. `mtf_trend.compute_trend()` returns mock 0. `shared/utils.py:16-24 calculate_position_size()` deprecated, returns 0.0.
- Strongest areas (score 3): risk mgmt, backtest reliability, observability. Weakest (score 1): microstructure, MTF, entry precision, trade lifecycle, live execution.
- Hard live blockers: no true OCO, no orphan/restart recovery, no broker failover, shutdown doesn't close positions, no live trade-lifecycle loop.

Roadmap tiers: E-P5.1 live-safety → E-P5.2 edge measurement → E-P5.3 lifecycle/entry → E-P5.4 MTF/portfolio → E-P5.5 microstructure/adaptation. Relates to [[e8-cleanup-progress]] (prior phase).

**Execution-plan decision (`phase5-execution-plan.md`, source-verified):** OVERRODE overview's "E-P5.1 first" → run **E-P5.2 offline core FIRST** as a cheap edge gate (prove edge net of realistic costs before paying for execution safety; E-P5.2 offline has no hard dep on E-P5.1). Order: E-P5.2 → [EDGE GATE go/no-go] → E-P5.1 → E-P5.3 → E-P5.4 → E-P5.5. E-P5.2 internal order corrected: consolidate backtester → kill mock-data fallback → realistic fills → edge ledger → attribution → gate.
**Verified-worse-than-audited bug:** `bingx_adapter.py:533-546` returns `success:True` even when SL/TP conditional legs fail → live position can exist with NO stop. SL/TP are full-qty, not reduceOnly. No failover (`multi_broker_service.py` returns None on any failure). Shutdown (`auto_detection_orchestrator.py:600-664`) never closes positions. No reconciliation loop exists anywhere.
