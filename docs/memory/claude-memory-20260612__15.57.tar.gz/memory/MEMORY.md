# Memory index
- [Timeframe re-architecture mandate](timeframe-rearchitecture-mandate.md) — ACTIVE: Phase-6 closed; 1m canonical data resample→5m/15m/30m/1h (MTF no-lookahead); validate 12 strats × BTC/ETH/SOL × {15m,30m,1h}; 5 reports; state-to-resume + infra-already-built
- [Rehab readiness criteria](rehab-readiness-criteria.md) — Rehab Mode: A/B fix, C don't; READY needs profitability-support (correct+losing=NEEDS_IMPROVEMENT); final 4 deliverables
- [Direction-B strategy remediation](direction-b-strategy-remediation.md) — rewired backtest through real generate_signal (single authoritative path); fidelity fixes committed; trend_following unblocked; mean_reversion/vwap=intrinsic-selectivity, scalping=cost-NON_VIABLE-on-1m; remaining genuine defect=breakout windowing latch; strategies measurable but lose (no edge per Phase-5)

- [E-P5.2 progress](phase5-ep5.2-progress.md) — edge-measurement epic; T3 mock-seal DONE (41bc605, shared/mock_data_guard.py); next T4 realistic fills (will rebaseline golden); env limits
- [Deferred architecture backlog](deferred-architecture-backlog.md) — canonical ledger at tasks/deferred-backlog.md (gitignored/local); 30 allowlist edges + E6/E8 items DB-1..DB-14 w/ revisit phases; NOT executed in Phase-5 unless profitability-blocking

- [E3 consolidation progress](e3-consolidation-progress.md) — Phase-4 Stage-3 status, what's done/next, T7/T8 caveats
- [E4.T1 entity merge](e4-t1-entity-merge.md) — canonical entity model done; 108 importers migrated off shims; pre-existing domain.events bug; full E4 history (T1-T4, closure)
- [E5 decomposition plan](e5-decomposition-plan.md) — E4 closed at ingestion; E5 interface-decomposition plan, verified targets, T7 obsolete, broker-split-before-wiring rule
- [E6 enforcement progress](e6-enforcement-progress.md) — T1/T2/T3 done, T4 blocked (frozen-code mypy), T5 partial; WSL linux-venv + dep-drift gotcha
- [E8 cleanup progress](e8-cleanup-progress.md) — T1a/T1b/T2 committed (deleted 10 dead modules, folded+removed utils/); remaining E8 + allowlist-retirement notes
- [E4 testing epic](e4-testing-epic.md) — user's "E4"=testing/validation (the deferred E6.T5 unit-pyramid), NOT closed domain-unification E4; T1 done, tiered candidate list, excludes E5-B
- [tests/ is gitignored](repo-tests-gitignored.md) — tests run locally but aren't committed; don't force-add
- [Windows venv](repo-uses-windows-venv.md) — run pytest via `.venv/Scripts/python.exe`; logger rotation flake note
- [Lint graph coverage gap](lint-graph-coverage-gap.md) — RESOLVED 617a70e (added 39 __init__.py; 412 modules; allowlist 9→92); root cause = missing __init__.py
- [Canonical env + validation unblocked](canonical-env-validation-unblocked.md) — Option 1 env adopted (py3.12/pydantic-v2); settings regression fixed fa3fd26; suite runs in WSL (310/3 baseline); E1.T4 unblocked+started
- [E1.T4/T5 progress](e1-t4-t5-progress.md) — T4(a-f)+T5 use_cases done (33 edges retired, deps→1090); 12 remaining all singleton-blocked/exempt → owned by E8
- [E8 allowlist retirement](e8-allowlist-retirement.md) — allowlist 56→45 (dead-code ×3 + event_system relocation); remaining 45 all blocked; exact path to allowlist=0
- [E5-B progress](e5b-progress.md) — T1 done (45→42, composition-root injection of risk+sizing engines); ranked remaining E5-B plan; slow-/mnt/c validation gotcha
- [Allowlist 40 fork wall](allowlist-40-fork-wall.md) — 8 commits 42→30 (incl. entry-point rewiring: data-sync + WFO CLIs via container); reusable rewiring pattern; 30 left each hit a stop condition (WFO=hyperopt-absent, E4 frozen, ERM deferred, strategy_config 140-site, forks/forbidden); earlier note: 6 commits 42→36 (adaptive_retuning, cross_validation_engine, backtester, fusion, trade_tracker+forensic_logger); "promote-to-default-if-runtime==schema" pattern; HARD tier left (strategy_config 140 call sites, wfo_config/symbol_manager need entry-point rewiring); decision list
- [Phase6 edge discovery progress](phase6-edge-discovery-progress.md) — harness+hexagonal ingestion built; research/edge_discovery/ (function-named, not phase); 6 hypothesis batches ~all null; FIRST breadth lead = revert_highvol_3 (high-vol-regime reversion, IC +0.064, 17/24 sig, PROVISIONAL); next = OOS + cost check; funding_revert BTC@4d falsified on wider universe
- [Phase5 CLOSURE verdict](phase5-closure-verdict.md) — Phase-5 formally closed 2026-06-11: NOT READY — BLOCKERS REMAIN; POST matrix 108/108 done + FROZEN; 0/108 cells profitable, 0 GO; bug-fix recovery is artifact (−76% loss) not profit; SUPERSEDES remediation-mandate (user pivoted to strict closure deliverable)
- [Phase5 remediation mandate](phase5-remediation-mandate.md) — Phase-5 is Measure→Diagnose→FIX→Re-evaluate (not audit-only); for every validated blocker: quantify→upside→remediation epic→ROI-rank→IMPLEMENT (unless approval-gated)→re-eval→measure delta; loop until blockers exhausted
- [Phase5 profitability audit](phase5-trading-profitability-audit.md) — verdict Research Ready (~1.9/5); two divergent live paths; OHLCV-only/no microstructure; live-safety blockers; E-P5.1..5.5 epics in tasks/phase5-evaluate/
