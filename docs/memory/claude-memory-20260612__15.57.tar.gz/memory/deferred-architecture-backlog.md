---
name: deferred-architecture-backlog
description: "Canonical deferred-work ledger (tasks/deferred-backlog.md) — all 30 allowlist edges + E6/E8 deferred items, with revisit phases"
metadata: 
  node_type: memory
  type: project
  originSessionId: fc9cdcc4-5d1d-422b-a04e-ac66c5c6912d
---

Phase-5 launch deliverable (2026-06-10): the consolidated **Deferred Architecture Backlog** now lives at `tasks/deferred-backlog.md` (NOTE: `tasks/` is fully gitignored like [[repo-tests-gitignored]] — 0 files tracked — so it's local-only/persisted-on-disk, not committed; that's how every Phase-5 artifact exists). This doc **supersedes the scattered E5/E8 notes** as the single ledger; update it (not just memory) when items resolve.

Grounded against live `pyproject.toml [tool.importlinter]`: **30 allowlist edges** (27 layered + 3 R1), lint green. Items DB-1..DB-14, each with description/reason/blocker/business+trading impact/revisit phase:

- **DB-1 strategy_config** (1 edge, ~140 call sites) — biggest cascade; runtime≠defaults so not promotable; injection-style is itself a fork. Post-Phase-5, own epic, risk-parity baseline.
- **DB-2 WFO orchestrator self-wiring** (4) — injection just shuffles edge up; can't validate (no hyperopt, no WFO golden). Tie to Phase-5 WFO-validation.
- **DB-3 E4 ingestion/DTO** (9) — deliberate E4 freeze; deferred indefinitely until owner unfreezes.
- **DB-4 ERM→trade_tracker/regime_detector/forensic_logger** (3) — live trade paths; RegimeType has 3 competing enum defs (consolidation fork); forensic via private method. Post-Phase-5.
- **DB-5 advanced_execution_service inheritance** (1) — cross-layer inheritance fork. Revisit w/ E-P5.1.
- **DB-6 R1 CLI fat-wiring** (3) — blocked by E5.T6 constraint; cheap once lifted. Not Phase-5 blocking.
- **DB-7 walk_forward↔sliding_window_splitter** (1) — relocate splitter to domain; bundle w/ DB-2.
- **DB-8 optimization_service→hyperopt_space** (1) — only R6 violation; port DI + rewire ~4 consumers (recheck liveness).
- **DB-9 other E1 singletons** (3: centralized_symbol_manager, wfo_config, event_system) — de-singletonize forks; symbol-universe + signal-path are trading-critical; wfo_config blocked behind entry-point rewiring + maybe dead.
- **DB-10 E5 datasync/reporting** (2: watcher_services→market_data_feed [no port + likely-dead orchestrator], prod_orchestrator→live_dashboard).
- **DB-11 config-layer exempt** (2: symbol_config/sync_settings→loaders) — NOT debt, never retire.
- **DB-12 mypy-strict** (E6.T4) — blocked by E4 freeze (domain 115 / app 2249 strict errors).
- **DB-13 coverage gate** (E6.T5) — undefined threshold + needs canonical Windows venv; fold into Phase-5 testing epic [[e4-testing-epic]].
- **DB-14 pre-existing bugs** — multi_strategy_optimizer imports nonexistent shared.auto_drop; 3 baseline test failures (non-regressions). bingx SL/TP success-on-failure bug is NOT here — it's escalated into E-P5.1.

Reusable patterns captured in the doc: promote-to-default-if-runtime==schema, annotation/default-only edge swap, entry-point rewiring, lint-imports-as-cheap-retirement-check. Supersedes/relates to [[allowlist-40-fork-wall]] [[e8-allowlist-retirement]] [[e6-enforcement-progress]] [[e5b-progress]]. Per user direction, these are NOT executed during Phase-5 unless they directly block profitability/live-readiness; priority is now [[phase5-trading-profitability-audit]].
