---
name: direction-b-strategy-remediation
description: Direction-B (Strategy Fidelity & Remediation) — rewired backtest through real generate_signal; status + remaining fixes
metadata: 
  node_type: memory
  type: project
  originSessionId: fc9cdcc4-5d1d-422b-a04e-ac66c5c6912d
---

**Direction B (approved 2026-06-12): make the 12 EXISTING production strategies
correct, measurable, viable.** Edge discovery CLOSED (archived to docs/archive/phase6/).
NO new strategies, NO hypothesis redesign, NO tuning/curve-fitting; fix implementation
fidelity only. Reports: docs/reports/strategy-fidelity-audit.md, final-strategy-roadmap.md.

**CORE REWIRE DONE (committed on e3-consolidation-behind-ports):** the backtest now
evaluates each strategy through its REAL `generate_signal()` (single authoritative
path), fed bar-by-bar via `update_with_market_data`. Was previously: rich adapter
generate_signal NEVER ran (no-op data feed) — a simplified raw-signal proxy was
evaluated instead. Fidelity fixes committed: base update_with_market_data feed;
calculate_ema/rsi/atr in BaseStrategyAdapter; Signal() API (drop strategy_name,
source_engine→source_layer — was crashing→0 signals); volatility_breakout real ATR
generate_signal + registration; removed duplicate feed overrides; correspondence-guard
None-counting bug; regime_context default→strategy_name (stop redundant should_execute
veto); breakout range-excludes-current + breakout_threshold 2%→0.1%; trend_following
trend_extreme_threshold 0.99→0.999.

**Tooling:** research/profitability_diagnostics/signal_frequency_diagnostic.py (fast
generate_signal BUY/SELL/HOLD counter — the 'measure/diagnose' step). eval_matrix at
research/profitability_diagnostics/eval_matrix.py. PRE baseline = frozen Phase-5
eval_matrix_POST_FROZEN_20260611.json; POST partial (29 cells BTC) =
eval_matrix_POST_PARTIAL_BTC.json.

**HFR COMPLETE (2026-06-12).** Hypothesis-Fidelity Review done on the whole starvation
cluster (doc: docs/reports/hypothesis-fidelity-review.md). Post-HFR BTC signal freq
(20k 1m bars): sweep_scalper 11624, mtf_trend 9414, oi_footprint 2701, trend_following
534, volatility_breakout 356, liquidity 87(SELL-only), vwap_reversal 67, momentum 25,
breakout/crypto_breakout 13, mean_reversion 10, **scalping 0**. → **11/12 FIRE**;
readiness READY 0 / NEEDS_IMPROVEMENT 11 / NON_VIABLE 1 / INSUFFICIENT_DATA 0.
- vwap_reversal 0→67: committed af3e10e. 3 defects — C: _assess_trend_exhaustion slope
  was $/bar vs fractional thr (normalize); C: _should_reset_session used bar_index%24
  (24-min "session") → anchor to REAL ts (UTC day); B: deviation_threshold 2% unreachable
  (max dev ~1.15%) → wired σ-band from existing dead std_mult=2.0. Residual type-C
  (documented, unfixed): _check_rejection_pattern requires close on opposite VWAP side
  from entry → rejection path dead, only failure_swings confirms.
- scalping stays 0 but RECLASSIFIED: committed cdc0992. B FIXED: adequate_volume used
  absolute min_volume_threshold=100 vs BTC ~6/bar → failed all bars BEFORE hypothesis
  gate; made relative (recent vs baseline, ratio 0.5) → micro-conditions 0→13640/19986.
  Residual is type-D: tick-cost gate (move≥0.2% = round-trip cost) IS the hypothesis;
  1m moves median 0.027% ≪ 0.2% → correctly refuses → NON_VIABLE-on-1m, JUSTIFIED (not
  modifiable). Earlier mean_reversion/vwap "intrinsic selectivity = INSUFFICIENT_DATA"
  call was WRONG (user-corrected): they were C-bugs + B-constants, now fire.

**NOW RUNNING (background nohup):** fresh full eval_matrix.py BTC/ETH/SOL×90/180/365
(108 cells, ~78s/cell @90d, slower @365d; OOM-prone; resumable, skips done cells).
Out=data/results_storage/eval_matrix.json, log=eval_matrix_run.log. Pre-HFR BTC partial
archived eval_matrix_PARTIAL_PRE_HFR_BTC_20260612.json. When done: fill roadmap PnL
table + PRE/POST delta. Breakout windowing catch-22 already fixed earlier (latched-range
state machine wired; 0→13).

**Key truth (from Phase-5 [[phase5-closure-verdict]] + Direction-B):** even correctly
wired+fired, these strategies LOSE (no gross entry edge on OHLCV). Remediation makes
them measurable/correct, not profitable. Don't manufacture signals by weakening
hypotheses. Matrix at 1m×365d is slow (~5min/cell, O(buffer) per-bar) + OOM-prone;
resumable.
