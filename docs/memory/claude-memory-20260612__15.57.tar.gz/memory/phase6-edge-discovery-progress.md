---
name: phase6-edge-discovery-progress
description: Phase-6 edge discovery — harness/ingestion built; 6 hypothesis batches; first breadth lead = high-vol-regime reversion (PROVISIONAL)
metadata: 
  node_type: memory
  type: project
  originSessionId: fc9cdcc4-5d1d-422b-a04e-ac66c5c6912d
---

Phase 6 = move from "no edge" (Phase-5 verdict, see [[phase5-closure-verdict]]) to
an edge-discovery system. Blueprint + protocol + data-decision in
`docs/reports/phase6/`. Status reports `phase6-step{3..8}-*.md`.

**Architecture (after the function-rename, NOT phase-labelled):**
- `research/edge_discovery/measurement/` — predictive-power HARNESS (forward
  labels, IC w/ Newey-West HAC, decile, event-study, purged+embargoed CV, BH-FDR,
  promote/archive gate, EdgeLedger). Tests: `tests/unit/test_edge_discovery_measurement.py`.
- `research/edge_discovery/features/` — feature_library, hypotheses, run_discovery
  (batch1), run_batch2 (extreme), run_batch3_funding, run_batch4_funding_wide,
  run_batch5_cross_sectional, run_batch6_regime, price_cache (8h ccxt), universe_loader.
- **Ingestion is HEXAGONAL** (not research): domain/ports/derivatives_data.py +
  infrastructure/data_sync/derivatives_{downloader,store}_adapter.py +
  application/use_cases/ingest_derivatives.py + interface/cli/derivatives_ingest.py
  + runner_derivatives_ingest.py + container wiring. Tests: test_derivatives_ingest.py.
- Data (untracked): `data/history/raw/funding/` (24 syms × 3yr), `data/research_cache/8h/`
  (24 syms × 3yr 8h OHLCV). OI capped 30d by Binance.

**Discovery results (6 batches, ~28 hypotheses, default-REJECT, cumulative BH-FDR):**
- Batches 1–5 (momentum, reversion, RSI/range, volume, funding-carry,
  cross-sectional, lead-lag): **0 promoted**, ICs ≈ 0.
- Batch-2 extreme-reversion lead: REJECTED (non-monotone).
- Batch-3 funding_revert BTC@4d (IC +0.183) looked strong but was idiosyncratic →
  **FALSIFIED** on wider 24-sym/3yr re-test (batch 4, mean IC −0.003). Good example
  of the conservative gate preventing a false promotion.
- **Batch-6 FIRST BREADTH LEAD: `revert_highvol_3`** = short-horizon reversion
  gated to HIGH-VOL regime. Mean in-regime IC **+0.064** @8h, **17/24 symbols
  same-sign-and-significant** (all prior were 1–3/24). **PROVISIONAL** (strict gate
  promoted only 2/24 under the 1047-test family). Economically sensible (overreaction
  reversion in panic). Pre-registered §3B class (low snoop risk).

**revert_highvol_3 RESOLVED (step 9, run_oos_costgate.py):** OOS-confirmed +
cost-gated. OOS (last 30%): mean IC +0.080(IS)→+0.043(OOS) — persists directionally
but weak, breadth drops to 4/24 sig. COST GATE (decisive): gross **+1.3 bps/trade**,
breakeven **1.3 bps**, net@10bps **−8.7 bps** → **REJECTED at cost gate**. A real but
tiny signal-level effect, NOT tradeable at 8h turnover (gross « ~10bps cost cliff).
Confirms Phase-5: signal edge ≠ tradeable edge.

**CONCLUSION — free-data edge discovery EXHAUSTED:** ~28 hypotheses, 6 classes
(momentum/reversion/RSI/range/volume/funding-carry/cross-sectional/lead-lag/regime),
**0 tradeable edge** after costs. Strongest finding (high-vol reversion) is real at
signal level but dies on costs. Remaining avenues all need NEW inputs: paid
microstructure data (L2/trade tape — APPROVAL-GATED), lower-turnover/longer-hold
formulations, or fundamentally different hypothesis classes. No tuning/snooping;
honest verdicts. All work local on branch e3-consolidation-behind-ports; nothing pushed.

**Step-10 lower-turnover rescue FAILED** (no robust net-positive config; conviction-only
"+500bps" was a 40-trade outlier mirage, caught by net>0 & n>=500 & t>=2 gate).
**PHASE-6 SYNTHESIS written:** `docs/reports/phase6/PHASE6-SYNTHESIS.md` (~32 hyps / 8
classes, ZERO tradeable edge on free OHLCV+funding). Decision pending: (a) authorize
paid microstructure data (one untested edge class) or (b) accept research-stage
conclusion. Last commit 8f45775 (+ synthesis commit).

**PHASE 6.5 EDGE COVERAGE AUDIT (audit-only, no code):**
`docs/reports/phase6/PHASE6.5-EDGE-COVERAGE-AUDIT.md`. Verdict: free-data discovery
NOT exhausted — only a SUBSET tested. 8-class taxonomy (C1 technical, C2 cross-
sectional, C3 carry/term-structure, C4 microstructure, C5 regime, C6 event, C7
fundamental/alt, C8 ML-combination). Coverage ≈ 6 rejected / 3 inconclusive / 13
untested (8 FREE). Untested FREE classes: spot-perp basis, pairs/cointegration
stat-arb, OHLCV microstructure proxies, ML signal-combination, factor portfolios,
HMM/change-point regimes, calendar/seasonality, lead-lag networks. **Paid data =
PREMATURE.** Key insight: paid L2/tape microstructure is the HIGHEST-turnover /
MOST cost-sensitive class → worst fit for the ~10bps cost cliff that's been the
binding constraint. Roadmap A (free, do first, low-turnover/cost-tolerant): basis →
cointegration → ML-combination → factor portfolios → regimes → seasonality. Roadmap
B (paid, later): options-implied/VRP FIRST (cost-tolerant), L2/tape LAST.

**ROADMAP A EXECUTED (all 6 classes, shared eval_protocol.full_eval: HAC IC + CV +
OOS + cost gate; runner run_roadmapA.py; ledger docs/reports/phase6/PHASE6.6-roadmapA-edge-ledger.md;
spot 8h cache data/research_cache/8h_spot/):** basis REJECT, cointegration REJECT
(net +11.5bps but t=1.4), factors REJECT, ML-logit-combination REJECT, regime REJECT,
seasonality REJECT. **0 promoted — Roadmap A free-data EXHAUSTED, no confirmed
tradeable edge.** BUT one coherent NEAR-MISS: **regime_revert_highvol_downtrend**
(3-day-hold reversion in high-vol+downtrend) — IC@3d +0.081, OOS +0.078 (holds),
**net@10bps +38.0bps, t=+2.5, n=3125** — first signal to BEAT the cost cliff (low
turnover + regime/direction conditioned). REJECTED correctly on multiple-testing
(t=2.5 not family-significant) + breadth (9/24=37.5%, not majority). = single
highest-priority candidate for a dedicated pre-registered follow-up (wider universe +
longer history + true OOS). Paid data STILL premature. New code: eval_protocol.py,
run_roadmapA.py, fetch_spot_8h.py in research/edge_discovery/features/.
