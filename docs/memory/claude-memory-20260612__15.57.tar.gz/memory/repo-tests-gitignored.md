---
name: repo-tests-gitignored
description: "The tests/ directory is gitignored in this repo; tests run locally but aren't committed"
metadata: 
  node_type: memory
  type: reference
  originSessionId: fbf89117-bcaa-47ab-9653-f256abfc173a
---

`tests/` is gitignored in this repo (`git check-ignore tests/<f>` confirms; `git status --ignored` shows `!! tests/`). Characterization/unit/e2e tests exist and run locally, but are NOT version-controlled. Do not force-add them when committing — respect the repo convention. Prior epic commits ("E1 is completed", "E2 is completed") followed the same pattern. `E3.T3-Completed.zip` at repo root is a binary artifact, not source — exclude from commits.

Also locally excluded via `.git/info/exclude` (not `.gitignore`): `/.github/` and `/tasks/`. So `.github/workflows/ci.yml` is NOT tracked — edits to the CI workflow are local-only and won't be committed. When a task names ci.yml as an involved file, edit it on disk but expect it to stay untracked. (E6.T1 added a `lint-imports` step there; pyproject.toml carries the actual import-linter contracts and IS tracked.)
