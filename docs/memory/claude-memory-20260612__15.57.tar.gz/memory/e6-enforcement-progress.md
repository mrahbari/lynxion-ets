---
name: e6-enforcement-progress
description: "E6 (Rule Enforcement) phase status — T1/T2/T3 done, T4 blocked by frozen code, T5 partial; plus WSL venv/dep-drift gotcha"
metadata: 
  node_type: memory
  type: project
  originSessionId: 069a6e94-95a9-4405-abec-75defb63cf03
---

E6 (Rule Enforcement & Test Pyramid), Phase-4 Stage-4, executed via the phaseX loop:

- **E6.T1 ✅** import-linter contracts (R1-R6) in `pyproject.toml` `[tool.importlinter]` (tracked) + `lint-imports` step in `.github/workflows/ci.yml` (local-only). 8 pre-existing-debt edges allowlisted via documented `ignore_imports` (E1 settings shim, E5-B risk wiring, E8 shared cleanup). See [[e5-decomposition-plan]].
- **E6.T2 ✅** `tests/contract/test_layering.py` — local mirror of the CI gate; reads contracts from pyproject (single source of truth), passes clean / fails injected.
- **E6.T3 ✅** `tests/contract/test_adapter_port_conformance.py` — parametrized suite over every (port, impl) pair (13 port classes, 10 canonical adapters; `PortfolioManagementPort` has 2 impls). Checks MRO declaration + signature compat + no residual `__abstractmethods__`. 14 pass.
- **E6.T4 ❌ BLOCKED** mypy-strict can't reach exit-0: `domain/` 115 strict errors (35 even non-strict), `application/` 2249 strict errors. Both are FROZEN (E4 closure), so making it clean = out-of-scope refactor. Reported, not done. Needs a separate non-frozen typing task first.
- **E6.T5 ◑ PARTIAL** `tests/unit/test_consolidated_adapters_unit.py` (5 port-fake unit tests, risk+engine delegation adapters) delivered. Full coverage gate blocked: threshold is "agreed" but undefined anywhere, and full suite can't be measured here (see venv note).

**WSL venv gotcha:** `.venv` here is a bare *linux* venv (`pyvenv.cfg` home=/usr/bin); `.venv/Scripts/python.exe` is a stale Windows artifact that errors from WSL ("No Python at '/usr/bin\\python.exe'"), and there's no cmd.exe interop. The linux venv had NO project deps. Installed via `.venv/bin/python -m pip install --only-binary=:all:` (venv-local, gitignored): numpy/pandas/scipy/sklearn/pydantic/aiohttp/redis/matplotlib/ccxt + import-linter/mypy/pytest/pytest-cov. **Versions drifted from pins** (pandas 3.0.3 vs pinned 1.5.3, pydantic v2) → 10 settings/pydantic unit tests fail spuriously here; `TA-Lib` (C lib) uninstallable. Accurate full-suite/coverage runs need the canonical Windows venv with pinned deps. Run single dep-light tests with `.venv/bin/python -m pytest <file>`. Relates to [[repo-tests-gitignored]].
