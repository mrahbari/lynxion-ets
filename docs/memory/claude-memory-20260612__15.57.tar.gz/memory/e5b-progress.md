---
name: e5b-progress
description: E5-B dependency-inversion progress — T1 done (3 edges via DI); ranked remaining plan; validation gotcha
metadata: 
  node_type: memory
  type: project
  originSessionId: 0e6b0c19-65f7-49fd-8663-176dd6d86a22
---

E5-B = retiring infra↔application layering violations via dependency inversion. Authorized for autonomous execution (user 2026-06-09/10), stop only for: (1) genuine architectural fork w/ multiple valid designs, (2) trading-behavior change without golden/parity proof, (3) validation can't go green, (4) unresolved blocker. Branch `e3-consolidation-behind-ports`.

**E5-B edges are NOT god-module-size problems — they are dependency-DIRECTION problems.** Most adapters ALREADY implement a domain port (risk_ports/execution_ports/portfolio_ports/optimization_ports) but reach UP to the canonical application engine. Fix = composition-root injection (bootstrap builds the engine, injects it; adapter stops self-constructing). This is the codebase's established pattern (`bootstrap/container.py:_build_tracking` injects results_tracker). bootstrap legitimately imports all layers.

**E5-B.T1 DONE — commit `2bbc93d` (allowlist 45→42, lint 2 kept/0 broken, deps→1070):** 3 R3 edges retired by composition-root injection, all behavior-preserving (parity baseline = risk+position-sizing characterization 69 passed):
- `risk_engine_adapter`: ConsolidatedRiskEngineAdapter dropped its lazy `EnterpriseRiskManager()` self-construct fallback → requires injection; `_build_risk_engine` builds+injects EnterpriseRiskManager() (same defaults).
- `position_sizing_engine_adapter`: same; `_build_position_sizing_engine` injects PositionSizingService().
- `strategy_adapters`: EnterpriseRiskManager import was ONLY a type annotation on an unused vestigial param (`_calculate_comprehensive_risk_parameters`'s risk_manager, never passed) → dropped annotation+import.
Test construction sites updated to inject (gitignored/local: test_risk_decisions:39, test_position_sizing 4 sites, test_position_sizing_engine_adapter unit).

**RANKED remaining E5-B work (42 allowlist edges total; ~12 are E5-B):**
- **NEXT — reverse risk edges (3, app→infra), MED risk**: `enterprise_risk_manager -> {infrastructure.tracking.trade_tracker(L10, eager singleton), market_regime.regime_detector(L11 singleton + RegimeType enum), logging.forensic_logger(L214 lazy)}`. Used on LIVE trade paths (register_trade L238/close_trade L324, _generate_trade_id L215). Needs ports + inject into EnterpriseRiskManager.__init__ + container wiring; RegimeType enum placement is a sub-decision. Parity gate = test_risk_decisions. Retiring trade_tracker/forensic_logger here ALSO unblocks the E1 singleton edges for those modules.
- **backtest/wfo edges (7)**: walk_forward(application) → infra backtest/csv_loader/hyperopt + `infrastructure.backtest.adapters.walk_forward -> application.walk_forward.sliding_window_splitter` (bidirectional). Need port inversion. Audit wfo_orchestrator/cross_validation_engine/main_wfo. Parity gate = golden backtest.
- **shared.optimization_service -> hyperopt_space (1)**: ParameterSpace.__init__ imports concrete HyperoptParameterSpace (implements domain.ports.optimization_ports.IParameterSpace). DI/port-inject + rewire 4 app consumers.
- **BLOCKED (escalate, stop-#1) — `advanced_execution_service -> application.services.execution_services`**: INHERITANCE across layers (RiskAwareExecutionService extends application ExecutionService). Multiple valid designs (move base down / subclass up / recompose) → needs explicit design decision, NOT mechanical.

**VALIDATION GOTCHA (critical for pacing):** repo is on `/mnt/c` (slow WSL mount). `.venv/bin/python -m pytest` over it is SLOW — full suite ~40min, risk+position parity gates ~21min. lint-imports is fast (~30s). Strategy: batch behavior-preserving edits, validate ONCE with lint-imports (primary gate: confirms edge retired + no new violation; removing an allowlist entry while the import still exists makes lint FAIL = strong check) + run parity gate once. Commands time out at the foreground limit → they auto-background; watch PID exit via Monitor, `| tail` withholds output until process exits.

**FULL-SUITE BASELINE = 310 passed / 3 pre-existing failures** (stale utils.data_integrity_checker import + 2 utcnow() microsecond flakes — NOT regressions). E5-B.T1 not yet full-suite-validated (only lint + the 69-passed parity baseline pre-change); changes are behavior-preserving by construction. Recommend a full-suite run post-restart to confirm 310/3.

See [[e8-allowlist-retirement]] [[e1-t4-t5-progress]] [[canonical-env-validation-unblocked]] [[repo-tests-gitignored]].
