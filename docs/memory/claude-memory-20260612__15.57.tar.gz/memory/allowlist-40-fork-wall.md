---
name: allowlist-40-fork-wall
description: Allowlist at 40 edges; 2 clean inversions done this session; remaining 40 each hit a design-fork/freeze/forbidden stop — the consolidated decision list
metadata: 
  node_type: memory
  type: project
  originSessionId: d3c69df0-fadb-4f38-881d-39de5c20d658
---

Autonomous-execution session 2026-06-10 on `e3-consolidation-behind-ports`. Baseline
was 42 allowlist edges (39 layered + 3 R1), lint green (409 files, 1070 deps, 2 kept/0 broken).
Note: user commented out CLAUDE.md RULE 4 (stop-after-task) → continuous execution endorsed.

**FINAL (same session): 42 → 30 via 8 commits.** After the 6 below, user authorized
entry-point rewiring; landed:
- `65bbc66` — data-sync entry points: moved run_with_resources/main out of
  application/data_sync/{sync_loop,watcher_retune}.py into NEW thin CLIs
  interface/cli/{sync_loop_cli,watcher_retune_cli}.py that build the container via
  bootstrap.lifecycle.lifespan and resolve sync_manager/data_downloader/watcher_retune
  (already registered). App modules keep only SyncLoop/WatcherRetuneUseCase classes, import
  no infra. retention 180 matches. 4 edges.
- `e9f2cfc` — WFO: relocated application/walk_forward/main_wfo.py → interface/cli/wfo_cli.py
  (resolves wfo_orchestrator_factory; WFVisualizer legal in interface; dead hyperopt import
  dropped). 2 edges. NOTE: the rejected-then-reran commit initially captured only the file
  deletion; had to `git add wfo_cli.py pyproject.toml && commit --amend` to make it consistent.

**ENTRY-POINT REWIRING PATTERN (reusable): a __main__ script in application/ that self-wires
infra exists only because R4 bars application→bootstrap. Fix = move run_with_resources/main into
interface/cli/<x>_cli.py, `with lifespan() as container: container.resolve("<key>")`. The container
already has factories for most things (grep `self.register(` in bootstrap/container.py). Keep
reusable classes in application/.**

**30 EDGES LEFT — each hits a stop condition (verified):**
- wfo_orchestrator self-wiring (4: realistic_backtester/walk_forward-adapter/csv_history_loader/
  hyperopt_space): CANNOT validate — hyperopt not installed in this venv + no WFO golden test
  (stop #5). Injection would be behavior-by-construction but unverifiable here.
- E4-deferred ingestion/DTO (9): FROZEN, user declined unfreeze.
- ERM → trade_tracker/regime_detector/forensic_logger (3): user-deferred.
- advanced_execution_service inheritance (1): design fork. R1 CLI fat-wiring (3): forbidden (E5.T6).
- config-layer EXEMPT (2: symbol_config/sync_settings → loaders): never retire.
- strategy_config → loaders (1): 140 call sites, trading-critical thresholds (risk_per_trade/
  confidence); validatable only via slow risk-parity; injection-vs-service-locator is itself a fork.
- centralized_symbol_manager (1: configured wfo.coins), wfo_config (1: 24 configured values;
  consumer auto_sync_service is now UNIMPORTED/likely-dead → E8 deletion candidate), event_system
  singleton (1), watcher_services→market_data_feed (1, unconstructed orchestrator + no port),
  prod_orchestrator→live_dashboard (1, infra→interface inversion), walk_forward-adapter→
  sliding_window_splitter (1, needs splitter relocation to domain), optimization_service→
  hyperopt_space (1, broken/dead consumers).

**ORIGINAL 6 commits (42 → 36):**
Newer commits after the 2 below:
- `74fbf81` — comprehensive_portfolio_backtester: use_mock_data lazy load_settings → ctor param
  (default False; container factory injects settings.infrastructure.use_mock_data). Golden 2 passed.
- `b208654` — fusion_service: correlation_consensus/confidence_weight lazy load → ctor params
  (defaults 0.6/0.4; those keys ABSENT from schema so fallback always won → bit-identical).
- `f302460` — trade_tracker + forensic_logger: forensic_logging_enabled (True at runtime+schema
  default; gates LOGGING only, no PnL impact) → ctor param / drop lazy fallback. 2 edges.

**KEY PATTERN that worked (the only safe one): a singleton reading a settings value whose
RUNTIME value == SCHEMA DEFAULT (or the key is absent so the hardcoded fallback always won) can be
promoted to a defaulted ctor param — bit-identical, no cascade. Verify runtime==default with a
`load_settings()` probe BEFORE doing it.**

**HARD TIER — 3 E1 singletons left, NOT promotable (runtime values DIFFER from hardcoded defaults
→ promoting would change trading behavior). Need true injection + big cascade + risk-parity:**
- `strategy_config` (infrastructure/strategies): @staticmethod accessors reading strategy/risk
  settings; runtime DIFFERS from defaults (high_confidence_threshold 0.7 vs default 0.95;
  stop_loss transforms to 3.0 vs 1.5). **140 call sites across 12 files** (all strategy adapters +
  watcher_config + symbol_config) → converting to injected settings is a sprawling trading-critical
  cascade. Also "how to inject a static-method config accessor" is itself a design choice
  (ctor-cascade vs service-locator-init vs entry-point rewiring).
- `wfo_config` (WFOConfigManager, 24 wfo.* values): module global `config` consumed by
  auto_sync_service which is NOT container-built → cascade goes up to sync_loop (__main__ script) →
  needs the entry-point rewiring (decision 2) FIRST.
- `centralized_symbol_manager`: reads wfo.coins (genuinely configured, ≠ hardcoded list); global
  `symbol_manager` consumed by unified_symbol_config. Symbol-universe = behavior-critical.

**2 clean behavior-preserving inversions committed (42 → 40):**
- `915adc7` — `adaptive_retuning -> results_tracker` retired. It already INJECTED the
  ResultsTracker; only the concrete type ANNOTATION created the edge. Swapped to the existing
  `domain.ports.tracking_ports.ResultsTrackingPort` (a Protocol it structurally satisfies).
  Annotation-only; zero runtime change.
- `00db385` — `cross_validation_engine -> realistic_backtester` retired. Only coupling was the
  `backtester_class: type = RealisticBacktester` DEFAULT arg. Made it required keyword-only
  (`*, backtester_class: Callable[[], BacktestEnginePort]`, domain port) and injected
  `RealisticBacktester` at the sole caller `wfo_orchestrator` (which already imports it → no new
  edge). Golden-gated: `tests/e2e/test_backtest_golden.py` 2 passed (13s, byte-stable). Note the
  golden test is FAST (~13s), not 40min — earlier "slow" estimates were the full suite/risk-parity.

**THE WALL — remaining 40 edges each hit stop-condition #1 (design fork repo doesn't resolve),
a deliberate freeze, or a forbidden constraint. Verified this session:**
- **E1 settings singletons (7; 2 config-layer exempt)**: module-level EAGER `x=Foo()` reading
  `load_settings()` in __init__ (trade_tracker, forensic_logger, fusion_service, strategy_config,
  wfo_config, centralized_symbol_manager, comprehensive_portfolio_backtester). Retiring = drop the
  global + constructor-inject settings + rewire consumers. Can't default w/o behavior change
  (e.g. trade_tracker.forensic_logging_enabled). De-singletonization = design fork.
- **ERM → trade_tracker / forensic_logger / regime_detector (3)**: HIGH-risk live-trade paths
  (register_trade/close_trade). Each has a sub-fork: forensic_logger is called via a PRIVATE method
  `_generate_trade_id` (port would expose a private); `regime_detector` INSTANCE is unused — only
  `RegimeType` enum is used, but RegimeType has 3 competing defs (`_regime_classifiers` TRENDING_UP/
  MOMENTUM... vs `advanced_regime_classifier` BULLISH/BEARISH vs `advanced_risk_management`) →
  consolidation/relocation fork; trade_tracker also needs de-singletonization.
- **wfo_orchestrator (3: realistic_backtester/walk_forward-adapter/hyperopt_space) + main_wfo→
  hyperopt_space (1)**: WFOOrchestrator self-wires concrete infra (lines 34/59/186) but is built by
  main_wfo (a __main__ script) AND run_walkforward (use_case) AND bootstrap. Injecting its deps just
  SHUFFLES the edges to the application-layer callers (doesn't retire) unless ALL construction is
  rerouted through the container = wiring redesign fork.
- **backtest.adapters.walk_forward → sliding_window_splitter (1)**: infra→app; needs SlidingWindowSplitter
  relocated down to domain (relocation decision).
- **E5 data-sync (5)**: sync_loop/watcher_retune are __main__ scripts wiring infra in their
  `if __name__=='__main__'` block (relocate-entry-point fork); watcher_services→market_data_feed
  self-constructs MarketDataFeed() in EnhancedWatcherOrchestrationService — but NO market-data port
  exists AND that orchestrator is never constructed anywhere (only a type annotation) → speculative.
- **E5-A reporting (2)**: main_wfo→walkforward_report (script self-constructs WFVisualizer),
  prod_orchestrator→live_dashboard (self-constructs adapter). Relocation/logic-change forks.
- **event_system → loaders (1)**: SignalProcessor singleton de-singletonization fork.
- **E4-deferred ingestion/DTO (9)**: deliberate E4 closure FREEZE — repo says don't touch.
- **R1 CLI fat-wiring (3)**: forbidden under E5.T6 constraints (route-via-bootstrap-factory = wiring change).
- **advanced_execution_service → execution_services (1)**: cross-layer INHERITANCE — genuine fork.

**Common pattern blocking ~half**: the source is a `__main__` SCRIPT or self-wiring orchestrator in
`application/`. Injecting deps moves the import UP to another application-layer caller (no net retire).
The real fix is "where do WFO/data-sync/reporting entry-points + their composition live" — a wiring
redesign that is itself the fork. The 2 retired this session were the only edges where the object was
ALREADY injected and only an annotation/default created the edge.

Path to <40 requires user decisions on: (a) de-singletonize the 7 E1 globals (yes/no + accept consumer
cascade), (b) unfreeze E4, (c) reroute WFO/data-sync/reporting entry-point construction through bootstrap,
(d) consolidate/relocate RegimeType, (e) the advanced_execution_service inheritance design, (f) lift the
E5.T6 CLI-wiring constraint. See [[e5b-progress]] [[e8-allowlist-retirement]] [[e1-t4-t5-progress]].
</content>
</invoke>
