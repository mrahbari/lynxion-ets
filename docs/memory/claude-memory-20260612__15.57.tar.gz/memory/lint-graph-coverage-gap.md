---
name: lint-graph-coverage-gap
description: "lint-imports coverage gap (142/373) — RESOLVED 617a70e by adding 39 __init__.py; cause was missing __init__.py, NOT venv"
metadata: 
  node_type: memory
  type: project
  originSessionId: b5341d6a-86d3-4717-abf0-effbdc70fde1
---

**RESOLVED 2026-06-08 in commit `617a70e`** (branch e3-consolidation-behind-ports). Added 39 empty `__init__.py` to the no-init subpackages → grimp now analyzes **412 modules / 1126 deps** (was 142/289). Allowlist re-baselined **9 → 92** entries (89 layered + 3 R1) in `pyproject.toml`, bucketed by owning task (E1.T4/T5 settings, E5-B risk/backtest/optimization, E4-deferred ingestion/DTO, E5 data-sync, E5-A reporting inversion, E8 shared, E5.T6 CLI fat-wiring) so each block retires wholesale. All 92 provably match real imports (import-linter `unmatched_ignore_imports_alerting` defaults to ERROR; lint exits 0 = no dead entries). Validated: compileall clean, grimp sees all trading-critical targets, injected-R5-violation self-test fails-then-recovers. **The gate is now trustworthy across the full tree.** NOTE: surfaced that 3 CLIs DO import infrastructure at function level (`comprehensive_portfolio_backtest`/`comprehensive_validation`/`extended_horizon_validation` → comprehensive_portfolio_backtester.load_sample_strategies) — refutes the old [[e5-decomposition-plan]] "all CLIs import 0 infrastructure" claim (that check was top-of-file only). Original investigation retained below.

---

**ROOT CAUSE of the "142 files analyzed" lint-imports gap (audited 2026-06-08).** Prior notes ([[e8-cleanup-progress]], [[e6-enforcement-progress]]) implied the canonical Windows venv was needed for "full-graph lint." That attribution is WRONG. The real cause: grimp's module finder only descends into **regular packages** (dirs with `__init__.py`). ~37 subpackages under `application/` and `infrastructure/` have NO `__init__.py` (they work at runtime as PEP-420 namespace packages), so grimp skips them entirely.

Result: `lint-imports` analyzes **142 of 373** source `.py` files (~38%). Fully covered: domain (30/37), interface (19/19), bootstrap (10/10), shared (18/18). Barely covered: application (25/106), infrastructure (40/183). In-graph infra subpackages = only brokers/messaging/optimization/strategies (the ones with `__init__.py`). **Invisible:** infrastructure/{backtest, orchestrators, watchers, risk, data, execution, fusion, monitoring, market_regime, statistical_validation, ...} and application/{use_cases, services, walk_forward, data_sync, configs/schemas, ...} — i.e. the entire trading-critical + E5-B surface. R1-R6 contracts are UNVERIFIED for that 62%.

Same blind spot exists in **CI** (`.github/workflows/ci.yml` runs `lint-imports` against the same tree). The 2-contracts-KEPT green status is misleading.

FIX (recommended next task, low-risk): add empty `__init__.py` to the no-init subpackages (or enable namespace discovery) so grimp sees all 373 modules. Does NOT need the venv. Allowlist note: all 9 `ignore_imports` entries reconciled — every one still present in source AND its source module is within the covered 142, so all 9 are genuinely matched/active (none stale).

Separately, the canonical Windows venv IS still required, but for a DIFFERENT reason: runtime/parity tests. `.venv/Scripts/python.exe` errors from WSL (`No Python at '/usr/bin\python.exe'`, no cmd.exe interop); only `.venv/bin/python` (linux 3.12.3) works, with deps DRIFTED off pins (numpy 2.4.6 vs 1.24.3, pandas 3.0.3 vs 1.5.3, pydantic v2, TA-Lib uninstallable). See [[repo-uses-windows-venv]].
