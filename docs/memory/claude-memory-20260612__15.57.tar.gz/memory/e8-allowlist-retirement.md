---
name: e8-allowlist-retirement
description: "E8 allowlist-edge retirement sweep — what was retired, current count, exact path to allowlist=0"
metadata: 
  node_type: memory
  type: project
  originSessionId: 0e6b0c19-65f7-49fd-8663-176dd6d86a22
---

E8 "remaining architecture debt" sweep on branch `e3-consolidation-behind-ports` (2026-06-09, after E1 closed). Goal: reduce allowlist edges without touching E5-B. Allowlist lives in `pyproject.toml [tool.importlinter]` (2 contracts: layered + R1 interface↛infra).

**Allowlist 56 → 45 (11 retired). All via `.venv/bin/lint-imports` (409 files, 2 kept/0 broken) + characterization tests.** Three commits:
- **E8.T4(a)** delete dead `application/services/position_sizing_service.py` (deprecated E3.T3, 0 importers) → −1.
- **E8.T4(b)** relocate `shared/event_system.py` → `infrastructure/messaging/event_system.py` → −5 net. It built Orders/placed trades + imported domain/infra (R6 violation); all real importers already in infra/. Pure git-mv + import repoint. Only edge left = `infrastructure.messaging.event_system -> bootstrap.settings.loaders` (settings singleton on trade-exec path; load_settings de-coupling = trading change, deferred).
- **E8.T4(c)** delete dead E0-legacy `application/services/{workflow_manager,unified_optimization_service}.py` (commit 8092332 E0; 0 importers, 0 class refs, no __main__) → −5. Edges were parked in E5/E5-B blocks but modules are dead → deletion is E8, not E5-B work.

**Remaining 45 = ALL blocked (none safely retireable now):**
- **E5-B golden-gated (15)**: risk/exec/position-sizing wiring (7: strategy_adapters/risk_engine_adapter/position_sizing_engine_adapter/advanced_execution_service → app; enterprise_risk_manager → trade_tracker/regime_detector/forensic_logger) + backtest/wfo (8: cross_validation_engine/wfo_orchestrator/main_wfo + backtest.adapters.walk_forward). OFF-LIMITS per user.
- **E4-frozen (9)**: data-ingestion/DTO (csv_history_loader→dto, data_downloader_adapter→dto/configs, file_repository_adapter→ports, configurable_historical_data_provider→centralized_symbol_manager, _edp_pricing/_edp_availability/enhanced_data_provider→sync_manager). E4 closure freeze.
- **E1 settings singletons (7) — architecture-blocked**: centralized_symbol_manager, strategy_config, trade_tracker, forensic_logger, wfo_config, fusion_service(also E5-B trading), event_system → bootstrap.settings.loaders. All module-level EAGER singletons calling load_settings() at import; retiring requires de-singletonize + constructor-inject + consumer rewire = design decision (#1/#6 stop). E1.T4/T5 already did all the container-wired (non-singleton) ones.
- **E1 config-layer EXEMPT (2)**: configs.symbol_config + configs.sync_settings → loaders (config layer legitimately reads settings; exempt by E1.T5 rule, never retire).
- **E5-A dependency-inversion (2)**: main_wfo→interface.reporting.walkforward_report, production_trading_orchestrator→interface.reporting.live_dashboard (relocations done; full inversion = logic change, deferred).
- **E5 datasync wiring (6)**: sync_loop/watcher_retune→data_downloader_adapter/file_repository_adapter, watcher_services→market_data_feed, adaptive_retuning→results_tracker. R2 violations needing port inversion (architectural).
- **shared.optimization_service→hyperopt_space (1)**: R6; `ParameterSpace.__init__` imports concrete HyperoptParameterSpace (implements domain.ports.optimization_ports.IParameterSpace). Retire via DI/port injection + rewire 4 app consumers = architectural.
- **R1 CLI fat-wiring (3)**: comprehensive_portfolio_backtest/comprehensive_validation/extended_horizon_validation → comprehensive_portfolio_backtester. Route via bootstrap factory = WIRING change (forbidden under E5.T6 constraints).

**EXACT PATH TO ALLOWLIST=0** (each needs its owning epic, none is free):
1. De-singletonize the 7 settings globals (E1-followup) → −7. Pattern: drop module-level eager `x = Foo()`, make consumers build `Foo(settings)` via container, delete `load_settings` import.
2. Unfreeze E4 + invert data-ingestion DTO ports → −9.
3. E5-B golden-gated risk/backtest port inversion → −15.
4. E5-A dependency inversion on the 2 reporting edges → −2.
5. E5 datasync port inversion (6) + optimization_service port DI (1) → −7.
6. E5.T6 CLI fat-wiring via bootstrap factory → −3.
7. Keep the 2 config-layer exempt edges OR carve them into a separate "allowed" list (they're legitimate, not debt) → −2.

**Entry-point scripts NOT deleted (have __main__, runnable, not dead): `application/walk_forward/main_wfo.py`, `application/data_sync/sync_loop.py`. Pre-existing OUT-OF-SCOPE bug: `application/services/multi_strategy_optimizer.py` imports nonexistent `shared.auto_drop` (broken since before this session) — flagged, not fixed.**

See [[e1-t4-t5-progress]] [[e8-cleanup-progress]] [[canonical-env-validation-unblocked]] [[e5-decomposition-plan]].
