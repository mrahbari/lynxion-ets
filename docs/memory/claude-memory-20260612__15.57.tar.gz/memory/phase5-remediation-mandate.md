---
name: phase5-remediation-mandate
description: "Phase-5 is Measure→Diagnose→FIX→Re-evaluate, not audit-only; remediate every validated blocker"
metadata: 
  node_type: memory
  type: project
  originSessionId: fc9cdcc4-5d1d-422b-a04e-ac66c5c6912d
---

Phase 5 is NOT audit-only. After a profitability blocker is quantified and
validated (in E-P5.3 / E-P5.4 / E-P5.5), the mandated next step is
IMPLEMENTATION, not just diagnosis.

For every validated blocker, run the full cycle:
1. quantify impact  2. estimate profitability upside  3. create remediation
epic/task (`tasks/phase5-profitability/remediation-<id>.md`)  4. prioritize by
expected ROI (upside × confidence ÷ effort)  5. IMPLEMENT unless approval-gated
6. re-run affected evaluations  7. measure improvement vs frozen baseline +
update [[phase5-ep5.2-progress]] blocker-ledger status with measured delta.

**Why:** user clarified (2026-06-10) the end goal is to systematically REMOVE
the highest-ROI blockers and measure the resulting improvement — Measure →
Diagnose → Fix → Re-evaluate, not Measure → Diagnose → Stop.

**How to apply:** keep the diagnosis→remediation→re-eval loop running
autonomously until blockers are exhausted, an approval gate appears, or a
defensible profitability verdict is reached. Approval gates only = production
assets / real money / data loss / security / legal-compliance /
materially-different architecture / irreversible / external paid service.
Respect frozen-baseline discipline: remediation edits land ON TOP of the freeze
and are re-measured against it. Encoded in tasks/phase5-profitability/README.md
(blocker-handling + per-epic template outputs 7-9).
