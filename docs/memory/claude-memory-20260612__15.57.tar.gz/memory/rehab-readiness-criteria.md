---
name: rehab-readiness-criteria
description: Strategy Rehabilitation Mode — the READY bar and required deliverables
metadata: 
  node_type: memory
  type: feedback
  originSessionId: fc9cdcc4-5d1d-422b-a04e-ac66c5c6912d
---

**Strategy Rehabilitation Mode (approved 2026-06-12).** Objective = "deployable
trading systems", NOT "working code". Method: Measure→Diagnose→Fix→Re-evaluate per
strategy across 10 dims (signal freq, trade freq, long cov, short cov, regime cov,
stop, TP, RR geometry, timeframe suitability, data sufficiency). Classify each weakness
A=impl-defect / B=calibration / C=structural-hypothesis-limit. **Fix A & B only; never
modify C.** Not optimization/Hyperopt/param-search — only "reasonable engineering
assumptions" restoration.

**READY bar (HARD — do not inflate):** READY is NOT earned by correctness, signals, or
passing impl checks. READY requires ALL of: (1) sufficient trade sample, (2) stable
across symbols, (3) stable across windows, (4) acceptable drawdown, (5) no unresolved
A/B, (6) no directional-bias bug, (7) no starvation, (8) no data-dependency defect,
(9) no execution-path defect, (10) no fidelity gap — AND **profitability-supported**.
**If PnL stays negative after all A/B remediation → NEEDS_IMPROVEMENT, never READY.**
A correctly-implemented losing strategy is NOT READY. Verdicts must be evidence-based.

**Final deliverables (after A/B findings exhausted):** (1) final rehabilitation report,
(2) final readiness matrix, (3) production deployment recommendation, (4) ranked roadmap
for remaining strategy work. "Do not stop at documentation. Continue until rehab
exhausted." Builds on [[direction-b-strategy-remediation]]. Working doc:
docs/reports/strategy-rehabilitation.md; HFR: docs/reports/hypothesis-fidelity-review.md.

**REHAB COMPLETE (2026-06-12, commits 30e57d8 + 5d78e38).** Stop condition met (all
Type-A resolved). 5 deliverables in docs/reports/: strategy-rehabilitation,
strategy-readiness-matrix, production-readiness-report, final-strategy-roadmap,
candidate-calibration-fixes. Verdicts: **READY 0 / NEEDS_IMPROVEMENT 11 / NON_VIABLE 1**
(scalping). **HEADLINE finding: 1m is structurally cost-incompatible** — TP=2.25×ATR≈0.10%
<< 0.30% round-trip cost (fee0.1%×2+slip0.05%×2); breakeven≈15m; this caused the universal
2-5% win rate (NOT signal quality). Empirically confirmed: built BACKTEST_TIMEFRAME
data-flow hook (run_backtest.py + file_repository_adapter.py, default-preserving) +
research/profitability_diagnostics/higher_tf_eval.py; resampled 1m→15m/1h
(data/history/raw/15m,1h, untracked). At 1h win rates 14-26%, a few cells positive/GO
(oi_footprint ETH, mtf_trend/momentum BTC) but **NO strategy stable across BTC/ETH/SOL**
(SOL destroys all) → none meets profitability+stability READY bar. Type-A fixed: liquidity
'type'-key directional bug 0→61 BUY. Type-B (documented, NOT changed): breakout
min_confidence-vs-confidence-scale gate (0 trades), atr_mult/RR-vs-cost, vwap dead-rejection.
1m canonical matrix left partial (17 BTC cells; full=~32h O(n²), low-value). NOT
production-ready; #1 next lever = re-baseline on ≥15m + cross-symbol stability gates + WFO.
