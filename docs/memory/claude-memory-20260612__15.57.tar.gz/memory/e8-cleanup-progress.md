---
name: e8-cleanup-progress
description: E8 (Continuous Cleanup) progress — T1a/T1b/T2 committed; what remains; utils/ gone
metadata: 
  node_type: memory
  type: project
  originSessionId: 069a6e94-95a9-4405-abec-75defb63cf03
---

E8 (Stage 5 cleanup) executed step-wise on branch `e3-consolidation-behind-ports` (E6.T1 was committed by the user as `be26ed3`). Each step: verify zero-importers → delete/move → grep + lint-imports + compileall + runnable test subset → commit.

- **E8.T1a ✅ `1ba4d51`** — deleted 6 zero-importer orphans: `infrastructure/risk/{risk_adapters,adaptive_risk_manager}.py`, `application/services/workflow_orchestrator.py`, `utils/{data_integrity_checker,data_integrity_report,profitability_enhancer}.py`.
- **E8.T1b ✅ `ab6a324`** — deleted 2 dead chains: `main_hexagonal_container.py` (legacy E2 root) → `infrastructure/risk_management/portfolio_risk_manager.py`; `application/execution/advanced_execution_engine.py` → `infrastructure/risk/advanced_sltp_manager.py`. `infrastructure/risk_management/` now has no tracked files.
- **E8.T2 ✅ `78ed695`** — folded `utils/` and removed it: `utils/logger.py`→`shared/sync_logger.py` (stdlib SyncLogger, used by app+infra so must be shared/R6), `utils/config_helper.py`→`shared/config_helper.py`, `utils/symbol_validator.py`→`infrastructure/services/symbol_validator.py` (imports domain+shared, all 7 importers infra). Repointed 21 sites. **Gotcha fixed:** SymbolValidator resolved `approved_symbols.json` via `dirname(dirname(__file__))` ("2 levels"); the move to depth-2 broke it → changed to 3 levels (loads 676 symbols). `<root>/application/configs/approved_symbols.json` is the canonical config.

- **E8.T1c ✅ `dc625ce`** — deleted `infrastructure/position_sizing/advanced_position_sizing.py` (deprecated E3.T3, 0 module-path importers; its class duplicate-defined in probabilistic_position_sizer is unrelated). Fixed the stale `risk_engine_adapter.py` docstring (it claimed the T1a/T1b-deleted risk modules "remain importable").

**CORRECTION — "orphan factory wiring" is NOT orphaned (do NOT delete):** the stack `application/containers/container.py <- factories/trading_factories <- services/trading_services <- use_cases/trading_use_cases` is LIVE — reachable via `watcher_services -> watcher_use_cases -> bootstrap/container`, orchestrators, and `interface/cli`. The backlog label is a misnomer; leave it.

**Remaining E8:** "lazy compatibility accessors" = the `__getattr__` in `probabilistic_position_sizer.py` (an E5-B module → defer to E5-B, don't touch now). E8.T3 (docs refresh) not started (README already clean of deleted refs). Allowlist NOT reduced by E8 yet — the shared/ event_system (retire 2) + optimization_service (port-split) edges need relocation, and need the canonical Windows venv for full-graph lint first (grimp analyzes only 142/377 files here). See [[e6-enforcement-progress]].

Validation caveat unchanged: full suite needs the canonical Windows venv (pinned deps); this WSL venv runs lint-imports + a runnable test subset only. See [[repo-uses-windows-venv]], [[repo-tests-gitignored]].
