---
name: repo-uses-windows-venv
description: How to run Python/pytest in this WSL-mounted repo (Windows venv)
metadata: 
  node_type: memory
  type: reference
  originSessionId: fbf89117-bcaa-47ab-9653-f256abfc173a
---

**CORRECTION 2026-06-08 — the "pinned-deps canonical venv" framing in prior memories is WRONG.** Verified by reading `.venv/Lib/site-packages` (the actual Windows venv) + `.github/workflows/ci.yml`: the project's REAL canonical environment is **Python 3.12** (CI sets `python-version: "3.12"`; venv holds cp312 win_amd64 wheels) with **numpy 1.26.4, pandas 3.0.3, pydantic 2.13.4 (v2), scipy 1.17.1, scikit-learn 1.9.0, ccxt 4.5.56, matplotlib 3.10.9, aiohttp 3.14.0, hyperopt 0.2.7, fastapi 0.136.3**. The `requirements.txt` pins `numpy==1.24.3`/`pandas==1.5.3` are STALE (last touched at E0.T1 `8092332`, never updated, and have NO cp312 distribution — they were never actually installed). **pydantic is v2, NOT v1** — `bootstrap/settings/schema.py:43` uses `model_config = ConfigDict(...)` which is v2-only, so the code CANNOT run on pydantic v1 (the 16 v1-style `@validator`/`class Config` schemas work via v2's back-compat shim). **TA-Lib is declared in requirements.txt but imported by ZERO source files** → not an actual runtime dependency; absent from the working venv. Net: there is no pinned-deps environment to "restore"; the modernization already happened (≤E1). The drifted linux `.venv/bin/python` (numpy 2.4.6/pandas 3.0.3/pydantic 2.13.4) differs from canonical mainly in numpy major. requirements.txt needs a separate hygiene correction (flagged, not done — pins ≠ reality).

**UPDATE 2026-06-12 — in the current WSL bash, `.venv/Scripts/python.exe` FAILS** (launcher errors with `No Python at '/usr/bin\python.exe'`; pyvenv.cfg `home=/usr/bin`). The working interpreter in this shell is the LINUX venv **`.venv/bin/python`** — it has all deps (numpy/pandas/pydantic-v2/pytest) and runs the suite fine (e.g. `.venv/bin/python -m pytest tests/unit/... -q`). Note: `infrastructure/orchestrators/production_trading_orchestrator.py` import-fails on `import dash` (optional dashboard dep absent) — that's pre-existing and module-top; the composition root imports it lazily so it doesn't affect production wiring or byte-compile.

This repo lives on a Windows mount under WSL. There is no system `python`/`pytest` on PATH. Prior guidance was the Windows venv `.venv/Scripts/python.exe -m pytest ...`; use `.venv/bin/python` instead when the `.exe` launcher fails. Run from the repo root. pytest config in `pyproject.toml` (`[tool.pytest.ini_options]`, markers: unit/e2e/integration, strict markers, asyncio auto).

Flakiness note: `shared.logger.create_logger` uses a `RotatingFileHandler` on `logs/system.log` that can intermittently fail rotation on the Windows-mounted FS (its own source comments warn about this). A test touching `EnhancedLogger` may flake ~rarely with an I/O error unrelated to logic — re-run to confirm before treating as a real failure.
