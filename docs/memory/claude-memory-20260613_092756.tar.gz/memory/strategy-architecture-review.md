---
name: strategy-architecture-review
description: Strategy architecture review — READY=0 is predominantly (B) misdeployment not (A) absence of edge; analysis-only
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Strategy Architecture Review (2026-06-13, analysis-only, NO code/param/threshold changes). Report: `docs/reports/strategy_architecture_review.md`. Question: is READY=0 caused by (A) absence of edge or (B) architectural deployment mistakes? **Answer: predominantly (B)** — current evidence CANNOT distinguish "no edge" from "wrong environment."

**10 surviving strategies (NEEDS_IMPROVEMENT)** = trend_following, mean_reversion, momentum, breakout, liquidity, mtf_trend, oi_footprint, sweep_scalper, vwap_reversal, volatility_breakout. (2 RETIRED: scalping = cost-incompatible on 1m liquid crypto; crypto_breakout = code alias of breakout.)

**Verdicts:** 3 ARCHITECTURALLY INVALIDATED (as-implemented, core mechanism stub/absent → can't express hypothesis): mtf_trend (single-TF EMA proxy, compute_trend mock + weights dead, NOT true MTF), oi_footprint (never reads OI, volume proxy, empirical Δ=0), sweep_scalper (detect_sweep() stub returns 0/unused, killzone unused → crude range-ratio). 7 ARCHITECTURALLY MISDEPLOYED (sound+faithful but evaluated off designed env): trend_following, mean_reversion, momentum, breakout (untradeable — Type-B confidence-vs-min_confidence scale defect → 0 trades), liquidity, vwap_reversal, volatility_breakout. 0 SOUND.

**Three deployment mismatches (the (B) evidence):** (1) per-strategy design TFs declared in strategy_config.py (scalping/sweep_scalper 1m; liquidity/vwap_reversal 5m; breakout/volatility_breakout/mtf_trend 15m; trend_following/mean_reversion/momentum/oi_footprint 1h) but `get_strategy_timeframe(name,default)` IGNORES name (strategy_config.py:104-112) AND matrix flattened ALL to 15m/30m/1h; signal-freq diagnostic ran only BTC 1m. (2) regime detector exists (infrastructure/market_regime/regime_detector.py) but only soft risk/scoring weights — strategies always-on, validation never regime-conditioned. (3) SOL = universal failure (0 positive cells every strategy) pooled into all-3-must-be-positive roll-up, burying BTC-favourable (momentum, mtf_trend) + ETH-favourable (oi_footprint, liquidity, trend_following) single-symbol behavior.

**4 deployment recs:** exclude/separate SOL from pooled verdict (YES); independent BTC/ETH verdicts (YES); real per-strategy TF routing + design-TF eval (REQUIRED — currently broken); regime-based activation + regime-conditioned eval (REQUIRED). Caveat: fixing these is bounded by the standing no-param/threshold/optimization freeze; single-symbol positives may still be noise. Commit 23bdfac. Strategy verdict remains frozen (READY=0) — this review does NOT re-run/re-tune anything.
