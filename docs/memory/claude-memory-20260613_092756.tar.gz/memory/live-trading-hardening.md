---
name: live-trading-hardening
description: Live trading hardening — B1/B2/B5 RESOLVED (tested); B3/B4/B6/B7 remaining; verdict still NO-GO
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Live trading hardening (2026-06-12), implementing the [[live-trading-readiness-audit]] blockers. Final deliverable: `docs/reports/live_trading_production_readiness_final.md` (blocker matrix + GO/NO-GO). Strategy frozen. Verdict still **NO-GO** but 3 of 7 blockers resolved.

**RESOLVED (code + unit tests, all in bingx_adapter / multi_broker_service):**
- **B1 guaranteed protection** (`bingx_adapter._BingXBroker`): on SL/TP conditional-order failure, `_unwind_position` issues reduceOnly market close; if unwind fails → engage kill switch + flag orphaned_main_order_id + return success=False. Fixed the "naked position reported as success" bug. `test_b1_guaranteed_protection` 3/3. Testnet: protections succeeded that run (intermittent failure didn't recur) so unwind not observed live — proven by unit tests.
- **B2 idempotency** (`ensure_client_order_id` in bingx_adapter): generate client_order_id once, assign back to order (retry reuses), send as `clientOrderID` on both BingX payloads. `test_b2_idempotency` 3/3.
- **B5 cancel/status** (`multi_broker_service`): added `_order_exchange_map` (order_id→(exchange,symbol)) populated at placement; cancel_order/get_execution_status route to origin adapter (bingx get_order_status queries open+history); unknown→fail safe. `test_b5_order_lifecycle` 2/2.

**ALSO RESOLVED (2026-06-12 cont.):**
- **B3 durable recovery**: `infrastructure/execution/live_order_journal.py` (append-only fsync JSONL, INTENT-before-send→SUBMITTED→terminal); wired into multi_broker real-send path; multi_broker __init__ does startup recovery (rebuild order→exchange map + flag in-flight). `test_b3_durable_recovery` 4/4. **TESTNET-VALIDATED**: journal captured INTENT BTCUSDT/ETHUSDT→SUBMITTED with real order ids 2065541051751337984/2065541166012567552 + client_order_ids. Path bug fixed (module 2 levels deep needs 3 dirnames → was writing to infrastructure/data/, now <root>/data/).
- **B6 retry/backoff**: `shared/retry.py` (capped exp backoff, should_retry, injectable sleep) applied to multi_broker.get_execution_status read path. `test_b6_retry` 4/4.

**B4 + B7 NOW DONE (2026-06-12 cont., all 7 blockers resolved):**
- **B4 broker reconciliation** `infrastructure/execution/broker_reconciliation.py`: reconcile(broker, journal) resolves in-flight orders via broker status/fill + detects UNRECOVERABLE drift (broker position w/ no local journal record) → engages kill switch. **Testnet-validated**: fetched 9 real positions, flagged 7 unrecoverable, kill switch ENGAGED. Fixed get_all_positions to skip malformed exchange symbols (was crashing on "NCCOGOLD2USDUSDT" → disabled drift detection). `test_b4_broker_reconciliation` 4/4.
- **B7 partial-fill** `live_order_journal.record_fill/net_filled` (PARTIALLY_FILLED open state→FILLED), bingx `get_order_fill` (status+executedQty), reconcile records partials. Survives restart. `test_b7_partial_fill` 3/3. (Testnet MARKET orders fill fully — partials validated deterministically.)
- Full chain proven on testnet: RESTART RECOVERY (2 orders) → RECONCILE (9 positions, 7 unrecoverable) → HALT (kill switch engaged).

**ALL 7 BLOCKERS RESOLVED. 60/60 live-hardening unit tests pass.** Commits through 1084c5a. 4 reports: docs/reports/{broker_reconciliation_report,partial_fill_validation,testnet_soak_report,final_live_trading_readiness_report}.md.

**R1-R4 finalization DONE (2026-06-13):** R1 periodic reconcile loop wired into BOTH orchestrators (_reconciliation_loop, 60s, halt-on-drift) — live-testnet confirmed running + halts. R2 startup preflight `shared/preflight.py` (refuses unsafe LIVE start, wired into trading_system_production CLI) + journal.net_positions() local net-position book + 50-order restart-stress. R3 ~9min testnet soak: **safety chain proven end-to-end** — reconcile detected real drift (SUI/SOL/BCH leftover positions) → kill switch engaged → ALL 120 order attempts BLOCKED (0 placed). Soak found+fixed: EnhancedLogger lacked `.critical` (added; reconcile-halt logging crashed each cycle though halt worked), defensive alert-send wrap, preflight flush=True. R4 final verdict `docs/reports/infrastructure_go_no_go_final.md`. 4 deliverables: docs/reports/{r1_reconciliation_integration_report,r2_operational_hardening_report,testnet_soak_report_final,infrastructure_go_no_go_final}.md.

**69/69 unit tests pass. Commits through 85f9ec8.** FINAL VERDICT: **NO-GO, engineering-complete.** Remaining (operational/owner, NOT missing safety): C1 full 24-72h soak on CLEAN testnet account (clear leftover positions first — they pre-seed drift-halt); C2 owner credential rotation; C3 reconcile cadence vs BingX 5req/min rate budget; C4 truth-ledger per-deployment segmentation (shared file accumulates cross-run hash breaks); C5 wire real notification creds; C6 order-history window widening (UNKNOWN status); C7 logger-rollover FS flake; C8 Binance testnet/spot. ~1wk + soak window. All 7 blockers (B1-B7) + R1/R2 done & testnet-validated.

**53/53 live-hardening unit tests pass.** Commits: beeeecf(B2), a82011d(B5), B3+fix(454bba5), B6, 271393c(report). tests/ gitignored. Verdict still NO-GO. NOTE (user observed): only trend_following emits signals in runs; mean_reversion/volatility_breakout register but REJECT fused signals (log: "regime_context='stable'/'trending' does not indicate ...") — strategy/signal layer behavior, FROZEN, not investigated.
