---
name: live-trading-readiness-audit
description: Live trading readiness audit — verdict NO-GO; 6 blockers; ~3-4wk broker-lifecycle hardening + testnet soak
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Live trading readiness audit (2026-06-12). Verdict: **NO-GO for real funds.** Deliverables: `docs/reports/live_trading_{readiness_audit,gap_analysis,release_checklist,go_no_go_decision}.md`. Strategy frozen (READY=0) — note: even with GO infra, no edge = no expected profit; infra GO is prerequisite not reason. Builds on [[phase11-infra-completion]].

**Validated strong (testnet run, valid BingX creds, paper off / BINGX_TESTNET=true / LIVE_TRADING unset):** both real-funds send-points (multi_broker.execute_order, broker_execution_service single) route through guard.authorize_and_send = ALL 5 controls enforced (guard, risk admission fail-closed, kill switch, circuit breaker, ETL). Run placed **4 real testnet orders** (real exchange ids e.g. 2065529962644901888), **0 LIVE / 0 PAPER / 0 unauthorized**, ETL recorded all. Real-send path works + correctly gated.

**6 blockers (NO-GO):** B1 CRITICAL SL/TP not guaranteed — conditional orders placed separately, failure swallowed, main reported success → naked position (**EMPIRICALLY REPRODUCED**: 4 conditional-order errors on testnet); B2 CRITICAL no client_order_id idempotency (bingx place_order payload has none) + errors→None untyped → duplicate/phantom on retry; B3 CRITICAL no durable LIVE position/order store (PendingOrdersTracker + EnterpriseRiskManager in-memory) + no startup recovery; B4 CRITICAL reconciliation only engine-vs-ledger, NOT vs real broker API; B5 HIGH cancel/status non-functional at multi-broker layer (no order_id→exchange map; bingx ADAPTER get_order_status works but layer doesn't use it); B6/B7 HIGH no retry/backoff, no partial-fill handling. Also: Binance ignores testnet/spot-vs-futures (M), committed creds need rotation (owner).

**Effort ~3-4 weeks** incremental (spine done). Path: A1 guarantee stop→A2 idempotency+typed results→A3 durable journal+startup recovery→A4 broker reconcile+halt-on-drift→A5 cancel/status→A6 retry+partial-fill→owner secret rotation→24-72h testnet soak (induced disconnects/timeouts/partials+restart)→tiny-cap first live. Commit fb3851b. Note observed (frozen, not acted): "Signal contradiction Bias=SELL vs Order=BUY" fusion-layer warning; logger RotatingFileHandler WSL-mount flake (benign).
