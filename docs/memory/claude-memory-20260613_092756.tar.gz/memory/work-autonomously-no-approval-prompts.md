---
name: work-autonomously-no-approval-prompts
description: "User wants minimal approval prompts — proceed autonomously, don't stop for routine confirmations"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

The user is disturbed by frequent tool-approval prompts and explicitly asked to "proceed without asking." Combined with CLAUDE.md Rule 4/Autonomous Execution Policy.

**Why:** They want momentum, not interruptions for routine engineering decisions.

**How to apply:** Execute multi-step tasks end-to-end without pausing for confirmation. Only surface a true Rule-5 approval gate (production secrets, real funds, destructive/irreversible actions). For read-only/verification bash, batch commands and avoid constructs (subshells like `$(...)`, unusual flags) that may trigger permission prompts; prefer plain, allowlisted invocations. Don't ask "should I proceed?" — just do it and report results. Consider running `/fewer-permission-prompts` or adding allowlist entries via settings to reduce future prompts. See [[repo-uses-windows-venv]].
