---
name: timeframe-rearchitecture-mandate
description: Active mandate after Phase-6 termination — timeframe re-architecture + final validation; state to resume
metadata: 
  node_type: memory
  type: project
  originSessionId: fc9cdcc4-5d1d-422b-a04e-ac66c5c6912d
---

**Phase 6 CLOSED (2026-06-12).** Edge discovery terminated: free-data search exhausted,
no stable tradeable edge, cost-cliff validated, false positives rejected. Research-only
artifacts ALREADY archived (research/edge_discovery → docs/archive/phase6/; only
research/profitability_diagnostics/ = eval framework remains). NO more edge discovery /
new strategies / signal classes / hypothesis mining / hyperopt / param sweeps / optimization.

**ACTIVE MANDATE: Timeframe Re-Architecture + Final Validation.** Validate & finalize the
12 fixed production strategies. Rules: existing production parameters ONLY — no tuning, no
threshold changes, no curve-fitting.

**Architecture:** 1m stays the CANONICAL broker data feed (do NOT switch source). Create
higher TFs by RESAMPLING 1m→5m/15m/30m/1h. Mandatory MTF standard: downsample→ffill→
shift→align, NO lookahead. Timeframe roles: 1h=macro trend filter, 30m=trend confirmation,
15m=PRIMARY signal TF, 5m=entry refinement, 1m=execution only. **Strategies must NOT use
1m as primary decision TF.**

**Validation:** re-evaluate all 12 strategies on BTC/ETH/SOL × {15m,30m,1h}.
READY=profitable+stable across symbols+stable across horizons+statistically supported;
NEEDS_IMPROVEMENT=correct+inconsistent profit; NON_VIABLE=structural.

**5 DELIVERABLES (docs/reports/):** timeframe-refactor-report.md,
timeframe-validation-report.md, cross-symbol-stability-report.md,
production-candidate-ranking.md, final-deployment-readiness-report.md.

**INFRA ALREADY BUILT (reuse — do NOT rebuild):** BACKTEST_TIMEFRAME env hook
(application/use_cases/run_backtest.py + infrastructure/data_sync/file_repository_adapter.py,
default-preserving; reads data/history/raw/<tf>/). Runner:
research/profitability_diagnostics/higher_tf_eval.py (arg=tf, writes eval_matrix_<tf>.json,
resumable). Resample recipe (correct epoch): see commit 5d78e38 / regenerate with
`(g.index - pd.Timestamp('1970-01-01'))//pd.Timedelta('1s')` for timestamp col.

**STATE AT SHUTDOWN (2026-06-12):**
- Resampled data present: data/history/raw/15m/, 1h/ (BTC/ETH/SOL). **MISSING: 5m, 30m**
  (resample these on resume — same recipe).
- eval_matrix_1h.json = COMPLETE (108 cells). eval_matrix_15m.json = PARTIAL (89/108,
  resume via `BACKTEST_TIMEFRAME=15m .venv/bin/python3 research/profitability_diagnostics/higher_tf_eval.py 15m`).
  **30m matrix NOT run.** 1m eval_matrix.json = partial 17 BTC cells (leave; 1m is
  execution-only now).
- 5 reports NOT yet written.

**KEY EVIDENCE ALREADY ESTABLISHED (carry into reports):** 1m structurally cost-incompatible
(TP=2.25×ATR≈0.10% << 0.30% round-trip cost; breakeven≈15m). At 1h: win rates 14-26% (vs
1m 2-5%), a few cells positive/GO (oi_footprint ETH 365d +165, mtf_trend BTC 180d +156,
trend_following ETH 365d +50) but **NO strategy stable across BTC/ETH/SOL** (SOL universally
unprofitable). 15m partial avg win ~22%, 0/16 sig cells positive. Prior rehab verdict
(commit 5d78e38): READY 0 / NEEDS_IMPROVEMENT 11 / NON_VIABLE 1 (scalping). Builds on
[[rehab-readiness-criteria]] [[direction-b-strategy-remediation]].

**ON RESUME:** (1) resample 5m+30m; (2) finish 15m matrix + run 30m matrix (1h done);
(3) write the 5 deliverables from the 15m/30m/1h matrices; (4) assign final verdicts.
Continue autonomously, no edge discovery.

**MANDATE COMPLETE (2026-06-12, commits 341751e + predecessors).** All 324 cells done
(15m/30m/1h × BTC/ETH/SOL × 90/180/365d): 15m=108, 30m=108, 1h=108
(data/results_storage/eval_matrix_{15m,30m,1h}.json). All 5 deliverables written+committed
in docs/reports/: timeframe-refactor-report, timeframe-validation-report,
cross-symbol-stability-report, production-candidate-ranking, final-deployment-readiness-report.
**FINAL VERDICT: NOT DEPLOYABLE — READY 0 / NEEDS_IMPROVEMENT 11 / NON_VIABLE 1 (scalping).**
Monotonic cost gradient (positive-sig-cells 15m 0/42 → 30m 1/39 → 1h 7/33; loss
−28.6k→−22.7k→−16.9k; all net-negative; win 19-24% << 40% breakeven). NO strategy positive
across all 3 symbols at any horizon; SOL universally unprofitable (0 positive cells any
strategy). 15m (mandated primary TF) is WORST (on cost cliff); 1h most cost-robust but
still edgeless. Closest (all NEEDS_IMPROVEMENT, single-symbol only): oi_footprint (ETH 1h
+165 GO, but data-blocked = volume OI proxy), mtf_trend (BTC), momentum (BTC). NEXT
non-tuning levers: real-OI feed for oi_footprint, cross-symbol stability gating + WFO on
1h, human-review breakout/vwap Type-B (candidate-calibration-fixes.md). Repo clean, all
background evals stopped — safe to shut down.

**WALK-FORWARD OOS DONE (2026-06-12, commit d2d6ed4) — CONCLUSIVE.** Ran the WFO lever:
research/profitability_diagnostics/wfo_eval.py → data/results_storage/wfo_1h.json (144
cells = 12 strat × BTC/ETH/SOL × 4 DISJOINT ~3mo OOS segments at 1h; no tuning, strategies
have no fitted params so WFO=temporal stability). RESULT: **ZERO temporally-stable
(strategy,symbol) pairs** — none positive in ≥3 of 4 OOS segments on any symbol (best=2/4
coin-flip, signs alternate). oi_footprint ETH (best nested cell +165 GO) only 2/4 OOS →
the nested-window positives are IN-SAMPLE ARTIFACTS, no persistent edge. 6th report:
docs/reports/walk-forward-validation-report.md; final-deployment-readiness-report.md
updated with OOS confirmation. Verdict UNCHANGED + now strongest-possible-evidence:
READY 0 / NOT DEPLOYABLE. Remaining non-tuning levers (not yet done): real-OI feed for
oi_footprint; human-review breakout B-1 / vwap B-3 Type-B reclassification.

**OPERATIONAL STABILIZATION + FINAL STRATEGY REVIEW COMPLETE (2026-06-12, commits
2d41384/5464c0c/395b822).** Phase 1 (6 tasks) done → verdict **STABLE** (DEV/paper+
testnet). Fixes (no logic/threshold/risk change): resample_engine 5T/15T/30T/1H→
5min/15min/30min/1h; backtester _detect_missing_candles 1H→1h; CMC excluded_coins
list-or-string; csv_history_loader empty-file guard; restored setuptools in venv (fixed
production-boot crash: pkg_resources missing via hyperopt import). Production boots+runs
~4.5min, full signal pipeline, graceful degradation, no crash/deadlock/runaway. Re-run
validated: CMC 2→0, CSV-nocols 47→0, Invalid-freq→0. Residuals: BINGX-not-connected
(testnet keys, env not code), 1 logging-rotation race (C). Doc-drift: README references 3
missing runners (correlation_stress/capital_shock/integration_tests). **SECURITY FLAG:**
.env has LIVE exchange keys (BingX/Binance/MEXC) while testnet=True — safe now but
flipping BROKER_TESTNET=false = real funds. Phase 2 (Final Strategy Review) → DECISION
GATE: all 12 adapters import/construct clean, all prior Type-A/B fixed, Direction-vs-Bias
'contradiction' is by-design, remaining Type-B out-of-scope (threshold-opt/redesign
disallowed) → **STRATEGY SUITE FINALIZED**. 6 reports in docs/reports/: stabilization-fixes,
runner-validation-report, system-stability-report, final-strategy-review (+ earlier
timeframe/wfo/rehab set). Mission objective met; stopped per decision gate. NOT DEPLOYABLE.

**PHASE 7 COMPLETE (2026-06-12, commit 6620b07) — FINAL DISPOSITIONS.** Strategy-by-strategy
deep review of all 12 (hypothesis/entry/exit/regime/symbol/timeframe + A/B/C). 5 reports in
docs/reports/phase7/: strategy_deep_review, strategy_issue_registry, strategy_survivor_ranking,
production_subset_candidates, final_strategy_decision. **READY 0 / NEEDS_IMPROVEMENT 10 /
NON_VIABLE 0 / RETIRED 2.** RETIRED: crypto_breakout (explicit code alias of breakout =
redundant; strategy_provider.py:49) + scalping (structural cost-incompat, negative every
TF+symbol). 10 NEEDS_IMPROVEMENT (correct+measurable, no stable edge, non-tuning path).
All 7 strategy Type-A defects fixed+verified; Type-B (breakout B1 confidence-formula≤0.2
can't reach own min_confidence=0.35 → 0 trades; vwap B2 dead-rejection) documented NOT
changed (=threshold/redesign disallowed). Production subset EMPTY. No new strategy (no
superior profitable alt). Dispositions are documentation — crypto_breakout alias + scalping
registrations NOT physically removed (avoid breaking refs; recommended cleanup only). Suite
FINALIZED at highest-confidence honest state. Watchlist (research-gated, non-tuning): real-OI
feed for oi_footprint → re-test under promotion rule (positive BTC&ETH&SOL + ≥3/4 OOS segs).

**PHASE 8 COMPLETE — PROGRAM CONCLUSIVELY CLOSED (2026-06-12, commit a4be4ff).** Resolved
3 final validity questions (rulings, no tuning); 4 reports in docs/reports/phase8/:
oi_footprint_validation, breakout_correctness_review, vwap_correctness_review,
phase8_final_verdict. KEY RULINGS: (1) **oi_footprint NEVER reads open interest** —
volume-momentum-RSI strategy mislabeled "OI footprint"; oi_expansion/delta_strength config
vestigial/unused; no OI data path; real-OI delta provably 0 without new logic; OI data only
~30d hourly. (2) **breakout** confidence formula (compression_ratio/10 → 0.10-0.15 for its
own >1.5-trigger setups) can't reach own min_confidence=0.35 (needs compression≥7) →
incompatible-scale correctness defect, untradeable-as-wired. (3) **vwap_reversal** rejection
path dead-in-context (fires 36/40 globally but 0 co-occurrence with entry zone; bullish_rej
needs close>VWAP vs BUY needs close<VWAP-band); functions via failure_swings. All 3 stay
NEEDS_IMPROVEMENT (remediation = new-logic or human-gated calibration, out of scope). READY
stayed 0 → **STRATEGY PROGRAM CLOSED, no unresolved validity questions.** FINAL SUITE: READY
0 / NEEDS_IMPROVEMENT 10 / NON_VIABLE 0 / RETIRED 2 (crypto_breakout, scalping). NOT
DEPLOYABLE. No further research/optimization/Phase-6 authorized.
