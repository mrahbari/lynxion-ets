---
name: phase9-infra-audit-verdict
description: Phase-9 production infrastructure audit — verdict PRODUCTION UNSAFE; safety components exist but unwired into live order path; committed creds need rotation
metadata: 
  node_type: memory
  type: project
  originSessionId: 9bf4eb08-8f8f-4005-8334-e188a6b9b43f
---

Phase-9 (2026-06-12) audited the production trading **infrastructure** (20 areas) — not strategy/profitability (program closed, READY=0). Verdict: **PRODUCTION UNSAFE** (infra only). Reports in `docs/reports/phase9/`: production_infrastructure_audit.md (master+verdict), risk_engine_review.md, broker_reliability_review.md, operational_readiness_review.md, production_release_checklist.md (GO/NO-GO gate).

**Core systemic finding:** the repo has competent safety components (EnterpriseRiskManager portfolio gates, position_sizing_engine, StrategyKillSwitchEngine, shared/circuit_breaker) BUT they are **not wired into the live order path**. The production orchestrator (`infrastructure/orchestrators/production_trading_orchestrator.py`, built at `bootstrap/container.py:478-489`) injects only market_data/execution/portfolio/optimization — it never resolves `risk_engine`/`position_sizing_engine` (those resolve only in tests), and `kill_switch`/`circuit_breaker` have zero refs in orchestrators/execution/services/brokers. `risk_engine.is_trading_allowed()` has no live caller. Order chokepoint = `infrastructure/services/broker_execution_service.py:191 execute_order` → only SL/TP-shape checks, **fails open** (`:641-643`), risk validation explicitly removed (`:716-717`).

**10 Critical themes:** no live risk gate (C1); breaches alert-only never halt (C2); no runtime kill switch/circuit breaker (C3); naive sizing off hardcoded $10k + random price on missing data (C4, `_auto_detection_execution.py:101-172`); no client_order_id idempotency + in-memory duplicate guard (C5); order errors collapse to None fail-open (C6); no durable state + blind restart (C7); no broker↔local reconciliation + hardcoded FILLED status (C8, `binance_adapter.py:175-180`); **committed live secrets** (C9); unsafe live defaults — order placement default True, paper_trading dead code, Binance ignores testnet, no startup preflight (C10). Also: wired "production" loop is itself a stub (random sample data + empty `LiveExecutionEngine._execute_trades`).

**SECURITY (owner action required, NOT done by me):** live exchange API keys (BingX/Binance/MEXC/Phemex) + CMC key + Telegram bot token are committed — populated values in **tracked** `.env.example` and hardcoded as defaults in `application/configs/schemas/monitoring.py:19-21`, `_config_extractors.py:288-290`, `profiles/{dev,staging,live}.py`. Per org policy these were **flagged, not removed**. Must rotate/revoke on all venues + purge git history. (No secret values are stored in memory or reports.)

**Applied autonomously (safe, verified):** added missing `import os` to `shared/sync_logger.py` (was raising NameError, breaking sync-path file logging). All other Critical/High fixes are **Rule-5 gated** (touch real-funds order path or secrets) and specified in production_release_checklist.md, not applied. Test suite couldn't run in WSL shell (Windows venv `.exe` interop fails; system py3 lacks numpy — see [[repo-uses-windows-venv]]).
