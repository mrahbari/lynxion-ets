import json, time, hmac, hashlib, urllib.request, urllib.error, urllib.parse
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from dotenv import dotenv_values

root=Path('/Users/mojtaba.rahbari/Sites/python/lynxion-ets')
env=dotenv_values(root/'.env',interpolate=False)
key,secret=env.get('BINGX_API_KEY'),env.get('BINGX_SECRET_KEY')
if not key or not secret: raise SystemExit('MISSING_CREDENTIALS')
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): raise RuntimeError('REDIRECT_DENIED')
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
def get(path, params=None):
    assert path in ('/openApi/swap/v2/user/positions','/openApi/swap/v2/trade/openOrders','/openApi/swap/v2/trade/allOrders')
    query=urllib.parse.urlencode(sorted(dict(params or {},timestamp=int(time.time()*1000),recvWindow=5000).items()))
    sig=hmac.new(secret.encode(),query.encode(),hashlib.sha256).hexdigest()
    request=urllib.request.Request('https://open-api-vst.bingx.com'+path+'?'+query+'&signature='+sig,
                                  headers={'X-BX-APIKEY':key},method='GET')
    try:
        with opener.open(request,timeout=20) as response: return json.loads(response.read())
    except urllib.error.HTTPError as exc: return {'code':'HTTP_ERROR','http_status':exc.code}
    except Exception as exc: return {'code':'TRANSPORT_ERROR','error_type':type(exc).__name__}
report={'utc':datetime.now(timezone.utc).isoformat(),'scope':'TESTNET_GET_ONLY'}
for label,path,field,keys in (
    ('positions','/openApi/swap/v2/user/positions','positions',('symbol','positionSide','positionAmt')),
    ('open_orders','/openApi/swap/v2/trade/openOrders','orders',('symbol','side','positionSide','type','status','origQty','stopPrice','reduceOnly','closePosition'))):
    body=get(path); report[label]={'code':body.get('code')}
    data=body.get('data')
    rows=data if isinstance(data,list) else data.get(field) if isinstance(data,dict) else None
    report[label]['schema_valid']=body.get('code')==0 and isinstance(rows,list)
    if report[label]['schema_valid']:
        try:
            if label=='positions':
                for row in rows:
                    if not Decimal(str(row['positionAmt'])).is_finite(): raise ValueError('nonfinite')
                rows=[r for r in rows if Decimal(str(r['positionAmt']))!=0]
            report[label].update(count=len(rows),rows=[{k:r.get(k) for k in keys} for r in rows])
        except Exception: report[label]['schema_valid']=False
if __import__('sys').argv[-1]=='--trx-history':
    # One bounded operational history request; no PnL/future research outcomes emitted.
    center=int(datetime(2026,10,24,5,49,22,tzinfo=timezone.utc).timestamp()*1000)
    body=get('/openApi/swap/v2/trade/allOrders',{'symbol':'TRX-USDT','startTime':center-86400000,'endTime':center+86400000,'limit':1000})
    data=body.get('data'); rows=data if isinstance(data,list) else data.get('orders') if isinstance(data,dict) else None
    report['trx_history']={'code':body.get('code'),'schema_valid':isinstance(rows,list)}
    if isinstance(rows,list):
        matches=[r for r in rows if str(r.get('type','')).upper()=='STOP_MARKET' and Decimal(str(r.get('stopPrice') or 0))==Decimal('0.328502')]
        report['trx_history'].update(count=len(rows),possible_truncation=len(rows)>=1000,
            exact_stop_price_matches=[{k:r.get(k) for k in ('symbol','side','positionSide','status','type','origQty','executedQty','stopPrice','time','updateTime')} for r in matches])
print(json.dumps(report,indent=2))
