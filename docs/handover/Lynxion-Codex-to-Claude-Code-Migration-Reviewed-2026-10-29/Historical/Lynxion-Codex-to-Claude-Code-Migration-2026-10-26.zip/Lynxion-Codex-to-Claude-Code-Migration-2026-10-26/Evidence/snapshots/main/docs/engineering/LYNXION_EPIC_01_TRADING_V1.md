# LYNXION-EPIC-01 — Trading System V1 Optimization & Validation

## 2026-10-24 23:28 UTC — explicit scientific-scope decision for baseline continuation

Inspected main02c2f2e and primary958dbd7; runtime session alive, log updating, no
ERROR/Traceback in sampled tail100. No repeated tests, broker reads/writes or deployment.
The original full-MTF three-family baseline remains blocked by TWO independent
requirements: truthful maker-order simulation AND synchronized observed5mOBI/CVD plus
1mquotes. An OHLCV maker model alone does not supply those missing observations.
Do not manufacture flow or relabel POST_ONLY intents as market to force a result.
Decision gate (not routine engineering permission): retain the original full-MTF
baseline as BLOCKED, or authorize a separately labeled DEVELOPMENT_ONLY component
experiment on qualified existing C06 inputs, with reduced observation coverage and
explicitly preregistered modeled execution assumptions. The latter is NOT the unchanged
strategy baseline, untouched OOS, VST fill evidence or proof of Edge. No component
outcomes may be opened before its exact contract/parameter/cost/boundary declaration.
Pending operator choice; meanwhile independent synthetic correctness/Radar work remains
authorized. No new backlog, cohort edits, collection or trading-policy change.


## 2026-10-24 22:31 UTC — existing execution facility reuse qualification

Inspected clean main e68b2ac and primary958dbd7 (same five unrelated research dirties).
Runner session99547 remained active and log updating; tail100 had no ERROR/Traceback.
No broker calls, restart, data writes or repeated tests. Existing facilities were read
before considering any replacement: PaperTradingEngine.simulate_fill uses reference
price plus slippage and immediate accounting, not pending LIMIT/POST_ONLY touch/queue
semantics. SimulatedBrokerAdapter in coin_history_service generates synthetic OHLCV;
it is not an order execution simulator. RealisticBacktestEngine creates MARKET orders;
canonical RealisticBacktester uses next-open pending market intent and its infrastructure
ExecutionIntent has no order-type/TIF contract. None of these inspected paths provides
a verified reusable maker queue/fill model. No new execution engine was introduced and
no existing maker-only family was silently converted to market to obtain a baseline.
T04/T05 remain BLOCKED_BY_EXECUTION_REALISM plus existing MTF observation boundaries.
Next bounded step: preregister a supported research execution contract and independently
specified conservative fill/cancel/expiry fixtures inside existing facilities before any
implementation or market outcomes; distinguish modeled behavior from broker evidence.


## 2026-10-24 21:33 UTC — composed maker-limit execution-model defect

Main baseline76f6c8d; current primary958dbd7 log/process inspected, unchanged. Synthetic
actual SetupEngine NGLS -> real confirmation/optimizer -> domain intent -> backtester
composition exposed POST_ONLY BUY limit10.199 being filled as market10.25 despite next
bar low10.2. A preliminary positive composition used too-wide synthetic spread and was
corrected to admissible explicit bid10.199/ask10.201 WITHOUT weakening spread guard.
The resulting market fill was characterization of a defect, NOT a valid positive test.
Replacement fail-closed expectation reproduced RED1FAIL/7PASS. Minimal offline adapter
guard now rejects unsupported limit_price/time_in_force/non-MARKET semantics BEFORE
global risk-engine access rather than guessing maker fills. Actual composed test and
three-field pre-risk lookup controls pass; real objective/backtester synthetic test
reports STATUS_FAIL/inf, never fabricated neutral/zero-trade performance.
Focused38PASS; selected full isolated suite305PASS,27warnings. Independent exact-diff
review/rerun38PASS, REVIEW_PASS_WITH_LIMITATIONS. No live strategy/risk/broker changes,
runner restart, real-market outcomes or economic optimization. Source MAIN ONLY.
Important release limitation: current DecisionPipeline-derived POST_ONLY domain intents
are BLOCKED_BY_EXECUTION_REALISM in this simulator. No maker-fill model was implemented,
and inability to simulate is NOT a negative strategy/Edge verdict. Other existing market
paths remain available under their own qualification gates; do not relabel maker plans
as market strategies to bypass this. T04-S04/05 and T05 remain BLOCKED; all30 scenario
counts unchanged. Next: qualify supported execution-model contract before baseline,
alongside already recorded true5mflow/1mquote-data limitations. No outcomes opened.


## 2026-10-24 20:31 UTC — marked replay ExecutionIntent clock contract

Main baseline 0da916a. Pipeline used fused timestamp or wall time without validating
explicit replay availability. Wrong/missing/naive/backdated/future fused clocks reached
confirmation: actual RED 1 FAIL / 9 PASS. For explicitly marked replay only, pipeline
now requires aware setup/fused/open/availability clocks, finite positive duration,
open+duration=availability, and exact row/setup/fused clock agreement BEFORE confirmation
or optimization. Unmarked legacy behavior and fallback remain unchanged.
Focused 11 PASS includes actual domain ExecutionIntent retaining causal timestamp,
symbol/fused identity with fake execution dependencies; legacy fallback control passes.
Full selected isolated allowlist 302 PASS, 27 warnings. Independent focused rerun
11 PASS, REVIEW_PASS_WITH_LIMITATIONS. No real orders, economic outcomes or optimization.
MAIN ONLY, not deployed to active primary958dbd7/session99547; no restart or risk change.
Limits: private-marker source/provenance still caller contract, malformed setup conversion
may fail with its native exception, other adapters not universally clock-bound. Existing
synthetic OBI/CVD/quotes defaults are NOT qualified observations and are not changed.
T03-S02/full replay parity remains unproven; 8 PASS / 1 FAIL / 21 BLOCKED unchanged.
Next: actual research replay composition must explicitly declare duration and qualify
availability/data/MTF observation boundaries before baseline outcomes may be opened.


## 2026-10-24 19:29 UTC — explicit replay clock propagated to three signal families

Main baseline 3cb237d; primary958dbd7 runner/log inspected and unchanged. Independent
fixture_review specified closed-bar marker transport and invalid-clock controls before
implementation (its local checkout caveat recorded; fixture expectations, not code verdict).
Backtester explicit-duration row lacked markers and Base lacked helper: actual RED
2 FAIL / 13 PASS. Explicit-duration path now carries availability, original bar open
and declared duration alongside existing availability-valued timestamp. Instance Hyperopt
wrapper preserves these fields. Base helper requires aware clocks, finite positive duration,
exact open+duration=availability, matching row timestamp and increasing prior marked bar;
partial/None/naive/future/duplicate/out-of-order markers fail rather than use wall time.
No markers retains live behavior. Existing TrendFollow/Breakout/Liquidity setup calls
and Signal timestamps consume that clock; no thresholds, MTF mapping or risk changes.
Focused GREEN 15 PASS before adapter fixtures; actual extracted signal methods with
synthetic dependencies verify all three families share setup/signal clock. Actual objective
wrapper/fake-backtester fixture verifies two-row transport. Final selected isolated suite
300 PASS, 27 warnings. No real economic outcomes, fmin optimization or source data changes.
Independent initial exact-diff focused run 43 PASS, REVIEW_PASS_WITH_LIMITATIONS;
additional wrapper fixture added after that review without changing production source.
Final independent rerun including wrapper fixture: 44 PASS, 27 warnings; limited verdict
confirmed and diff check clean.
Limits: explicit marker provenance is a caller contract, not exchange qualification;
AST/fake strategy fixtures are not complete replay parity. Mixed marked/unmarked buffer
history is not generally certified; other strategy families and downstream ExecutionIntent
pipeline timestamp remain outside this change. T03-S02 remains FAIL; 8 PASS / 1 FAIL /
21 BLOCKED unchanged. MAIN ONLY: do not hot-reload/restart/deploy active primary.
Next: downstream intent-clock contract and actual causal replay composition, then qualified
preregistered development baseline under explicit full-MTF observation/model boundaries.


## 2026-10-24 17:24 UTC — UTC instant freshness normalization

Main baseline 7bde6b7. Independent prior review identified timezone stripping and
host-local numeric conversion. Synthetic same-instant UTC/+02 case reproduced
RED 1 FAIL / 6 PASS. Freshness now compares aware clocks in UTC, uses explicit UTC
for existing epoch seconds/milliseconds path, and rejects naive/bool/nonfinite/invalid
values instead of guessing timezone. Equal wall-clock strings with different offsets
reject; same absolute instant accepts. Existing <5-second tolerance and missing-clock
fallback unchanged. Focused 7 PASS; selected isolated suite 297 PASS, 27 warnings;
independent review/run 7 PASS, REVIEW_PASS_WITH_LIMITATIONS, ACTIVATION_BLOCKED.
This MAIN-only correction affects live admission; active primary 958dbd7 and runner
session 99547 were not changed/restarted. Current primary log was updating, tail 100
had no errors; no broker snapshot or protection guarantee inferred.
Remaining limits: historical availability/candle provenance, downstream Signal clock
and full replay caller propagation; epoch-zero truthiness/modern-positive-ms heuristic
not generalized. T03-S02 remains FAIL and total 8 PASS / 1 FAIL / 21 BLOCKED unchanged.
Next task: explicit availability through research adapter and signal generation, retaining
live-clock behavior; no real economic outcomes before baseline/data gates.


## 2026-10-24 16:26 UTC — stale/future same-price freshness bypass

Main baseline 8c62064, primary remains 958dbd7 with five unrelated research dirties.
Actual extracted BaseStrategyAdapter._is_setup_fresh accepted an old setup solely
because trigger and close matched: RED 1 FAIL / 5 PASS. Minimal known-clock guard
now skips that price shortcut when both timestamps exist and uses the existing <5s
timestamp comparison. Synthetic old/future same-price cases reject; equal-time and
missing-clock legacy controls preserved. Selected isolated suite 296 PASS, 27 warnings;
additional compatibility-control focused run 6 PASS. Independent exact-diff review:
6 PASS, REVIEW_PASS_WITH_LIMITATIONS, ACTIVATION_BLOCKED. This is a MAIN code-only
correction affecting live admission semantics; active runtime source not changed.
Known preexisting limitations: timestamp normalizer strips timezone without converting
to UTC; numeric values use host-local conversion; candle-open vs availability meaning
is not qualified. No claim T03-S02 closed, no economic replay or outcomes opened.
Scenario counts remain 8 PASS / 1 FAIL / 21 BLOCKED. Next: correct timestamp normalization
and explicit historical availability propagation before end-to-end replay acceptance.
Primary log was updating at 16:27 UTC, last 100 lines had no ERROR/Traceback; this is
not current broker protection or trade proof. No broker request/restart/gate clearing.


## 2026-10-24 — explicit historical setup availability clock seam

Main baseline a04d1f6. Synthetic confirmed 2023-01-01 00:15 UTC setup request
could not provide a replay clock: RED 1 FAIL / 2 PASS. SetupEngine now accepts an
optional final available_at timezone-aware datetime and stamps generated candidates
with it, rejecting naive/string/numeric ambiguity. Omitting it preserves existing
live wall-clock behavior and positional callers. Actual focused GREEN 4 PASS;
independent exact-diff review/run 4 PASS, REVIEW_PASS_WITH_LIMITATIONS. An additional
legacy live-clock bounds control was then added; final selected clean credential-empty
network-denied suite 295 PASS, 27 warnings. No economic outcomes or runner-source changes.
The exact indicator-causality module was reviewed and added to the existing harness
allowlist; no transport or real adapter permission was expanded.
This is a prerequisite seam, NOT T03-S02 completion: adapter caller propagation,
signal timestamps, availability provenance and complete replay parity still unresolved.
No timestamp guessed from candle open or shifted by an assumed interval. Existing
seven packages/30 scenarios and 8 PASS / 1 FAIL / 21 BLOCKED unchanged. Next bounded
task: research replay caller passes explicit confirmed availability through setup and
signal paths, with missing-clock/future-access/monotonicity controls; keep live unchanged.


## 2026-10-23 — WFO multi-asset identity continuation

Following factory correction 2782e88, independent synthetic wrapper fixture showed
actual ETH/SOL keys becoming `data` before factory construction: RED 1 FAIL / 26 PASS.
Optional final constructor argument asset_symbol preserves positional compatibility;
MultiAssetHyperoptAdapter supplies its existing asset key, inner factory preserves it.
Direct callers without explicit identity retain legacy `data`, not guessed BTC;
instance evaluation without a valid asset therefore remains invalid, not certified.
Selected full credential-empty network-denied suite 290 PASS, 27 warnings. Fake fmin
does not call the objective; no economic outcome/optimization or runner source change.
Independent focused run 27 PASS, REVIEW_PASS_WITH_LIMITATIONS. Orchestrator still
labels optimizer callback inputs train_window_N; its public path requires a callable
strategy, so do not claim instance-based end-to-end WFO symbol compatibility. This
patch certifies actual symbol keys through MultiAssetHyperoptAdapter only.
Counts remain 8 PASS / 1 FAIL / 21 BLOCKED across exactly 30 acceptance scenarios.
Historical setup/strategy timestamps and qualified full-MTF baseline contract remain
explicit blockers; these synthetic identity corrections do not upgrade those verdicts.
Next safe work: propagate causal historical availability without changing live clock;
do not open economic baseline outcomes until its preregistered data/model gates pass.


## 2026-10-23 — offline optimizer per-asset identity correction

Main baseline ce4a5bb. Actual synthetic ETH/SOL factory run mislabeled every
strategy invocation BTC-USDT: RED 1 FAIL / 25 PASS. Factory now passes its actual
asset key into the metrics wrapper; direct legacy calls retain their default.
Selected credential-empty network-denied suite: 289 PASS, 27 warnings; independent
focused run 26 PASS, REVIEW_PASS_WITH_LIMITATIONS. Runtime primary source/process
untouched by this offline change; session 99547 remained alive when inspected.
No real economic outcome, fmin optimization, data collection or risk-policy change.
Important unresolved boundary: HyperoptAdapter wraps data under generic key `data`,
not an actual symbol. With strategy instances this now fails Symbol validation and
trial validity rather than pretending the asset is BTC. Explicit symbol propagation
through that adapter remains required before real instance-based WFO; no symbol
inference, fabricated BTC identity or full-WFO readiness claim. Scalar legacy wrapper
is also not covered. Existing seven packages/30 verdicts unchanged.


## 2026-10-22 13:49 UTC — finite optimizer objective validity

Inspected main c5c95b4 and primary 958dbd7; no new P0 external authorization or
runtime activation. Primary's five unrelated research modifications preserved.
Continued the explicitly identified T05 validity gaps without real outcomes:
empty asset population and missing/NaN/+infinity/-infinity requested objective
were all reported successful. Actual RED: 5 FAIL / 19 PASS. Bounded factory fix
rejects empty populations, absent/nonfinite requested metrics and nonfinite
aggregate loss using STATUS_FAIL; finite successful scoring/weights unchanged.
Initial focused isolated GREEN 24 PASS; after a dedicated two-asset synthetic
aggregation-overflow fixture, selected full allowlist 288 PASS, 27 warnings.
Independent initial focused run 24 PASS, REVIEW_PASS_WITH_LIMITATIONS; production
diff unchanged by the additional overflow fixture.
This is numerical trial admissibility, not parameter optimization or economic Edge.
An infinite Profit Factor may describe a no-loss sample mathematically, but is not
a finite rankable objective under this protocol; no cap or fabricated finite value
is substituted. Default extraction of absent backtester metrics and scalar legacy
objective remain outside this fix. Seven packages/30 acceptance verdicts unchanged.
Next: qualified baseline data/strategy contract; P0 remains separately gated by
authorized fresh broker exposure/protection evidence and supervised activation checks.


## 2026-10-22 11:50 UTC — failed optimizer trials cannot be ranked as successful

Main baseline 0f0cf79; primary inspected at 958dbd7 with its five unrelated research
modifications preserved. P0 activation remains externally gated; no broker request,
journal mutation, deployment or restart performed. Independent T05 fixture review
specified invalid copy/backtest/one-row evaluations must fail, not become sentinel scores.
Actual isolated RED: 3 FAIL / 15 PASS. Minimal fix adds an error marker to these
invalid metric paths and returns canonical Hyperopt STATUS_FAIL with infinite loss
before aggregation; outer factory errors also use STATUS_FAIL. Successful scoring
is unchanged, verified by a fixed dummy-metric control (loss -2.5, STATUS_OK).
Focused GREEN: 19 PASS; full selected credential-empty network-denied allowlist:
282 PASS, 27 warnings. No real strategy outcomes, economic optimization or new data.
Independent exact-diff review: REVIEW_PASS_WITH_LIMITATIONS; independent focused
isolated run 19 PASS, 27 warnings. Missing/nonfinite successful metrics remain outside
this patch's proof, alongside empty-universe validation.
The old numeric sentinel keys remain for legacy direct callers; this patch only
corrects factory trial validity. Scalar legacy objective and empty-universe handling
are not certified by these fixtures. Existing seven packages/30 scenarios and
economic acceptance verdicts unchanged. Next: qualified baseline/data contract
gates; P0 still needs fresh authorized authoritative exposure/protection evidence.


## 2026-10-22 06:12 UTC — optimizer cached-result mutation isolation

Main baseline 20ff0e5; primary still 8733cfb, P0 fresh broker scope not supplied.
Two synthetic fresh-result/cache-hit mutations changed cached nested parameters:
2 FAIL / 13 PASS. Minimum fix copies parameters at insertion and cache-hit return.
Full selected isolated suite 278 PASS, 27 warnings; independent focused 15 PASS,
REVIEW_PASS_WITH_LIMITATIONS. Fake fmin called once, objective never evaluated.
No real optimization, returns, market outcomes, risk-policy or runner changes.
Limit: direct public-cache mutation/custom deepcopy remains possible; insertion copy
failure retains existing exception handling, cache-hit copy failure propagates.
This closes only caller aliasing, not economic validation or universal optimizer safety.
Existing seven packages/30 acceptance scenarios unchanged. Next: qualified baseline
data/strategy contract gates and separately authorized P0 broker evidence.

## 2026-10-22 05:05 UTC — supplied strategy evaluation-state isolation

P0 primary remains 8733cfb; fresh broker GET-only scope still external, no calls made.
Independent T05 work: fixture_review specified two-row BUY/SELL expectations before
implementation. Both objective methods reused caller state: 2 FAIL / 7 PASS;
second evaluation changed synthetic signals from [1,-1] to [0,0]. Minimum offline
fix deep-copies supplied strategy instances per evaluation in both wrappers, rejecting
a copy returning the original. Four copy-failure/self-copy controls prove fake backtest
is never invoked. Functions/default paths unchanged; no production strategy edits.
Full selected isolated allowlist 276 PASS, 27 warnings. Independent focused 13 PASS,
REVIEW_PASS_WITH_LIMITATIONS. All metrics were fixed dummy values; no real backtest,
outcome inspection, fmin optimization, new data or risk-policy modification occurred.
Limits: external/global state and callable closures not universally isolated; parameter
application, symbol identity and complete WFO semantics remain unverified. Copy failures
retain existing penalty handling. No scenario upgraded to economic validation or Edge.
Next: existing qualified-data/baseline gates and P0 authorized broker evidence.

## 2026-10-22 04:10 UTC — independent Radar/WFO replay continuity

Actual main f0e7d07; primary 8733cfb with only five pre-existing research dirties.
P0 fresh GET-only broker audit remains authorization-gated; no new request executed.
Independent safe work: selected Radar, closed-bar-source, Hyperopt binding, WFO train-only
and rerun-isolation suites 25 PASS, 27 warnings under clean/network-denied harness.
Two credential-empty/socket-denied CLI replays of existing C06 at cutoff
2023-01-15T00:00:00+00:00 both emitted six observed-cohort rows with SHA-256
00e2826377d2fcd7cc89a906c37030b11026c6d0bf3f053a8a8fac49823c937d.
Temporary outputs /private/tmp/lynxion-radar-20261022-replay-{a,b}.json; no repository
dataset/output overwrites. Hash matches prior frozen replay; no new capability claim.
No outcomes, optimization, collection, broker queries, credentials or runtime changes.
Acceptance scenarios unchanged: repeatability is not Edge or full MTF strategy evidence.
Next: P0 external gate when authorized; continue existing offline data/evaluation gates.

## 2026-10-21 18:39 UTC — independent offline WFO gate check

Main baseline fbb8d84; primary remains 56fef14, unrelated dirty files preserved.
Selected objective-binding, train-only, rerun-isolation and CV-error tests:
13 PASS, 27 warnings, clean/network-denied isolation passed. No economic objective,
historical outcomes or optimization executed; no acceptance scenario promoted.
P0 candidate patches remain uninstalled under the deployment/activation gate.
Stateful objective strategy isolation remains outside these tests' proof scope;
do not claim cache correctness establishes independent fresh strategy state.
Next authorized work: exact target integration review and existing qualified-data gates.

## 2026-10-19 02:12 UTC continuation — optimizer context cache safety

Baseline `79bebf3`. Synthetic risk-change and mutable-strategy fixtures both reproduced
stale reuse: **2 FAIL / 5 PASS**. Minimum offline correction includes serialized risk
configuration in the cache fingerprint and bypasses reuse for supplied strategies/functions,
whose mutable state/closures cannot be established from identity alone. No risk values changed.
Combined credential-empty/network-denied suite: **164 PASS**, 27 warnings; no outcomes evaluated.
No deployment, broker access or protected research changes. No independent review claimed.
This does not establish reset of strategy state between actual objective evaluations.
P0 remains NO-GO pending runtime-source compatibility, authoritative broker reconciliation,
historical unknown handling and supervised activation gates. Next work: P0 compatibility first.

## 2026-10-19 01:04 UTC continuation — full training-data cache identity

Baseline `cd20d70`. Synthetic same-shape datasets with identical first ten rows but
different final values produced the same optimizer cache key: **1 FAIL / 4 PASS**.
Minimum fix hashes every row/index and column/dtype schema, not a displayed prefix.
Full credential-empty/network-denied allowlist: **162 PASS**, 27 warnings.
Diff check passed. No objective evaluation, broker access, deployment or frozen-artifact edit.
This proves the tested data-identity boundary only; mutable strategy/risk state in cached
optimization remains unverified. No independent review of this cache patch is claimed.
Next: verify cache reuse against changed risk/strategy state synthetically; P0 activation gates remain.

## 2026-10-18 21:09 UTC scheduled continuation — WFO constructor repaired

Baseline main `50deeef`; implementation `bf8bfc2`. Three synthetic construction/wiring
tests reproduced `NameError: HyperoptObjective is not defined`. The sole production change
imports the existing `infrastructure.optimization.hyperopt_objective.HyperoptObjective`.
No objective, search space, risk setting or strategy definition was changed. The tests never
evaluate an economic objective: factory/fmin/inner optimization calls are controlled fakes.
New and adjacent WFO modules: **22 PASS**, independently rerun with
REVIEW_PASS_WITH_LIMITATIONS. Combined main isolated allowlist: **160 PASS**, 27 warnings,
TEST_ISOLATION_PASS. Seven Pilot-2 hashes matched; runner remained stopped; no broker access.
The undefined-name constructor blocker is closed at source level. Real objective evaluation,
stateful strategy reset, qualified data/MTF baseline and holdout validity remain unproven.
Next: P0 restored-exit provenance/main compatibility; if externally gated, continue bounded
synthetic verification of existing optimizer state handling. Scenario economic gates remain.

## 2026-10-18 — verified local-main consolidation

This is the latest integration status. The older checkpoint tables below remain dated
evidence and are superseded for main-integration status by this section. Baseline actual
main was `e2c65fa`; no branch was merged wholesale across the 676-commit source divergence.

| Package | Source evidence | Actual main commit | Target verification | Activation |
| --- | --- | --- | --- | --- |
| P0 startup and Telegram | `d899cd3`, `1ef246e`, `41c04e0`, startup portion of `76cc8be`; existing main durability retained | `edc1154` | 71 credential-empty/network-denied tests PASS; independent review with limitations | NO |
| Causal offline replay | EPIC next-open, adverse-gap, explicit close-availability and provider-clock fixes through `92218ed` | `ab534c5` | 25 isolated tests PASS; independent review with limitations | NO |
| Observed-cohort Radar | `35971f6` and shared closed-bar dependency `7fe30d7` | `37b0566` | 15 isolated tests PASS; real six-row output hash reproduced | Research CLI only |
| Chronological train-only WFO | Existing EPIC calendar, training-slice, strategy/error and explicit-loader fixes | `f53e6fa` | 19 isolated tests PASS; independent review with limitations | Offline code only |
| Structural detector/opportunity assets | Exact research files from `aeab555` and `096885b` | `246c4ec` | 27 isolated tests PASS; contract and candidate hashes unchanged; independent review | Research asset only |

The combined main-target allowlist ran **157 PASS**, 27 warnings, with TEST_ISOLATION_PASS.
Command: `/Users/mojtaba.rahbari/.pyenv/versions/3.10.13/bin/python -B -c
'import runpy,sys; p="scripts/run_isolated_execution_tests.py"; d=runpy.run_path(p);
sys.argv=[p,*sorted(d["ALLOWED_TEST_FILES"])]; runpy.run_path(p,run_name="__main__")'`.
The separate configuration snapshot suite remains **2 FAIL / 3 PASS**; the identical result
was reproduced on untouched `e2c65fa` in an isolated temporary archive. Non-secret golden
values were not refreshed to hide these pre-existing failures.

Radar replay used only the existing C06 local panel at `2023-01-15T00:00:00+00:00`, yielding
six observed-cohort rows and SHA-256 `00e2826377d2fcd7cc89a906c37030b11026c6d0bf3f053a8a8fac49823c937d`.
Structural contract SHA-256 remains `abf0cb341ed54e068218aadb6ca5b16b28a7cb7484773e52fba542dec38a7300`;
candidate JSONL remains `260c987f232eb1036b90f736bc28d43179de309fbb577f22accc0ba7e40b9594`.
No candidates or economic outcomes were regenerated/opened during consolidation.

Still not merged: unreviewed risk/config worktrees; the runtime checkout's broader restored-exit
provenance path and platform-hardening diagnostics/timing candidates need separate main-target
compatibility tests. Main integration is not runtime deployment. Runner remains stopped.
The prior undefined `HyperoptObjective()` constructor blocker is fixed by `bf8bfc2` above.
Synthetic tests do not establish real optimizer economics. Full historical strategy clocks, MTF inputs and
independent holdout gates remain. The 30 scenario verdicts below are not promoted by code merge.
See the existing P0 board and canonical R01–R26 registry, now preserved in main.

## 2026-10-16 main integration checkpoint

- Actual `main` was `319d9ef`, 667 commits behind the active project checkout `task-00-ground-truth-audit` at `096885b`. This branch divergence must not be hidden when interpreting "merged to main".
- The bounded ambiguous-candle SL-priority fix `3f2c7f2` was cherry-picked to actual `main` as `698142f` in an isolated integration worktree. On that target, the credential-empty, socket-denied collision and short-lifecycle suite reported 5 PASS and 2 subtests PASS.
- The recorded signal/trade identity fix `42bb150` was reproduced red on actual `main` (1 fail/1 pass), ported without the EPIC-only board, and committed as `5bc4cdd`; the target suite reported 7 PASS and 2 subtests PASS.
- The `TrendMTFWatcher`/`trend_mtf` alias correction and exact cross-spelling duplicate guard were committed in this EPIC worktree as `6790acd` after independent `REVIEW_PASS_WITH_LIMITATIONS`. Cherry-pick to actual `main` resolved only the absent EPIC characterization file and created `c45c553`; a later no-double-vote Fusion decision fixture is `f5a8e98` on main. Target focused suite reported 11 PASS and 2 subtests PASS; EPIC focused suite reported 14 PASS. This changes source-level live signal admission; no runner deployment or runtime verification occurred. The fixture proves an alias pair alone remains NEUTRAL, not full deployed behavior.
- The remaining EPIC Backtester/WFO chain is not yet merged to the old `main` target; its source base and board/test dependencies need controlled per-fix integration and target tests. No after-cost baseline or WFO outcome has been run.
- The independent replay-clock guards from EPIC `c977f81` and `8acd274` were reproduced red on actual `main` (4 FAIL, 1 PASS), then ported together as main `27c3f8d`: conflicting or missing timestamp columns and duplicate/out-of-order index times now fail closed. Credential-empty, socket-denied target regression: 20 PASS + 2 subtests. This is not a candle-open/close availability fix and no baseline was run.
- The offline indicator-fill and ADX alignment corrections from EPIC `86344e2`/`478ebd6` were reproduced on actual `main`: the helper was absent and the pre-correction ADX fixture had 1 FAIL/1 PASS. Their bounded target port is main `63e9cd6`; credential-empty, socket-denied target suite reported **10 PASS + 2 subtests**. The backtest application no longer backward-fills early indicators or misaligns ADX on a DatetimeIndex. No economic replay or runner deployment followed.

| Fix | Isolated test | Actual `main` integration | Runtime activation | Runtime verification |
| --- | --- | --- | --- | --- |
| Ambiguous SL/TP candle → SL | EPIC synthetic PASS | `698142f`, target 5 PASS + 2 subtests | NO | NOT_MEASURED |
| Signal/trade identity across bars | EPIC red/green PASS | `5bc4cdd`, target 7 PASS + 2 subtests | NO | NOT_MEASURED |
| Ambiguous/duplicate replay bar clocks | EPIC synthetic PASS | `27c3f8d`, target 20 PASS + 2 subtests | NO | NOT_MEASURED |
| Historical indicator backfill / ADX alignment | EPIC 17 and 15 focused PASS | `63e9cd6`, target 10 PASS + 2 subtests | NO | NOT_MEASURED |
| Trend watcher alias/duplicate guard | EPIC 14 focused PASS; independent review with limitations | `c45c553` + `f5a8e98`, target 11 PASS + 2 subtests | NO; admission-change gate | NOT_MEASURED |
| Next-open/gap/clock Backtester and train-only WFO | EPIC focused synthetic suites PASS | NOT MERGED | NO | NOT_MEASURED |
| P0 durable INTENT/UNKNOWN/journal/reconciliation | P0 allowlisted fake-adapter suites and reviews with limitations; main-target 28 PASS | MERGED TO LOCAL MAIN as `f39928e`/`a2d3f29`; integration review pending | NO; execution-safety gate | NOT_MEASURED |
| Opportunity Radar read-only CLI | EPIC 10 PASS and six-row replay hash matched | NOT MERGED; research-only asset | NO | NOT_APPLICABLE |

Baseline `096885b`; branch `lynx/epic01-trading-v1`; isolated worktree `/Users/mojtaba.rahbari/.codex/worktrees/lynxion-epic-01-trading-v1/lynxion-ets`. No runtime deployment, broker access, new data, or frozen-research modification is authorized. Canonical research decisions remain in [R01–R26](../research/LYNXION_RESEARCH_BACKLOG.md); execution prerequisites remain in the separate P0 `POST_PILOT2_EXECUTION_RECOVERY_BOARD.md` worktree. A local accepted request is not a broker fill; offline correctness is not economic Edge.

## Work packages

| Package | Scope | Owner / worktree | Dependencies | Evidence | Implementation commit | Test result | Acceptance verdict | External gate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| T01 | Active-path and historical-data qualification | EPIC-01 / branch above | Existing files only | 5,150-row inventory; BTC spot panel and six-symbol Binance Futures 15m manifest/hash/source-code checks | `ab0d4dd`, `437c0c2`; current metadata audits | 2/2 inventory tests PASS; panel checks read-only | BLOCKED: independent holdout and runnable V1 path | Loader timeframe/index/coverage defects; separate holdout |
| T02 | Read-only watcher/screener/Radar shadow observations | EPIC-01 / branch above | T01; existing Radar asset | Existing commits cherry-picked unchanged; six-row replay hash matched | `dbdc44f`–`02643c7` | 10/10 Radar tests PASS | BLOCKED: watcher-port shadow wiring absent | Production behavior must stay unchanged |
| T03 | Watcher, Fusion, Strategy baseline behavior | EPIC-01 / branch above | T01 | Watcher alias corrected in source and main; historical event time and full Fusion trace still missing | `7b5eb7d`, `6790acd`; main `c45c553`, `f5a8e98` | Watcher-focused EPIC 14 PASS; main 11 PASS + 2 subtests | FAIL | Trading-admission runtime activation and historical clock correction remain gated |
| T04 | Up to three frozen plans and after-cost baseline backtests | EPIC-01 / branch above | T01–T03 | Three setup-family gaps; next-observed-open source correction, SL-priority, signal/trade identity, flat/add gap-crossed brackets and bar-clock guards | `3f2c7f2`, `42bb150`; current next-open, bracket and clock commits | Clock and adjacent offline suite 18 PASS, 2 subtests PASS | BLOCKED: no qualified plan run | Data timestamp/lineage qualification and remaining execution-model audit |
| T05 | Bounded Hyperopt and chronological WFO | EPIC-01 / branch above | T04 | Calendar split, train-only Hyperopt/CV, CV-error and explicit-timeframe/DatetimeIndex loader guards pass synthetic tests; C06 source panel is development-only | `7b5eb7d`, `90f9696`, `97db2ef`, `5c81844`, `524f23f`, `3a99f32`, `d31e025`; current loader fix | Eighteen focused WFO tests PASS; no real optimizer run | BLOCKED: qualified baseline and real-data replay | Frozen plan/cost model, development-only classification and separate holdout |
| T06 | Simulated execution and P0 gates | P0 worktree `d3e0ae8`; EPIC-01 read-only audit | P0 board; T03–T04 | P0 source reviews; local-main integration tests | Local main `f39928e`/`a2d3f29`, not this branch | Main isolation PASS; 28 PASS; separate historical LIVE guard expectation remains unresolved | BLOCKED | Independent integration review, global UNKNOWN admission, protective-order and runtime gates |
| T07 | Linked decision registry and release verdict | EPIC-01 / branch above | T01–T06 | Canonical R01–R26 linked; release separation below | This report's containing commit | 30 scenarios explicitly adjudicated | PASS for reporting; release NO-GO | No VST/live release by this epic |

## Acceptance scenarios (30)

`PASS` means the named deliverable is evidenced, not that the strategy has Edge. `FAIL` means a tested/source-confirmed defect violates the scenario. `BLOCKED` means a missing prerequisite prevents its acceptance; evidence is named below. No scenario is treated as passing because it has a document.

| ID | Named scenario | Outcome | Evidence |
| --- | --- | --- | --- |
| T01-S01 | Active strategy, watcher, Fusion and Regime composition inventoried | BLOCKED | Static source inventory exists; deployed active registrations and full composition not independently observed. |
| T01-S02 | Raw 1m per-symbol coverage and integrity quantified | PASS | 1,226 per-file rows in inventory JSONL; instrument tests 2/2. |
| T01-S03 | Processed MTF per-symbol coverage and resampling lineage quantified | BLOCKED | 3,924 per-file rows; processed-to-raw lineage cannot be verified from available provenance. |
| T01-S04 | Development, validation and holdout eligibility classified | BLOCKED | Prior-opened research is development-only; per-file independent holdout status remains unverified. |
| T02-S01 | Existing Radar and screener reuse proven | PASS | Research Radar commits reused unchanged; 10/10 tests; six-row replay hash reproduced. |
| T02-S02 | Movement observation remains read-only at watcher/screener boundary | BLOCKED | Research CLI is read-only but not wired to a watcher/screener port; no live integration authorized. |
| T02-S03 | Regime classification remains separate | PASS | No RegimeEngine, Strategy or Fusion production diff; Radar context remains a separate field. |
| T02-S04 | Causal timestamp, source and quality fields retained | PASS | Radar source/closed-bar tests and exact replay hash. |
| T02-S05 | Shadow output cannot alter trading selection or routing | PASS | Radar CLI has no broker, ExecutionIntent or production registration; separate research run. |
| T03-S01 | Watcher name/role mapping verified | PASS | Exact alias maps to existing DIRECTION role and 0.55 threshold; narrowly deduped cross-spelling identical observations. EPIC `6790acd`, main `c45c553` + no-double-vote test `f5a8e98`; independent `REVIEW_PASS_WITH_LIMITATIONS`; runtime NOT VERIFIED. |
| T03-S02 | Signal timestamp and freshness verified | FAIL | SetupEngine and strategy adapters stamp `datetime.now()` in historical path. |
| T03-S03 | Fusion agreement, HOLD and rejection reasons reported | BLOCKED | Prior incident has bounded neutral extract; complete baseline per-symbol trace not established. |
| T03-S04 | Strategy registration, defaults, thresholds and weights verified | BLOCKED | Design routing/source defaults inspected; runtime active set and all consumed thresholds not independently observed. |
| T03-S05 | Symbol isolation, intent suppression and cooldown verified | BLOCKED | No full isolated end-to-end decision replay; changing admission would affect trading behavior. |
| T04-S01 | Trend Pullback plan frozen from existing code | BLOCKED | `NGTREND_FOLLOW` is present; an explicit pullback/retest rule is not established. |
| T04-S02 | Breakout/Retest plan frozen from existing code | BLOCKED | `NGBREAKOUT` detects break, but no confirmed retest leg was found in its setup rule. |
| T04-S03 | Momentum Scalping plan frozen from existing code | BLOCKED | Existing `NGLS_SWEEP` is liquidity sweep, not proof of a momentum-scalping plan. |
| T04-S04 | Causal after-cost baseline backtests executed on qualified data | BLOCKED | Offline next-open/clock/bracket fixtures pass. Historical strategy/setup clocks still fail; C06 M15 OHLCV cannot independently supply the shared 5m OBI/CVD confirmation or 1m quote/POST_ONLY optimizer evidence, so its adapter defaults would be modeled rather than observed. No qualified after-cost baseline was run. |
| T04-S05 | Counts, expectancy, PF, drawdown, side, duration and rejections reported | BLOCKED | Requires a qualified T04-S04 run; metrics are NOT_MEASURED. |
| T05-S01 | Parameter spaces frozen before optimization output | BLOCKED | No causally qualified plan/baseline; optimization deliberately not started. |
| T05-S02 | Chronological WFO train/validation/test boundaries verified | BLOCKED | Outer WFO windows are half-open calendar-day windows. Outcome-free fake-adapter fixtures verify per-window Hyperopt/CV receive only supplied training slices. Inner-CV exceptions and error results now fail closed in synthetic tests; an actual qualified-data replay remains unverified. |
| T05-S03 | Evaluation budget and after-cost objective recorded | BLOCKED | Default max_evals=50 inspected, but no valid objective/run was executed. |
| T05-S04 | Holdout and overfit verdict explicitly qualified | BLOCKED | No untouched holdout proven; no optimization result to assess. |
| T06-S01 | Signal-to-intent simulated path verified | BLOCKED | P0 isolated suites are partial; no full EPIC replay admission evidence. |
| T06-S02 | Duplicate prevention and unknown outcome tested | BLOCKED | P0 fake-adapter tests exist, but global unknown-submission admission remains unproven. |
| T06-S03 | Protective-order semantics tested | BLOCKED | P0 source/fake tests do not establish authoritative deployed protective state. |
| T06-S04 | Journal, reconciliation and restart persistence tested | BLOCKED | P0 bounded tests passed in part; full end-to-end invariant and runner state remain unknown. |
| T06-S05 | No-lookahead deterministic replay and P0 gate retained | BLOCKED | Next-open synthetic replay and rebaselined synthetic golden are deterministic. Full timestamp provenance and gap-stop semantics are unverified; P0 runtime gate remains closed. |
| T07-S01 | Existing research IDs linked without verdict overwrite | PASS | Canonical R01–R26 registry linked; no source verdict rewritten. |
| T07-S02 | Release report separates correctness, performance, OOS, readiness and Edge | PASS | Current release separation section below; explicit NO-GO. |

## Initial evidence and scientific stop rules

- `application/configs/schemas/wfo.py` defaults to 90 training days, 30 testing days, 30-day step and 50 evaluations; the feature defaults to disabled. This is configuration, not evidence a valid WFO has run.
- `infrastructure/strategies/strategy_config.py` maps strategies to 1m, 5m, 15m or 1h design timeframes. The current HTF/LTF decision path still needs a runtime composition audit; no new production H1/M15 policy is implied.
- Local main-checkout raw and processed CSV examples encode ten-digit timestamps (seconds); `infrastructure/data/resample_engine.py` parses its input with `unit="ms"`. Their BTC date ranges also differ. Therefore processed files must **not** be assumed to descend from currently present raw files. This is a lineage/integration risk, not proof that every processed file is corrupt.
- File counts at initial read-only inventory: 1,226 raw 1m CSVs and 3,924 processed CSVs. Counts, size and row count alone do not establish usable closed-bar history or an untouched holdout. No backtest or optimization is eligible until T01 qualifies its exact inputs.
- Prior outcome-opened research is development-only for independent Edge claims. No existing file is presumed untouched merely from its name or modification time.

## T01 measured inventory and qualification (2026-10-15 UTC)

The read-only inventory command is:

```sh
python3 -B scripts/epic01_inventory_local_candles.py \
  --history-root /Users/mojtaba.rahbari/Sites/python/lynxion-ets/data/history \
  --cutoff-utc 2026-10-15T00:00:00Z \
  --output docs/engineering/LYNXION_EPIC_01_DATA_INVENTORY.jsonl
```

The JSONL companion is the per-symbol/per-timeframe inventory; every record includes source path, SHA-256, earliest/latest provisional UTC bar-open, rows, syntactically valid closed rows, gaps, duplicate and malformed bars, and timestamp unit. `lineage=UNVERIFIED` and `holdout_eligibility=UNVERIFIED` are deliberate. A syntactically valid closed row is **not** proof of exchange origin, bar-open convention, decision-time availability or scientific independence. The artifact intentionally contains no future returns or trade outcomes. Two complete runs over the same inputs produced byte-identical SHA-256 `f52e60a963ce74705b6f319715ce97b2423dd4e48ea1d74c48e35236b2a5e7aa` (5,150 rows).

The read-only scan over the main checkout found 5,150 files: 1,226 raw 1m and 654 each in processed 5m/15m/30m/1h/4h/1d. Raw 1m has 769 seconds-encoded and 457 milliseconds-encoded files; all processed files are seconds-encoded. There were no detected duplicate, out-of-order or invalid-OHLC rows in this scan, but 4,216 files had missing timestamp slots. Median processed span was about 181 days despite sparse rows; no gap-free processed file spanned the WFO default 90+30-day training/testing requirement. BTC raw 1m covered only 2026-08-02 09:03 through 2026-08-04 19:07 UTC with 922 missing minutes, whereas processed BTC 15m covered 2026-06-19 13:00 through 2026-07-19 13:00 UTC without timestamp gaps. These are different intervals and cannot be presumed one resampling lineage.

`CSVHistoryLoaderAdapter` interprets seconds-encoded files as UTC (`infrastructure/data/csv_history_loader.py`), while `ResampleEngine._prepare_df` unconditionally uses milliseconds. `DataSyncEngine` requests millisecond Binance data, but the present local files mix units and are not proven descendants of that path. The available `data/provenance/BTC-USDT_15m_provenance.json` labels source merely `CSV` and references a raw 15m file, not this processed 15m file. Its `date_range` is `1` to `1`, so it cannot establish exchange/time lineage for the processed BTC panel. This blocks production-quality baseline economic claims; no backtest was run on these CSVs.

A separate read-only BTCUSDT `data/research/spot_15m` qualification on 2026-10-16 found stronger but narrower lineage: its manifest identifies Binance **spot** daily 15m kline archives, and `scripts/fetch_binance_taker_flow_panel.py` explicitly derives `timestamp` from `open_time`, requires `close_time=open_time+899` seconds, excludes one partial source candle, and emits normalized rows sorted by open time. The present main-checkout BTC normalized row digest (header removed, CR stripped) matches manifest SHA-256 `dd81f6a4dc01fce15e284bbfea6ac7099ee96de939c3f9ce542d64548769687a`; the sampled 2023-01-01 raw archive matches listed SHA-256 `88c37bc65d7947ea0b9abaaee7a242698299bf1ac93cdf9b0bc318535077c569`. A timestamp-only scan found 128,346 rows, one gap event covering six 15m slots, and a longest contiguous run of 120,424 bars (about 1,254 days). This is **development-only spot-source evidence**, not a qualified VST perpetual baseline or untouched holdout: the panel was referenced by prior outcome-opening research, has `quote_volume` rather than the backtester's required base-volume field, and its spot prices/costs are not VST fills. No price outcome, forward return or PnL was inspected during this metadata check; no data were modified.

A separate read-only audit of `data/research/c06/binance_futures_15m` found a six-symbol **Binance USD-M futures** panel with 128,352 15m rows per symbol from 2023-01-01 to 2026-08-29. All six present CSV SHA-256 hashes match its manifest; the manifest reports zero missing intervals, duplicates, invalid OHLC and out-of-range rows. `scripts/fetch_aligned_futures_panel.py` records `row[0]` (kline open time) as UTC epoch seconds and writes base `volume`, so this is a stronger *development* candidate than the spot panel. It is still neither BingX VST execution evidence nor untouched holdout: prior C06/C14 and other outcome-opening scripts consumed this panel, and actual fees, spread, slippage and funding remain unproven for a VST baseline. Moreover, the current WFO loader defaults to `1d`, returns a numeric `timestamp` column with `RangeIndex`, and its minute-frame coverage calculation divides elapsed time by 60 seconds even for `15m`; the WFO splitter expects a `DatetimeIndex`. A direct WFO run on this panel would therefore be invalid or blocked. No price outcome, forward return or PnL was inspected, and no loader or frozen file was modified in this audit.

## T02–T06 bounded findings

- Existing Opportunity Radar V1 from research worktree commit `35971f6` was cherry-picked without modification into this isolated branch through `02643c7`; its CLI is read-only and labels the six-symbol historical panel `OBSERVED_COHORT_RANKING`, not a market-wide universe. Ten offline radar tests passed on this branch. The real development-only six-row replay at cutoff 2023-01-15 00:00 UTC reproduced SHA-256 `00e2826377d2fcd7cc89a906c37030b11026c6d0bf3f053a8a8fac49823c937d`. It has **not** been connected to a live watcher or strategy route, so production trading influence remains absent and watcher-boundary integration remains unverified. Declared MTF_TREND configuration remains 5m/15m/1h with 15m design routing; Radar's completed-H1 context is a separate research observation, not the production decision.
- `StrategyManager._register_default_strategies` enumerates ten adapters, while `StrategyConfig.get_strategy_enabled` currently always returns `True`. This proves a configuration/registration mismatch in source, not which constructors succeeded in a deployed runner. Correcting it can change trade selection and is not an implicit optimization.
- The prior Fusion incident [forensic record](../incidents/LYNXION_2026-10-07_FUSION_ETH_VST_FORENSICS.md) documents watcher-name/role mismatch and per-signal fusion calls; neutral event-bus output cannot be equated to absence of profitable opportunities. No acceptance or Fusion threshold change was made here.
- Existing `NGTREND_FOLLOW`, `NGBREAKOUT` and `NGLS_SWEEP` are concrete setup families. They do **not** by name prove the requested Trend Pullback, Breakout/Retest and Momentum Scalping economics: breakout has no independently verified retest rule here, and sweep scalping is not necessarily momentum scalping. `SetupEngine.scan_for_setups` and several strategy adapters stamp historical generated setups/signals with `datetime.now()`, not the replay bar's availability timestamp. This is a causal-timing blocker for trustworthy strategy backtests; no strategy or live MTF behavior was altered.
- Independent 2026-10-16 source audit: C06 `timestamp` is UTC **bar open**, while OHLC-derived setup information is available only at the closed-bar boundary. The backtest strategy provider feeds bar-open time into buffers and falls back to wall clock on invalid input; simply substituting it for `datetime.now()` would backdate a 15m decision. `SetupEngine` has 20 adapter call sites, and `_is_setup_fresh` may accept a same-close-price old setup before its timestamp check. Existing `CausalStrategyHistoryFeed` demonstrates a close-time availability convention. Until bar-open, availability, decision and fill clocks are separated and tested, T03-S02 and real T04 baselines remain blocked; no outcomes were opened to make this finding.
- `RealisticBacktester.run_backtest` previously handed the *current complete bar* to the strategy and executed its intent on that same bar. The offline source now queues the intent for the next observed bar's open, rechecks risk/cooldown at that open, uses only the signal bar's known volume for market impact, then evaluates stop/target against the execution bar's high/low. A final-bar intent remains unfilled. Flat/add entries whose original stop or target was already crossed at the next open are now rejected in offline replay rather than modeled with an invalid bracket; a four-case long/short synthetic fixture was red before correction and green afterward. Reversals and unqualified market-data timestamps remain separate limitations. Synthetic fee/SL and golden expectations were updated for the intentional timing change. This is source-level evaluation repair, **not** proof of bar-open/close exchange provenance, qualified data or economic Edge.
- A separate deterministic 15-minute fixture reproduced a false signal/trade correspondence failure: the validator's fixed five-minute proximity window ignored an explicitly recorded `signal_id` → trade link. A bounded offline backtester correction now accepts the recorded identity only when the linked trade is present in the supplied trade records; an unlinked later trade remains unmatched. Red then green tests passed. This removes one blocker for next-bar execution but **does not** change fill timing or make T04-S04 pass.
- The canonical `RealisticBacktester` previously selected whichever of SL/TP was nearer entry if both touched within one candle, despite its SL-priority comment. A synthetic long/short test reproduced TP selection, then the minimum offline backtester correction chose SL for both directions. The collision-specific and adjacent short-position suite passed under socket-denied, clean-env execution: 5 tests plus 2 subtests. This fixes only source-level replay semantics; historical economic results have **not** been recomputed.
- P0 isolated test harness self-test returned `TEST_ISOLATION_PASS`. Its six allowlisted suites were re-run: **44 passed, 1 failed**. The failure expects LIVE send despite the current BingX live-risk guard blocking it; the guard was not weakened. P0 worktree remains `9de6458`, not deployed. Broker-connected validation, unknown outcome, protection and runtime readiness remain open in its board.
- The read-only P0 protected-hash checker passed all seven frozen Pilot-2 targets in the original checkout: contract, activation, collector, supervisor, launchd file, readiness result and capture manifest. The main checkout's pre-existing C-11/C-35 dirty files were not changed by this epic.
- WFO schema labels `train_size=90`, `test_size=30`, `step_size=30` as days. The row/day mismatch was reproduced; the orchestrator and its `WalkForwardAnalyzer` explicitly select calendar-day mode while row-mode remains available for unrelated callers. Its half-open windows require a full observed boundary and unique timestamps. This does not certify gap-free data or produce an untouched test. An outcome-free fake-adapter test reproduced full-history CV/Hyperopt before WFO; the current offline source invokes both from the analyzer's per-window training callback and records window-specific parameters, with no global robust parameter claim. Inner-CV replay exceptions and error results no longer turn into neutral metrics or continued optimization. The zero-signal OOS placeholder was removed and the orchestrator fails before data loading without a real strategy function. Real qualified input and economic results remain unverified.
- Three networkless, outcome-free characterization tests pinned the original WFO row/day mismatch, watcher-name classification mismatch, and always-true strategy enable check. The WFO characterization still describes row-mode; the orchestrator's separate calendar-day mode has five passing acceptance tests. The Fusion and strategy-admission characterizations still document unresolved defects.

## Current release separation

Engineering correctness: bounded next-open timing, ambiguous-bar SL priority, WFO calendar-split, full-history pre-WFO optimization and inner-CV error-masking defects are corrected and regression-tested offline; watcher identity is corrected in source/main but not runtime-verified. Historical event-time/freshness and full Fusion decision evidence remain open, while source-qualified economic evaluation is blocked. The 30 scenarios now stand at **8 PASS, 1 FAIL, 21 BLOCKED**; PASS is not a deployment claim. Strategy baseline performance: `NOT_MEASURED`. Optimized in-sample performance: `NOT_MEASURED`. Untouched out-of-sample evidence: `NOT_ESTABLISHED`. Execution readiness: `BLOCKED_BY_P0`; no broker test or activation. Demonstrated economic Edge: `NOT_ESTABLISHED`. **V1 release decision: NO-GO.** A successful offline test, observed-cohort radar ranking, or a large CSV inventory is not evidence of after-cost profitability.

## Linked V1 decisions (canonical registry unchanged)

| V1 decision | Canonical mechanism / implementation | Prior evidence and economic verdict | Decision / reopening condition |
| --- | --- | --- | --- |
| V1-D01 | R22 extreme-mover opportunity; research-only Radar V1 | [R22](../research/LYNXION_RESEARCH_BACKLOG.md) is `EXTREME_MOVER_DATA_PARTIAL`; descriptive six-symbol replay has no economic outcome | Retain research asset; no market-wide or trading inference without point-in-time universe, executable costs and separate preregistration. |
| V1-D02 | R07 historical momentum versus requested Momentum Scalping plan | [R07](../research/LYNXION_RESEARCH_BACKLOG.md) closes tested C-14/C-15 mechanisms; `NGLS_SWEEP` is a different liquidity mechanism | Do not relabel sweep as momentum or retune opened R07 outcomes; a distinct plan would require explicit scientific definition and qualified data. |
| V1-D03 | Existing Trend Follow / Breakout setup families and canonical backtester | No V1 after-cost baseline or untouched holdout; ambiguous-bar SL priority was corrected offline | Keep plans unpromoted until causal timestamp/next-available execution, data lineage, plan semantics and costs are verified. |
| V1-D04 | R14 Lead A execution attribution | [R14](../research/LYNXION_RESEARCH_BACKLOG.md) remains `INSUFFICIENT_PROVENANCE`; P0 board records broker-truth gaps | No exit optimization; reopen only with joined authoritative mark/fill/order/route/clock evidence under P0. |

## Next bounded engineering order and external gates

1. Finish the bounded offline execution-model audit: qualify actual candle open/close availability and reversal-entry protective semantics. Conflicting index/column clocks now fail closed, flat/add gap-crossed brackets reject in synthetic replay, and an existing-position stop gap is priced at the worse open. Next-open cooldown correspondence is covered separately. These source corrections and the synthetic golden rebaseline are not data qualification or an economic result. Do not alter production strategy or risk policy.
2. Resolve Strategy/Setup replay timestamps. The calendar-vs-row outer split, full-history pre-WFO optimizer/CV leak and inner-CV error masking have bounded source corrections; a qualified-data replay remains necessary before any independent OOS interpretation. A correction that changes production signal admission or Fusion contributor counts requires a separate operator decision and independent execution review before deployment; source-only characterization is not that approval.
3. Use only explicit-timeframe, source-qualified input for any later development replay. The WFO loader now has synthetic coverage for 15m arithmetic, `DatetimeIndex` output and separate provenance output; no real C06 backtest or optimizer was run. The C06 Futures panel is source/hash-qualified for development characterization only, not BingX VST execution or untouched validation. Freeze an actually supported plan and cost model first; no download, collection, outcome opening or holdout relabeling. T04/T05 economic acceptance remains blocked.
4. Only then freeze any *actually supported* plan definitions and cost assumptions before opening baseline outcomes. Never invent a retest or momentum filter to force the requested three-plan count. Hyperopt/WFO follows only a valid baseline and chronological calendar splits.
5. P0 recovery remains the separate broker-connected prerequisite; this branch is not deployed. Any VST/live test, order, runner restart or trading-policy change is outside this epic's autonomous authority.

## Verification record

- 2026-10-18 P0 main integration: reviewed isolated corrections for flat-snapshot `UNKNOWN` status, pre-send INTENT durability, post-send uncertain outcome and lifecycle-write consistency were carried into the local `main` worktree as `f39928e` and `a2d3f29`. Main-specific red-then-green fault injection and the allowlisted credential-empty/network-denied suite yielded **28 PASS**; protected Pilot-2 hashes **7 PASS**. The main integration diff still needs its own independent review. `main` source is not the running checkout: no deployment, runner start, order, broker-fill proof or change to EPIC economic verdict followed. Global unknown-submission admission and conditional protective-order retry/identity remain P0 blockers; see the P0 board at `d3e0ae8`.

- 2026-10-16 local lower-timeframe metadata audit (no prices/outcomes): the six C06 Binance Futures M15 files each contain 128,352 contiguous open-time rows. Existing `history/micro/{1m,5m}` files cover only BTC/ETH/SOL for 2026-06-01 through 2026-07-15 18:59/18:55 UTC (64,500 1m and 12,900 5m rows per symbol, no timestamp gaps in these files). Their columns have OHLCV, trade counts and taker-buy volume, **not** true order-book OBI or best bid/ask; `scripts/fetch_microstructure.py` describes Binance Futures kline ingestion, but no inspected per-file source manifest binds these bytes to that invocation. Separate `history/raw/1m` C06-symbol files cover only short July/August segments with gaps and loader provenance `source: CSV`; `raw/5m` BTC/ADA have 864 January rows, while ETH/SOL/BNB/XRP have malformed timestamp strings. Therefore no local six-symbol, point-in-time 5m OBI plus 1m bid/ask panel was qualified. Do not treat taker-volume proxies or synthetic defaults as those observations, nor open economic outcomes to rescue coverage. T01-S03 and T04-S04 remain BLOCKED; next independent step is a strictly research-only setup baseline definition if the operator accepts explicit model assumptions, without changing live MTF admission.
- 2026-10-16 actual-family input gate (source audit, no outcomes): `NGTREND_FOLLOW`, `NGBREAKOUT` and `NGLS_SWEEP` call the shared `DecisionPipeline`. With an OHLCV-only latest bar it supplies direction-aligned synthetic OBI/CVD (`±0.15`, `±1.0`) to the 5m confirmation engine and derived bid/ask (`price ±0.01%`) to the 1m maker-first optimizer. These defaults satisfy the confirmation threshold and spread gate by construction; C06 is a 15m OHLCV panel, not independent 5m flow/1m quote evidence. Therefore an adapter-backed C06 run would model—not observe—those admission/execution gates. Do not label it an actual full-MTF strategy baseline or measured BingX fill. Next safe data task: inspect existing local 5m/1m provenance and synchronized coverage without downloading, then choose an explicitly modeled development-only setup baseline or report the missing gate; no production fallback/policy was changed.
- 2026-10-16 ADX index-alignment defect: a 100-bar synthetic DatetimeIndex fixture showed shifted `adx` remained `NaN` after warm-up because intermediate `pd.Series` objects had a RangeIndex and silently misaligned against the candle index (**1 FAIL**, prefix control PASS). The backtest application now preserves the candle index on the directional-movement and DX series. Credential-empty, socket-denied ADX, indicator-fill, closed-bar and provider-clock suite: **15 PASS**, including full-series prefix invariance. This repairs offline feature alignment, not strategy profitability or the separate historical SetupEngine clock; T04-S04 remains BLOCKED.
- 2026-10-16 indicator-fill lookahead: the `run_backtest` application path used `.ffill().bfill()` after shifting indicators, so an early warm-up row could receive a later indicator value. A bounded backtest-only correction removes backward filling while retaining the prior zero fallback for unavailable values; synthetic prefix and later-gap fixtures pass. Credential-empty, socket-denied adjacent suite: **17 PASS**. This is source-level causality repair, not a measured strategy result. Zero-fallback economic impact and the separate SetupEngine/adapter clock defect remain unverified; T04-S04 is still BLOCKED.
- 2026-10-16 explicit closed-bar availability seam: a synthetic M15 fixture first failed because a strategy saw no close-availability timestamp and could stamp an intent at the bar open. The offline backtester now accepts an explicit positive `bar_duration_seconds`, presents `open + duration` as the strategy observation timestamp, records signals at that availability time, rejects an intent backdated to the bar open, and refuses a next-open fill if the prior signal was not yet available. Missing/invalid durations are rejected when supplied. The backdated-intent fixture was independently red before its guard. Credential-empty, socket-denied adjacent backtest suite: **26 PASS**. This optional seam leaves legacy callers unchanged and is **not** a qualified C06 baseline: SetupEngine/adapter wall-clock stamps, provenance, cost assumptions and plan definition still require correction/verification; T03-S02 remains FAIL and T04/T05 remain BLOCKED.
- 2026-10-16 replay-provider clock guard: an independent synthetic fixture reproduced three cases in which a missing/invalid historical bar clock silently became `datetime.now()` (**3 FAIL**, 1 control PASS). The backtest-only strategy provider now rejects a non-datetime index without an explicit timestamp, `NaT` and invalid timestamps before strategy evaluation. Credential-empty, socket-denied provider, next-open and dual-clock suite: **13 PASS**. This prevents one wall-clock fallback but does **not** convert the C06 bar-open time to closed-bar availability or correct SetupEngine/adapter `datetime.now()` stamping; T03-S02 remains FAIL, T04/T05 remain BLOCKED and no outcome was opened. Next task: define/test a causal closed-bar availability clock without changing live strategy semantics.
- 2026-10-16 scheduled checkpoint: EPIC worktree `8618565` clean before inspection. Credential-empty, socket-denied next-available-fill, replay-clock and train-only WFO focused suite: **11 PASS** (27 non-failing deprecation/config warnings). Source recheck confirms `_is_setup_fresh` still accepts equal close price before historical timestamp validation; no live Strategy/Fusion change was made. Causal availability and plan-cost freeze remain the next tasks; economic baseline and runner activation remain blocked, with no outcomes or broker access opened.
- `python3 -B -m unittest tests.unit.test_epic01_inventory_local_candles -v`: 2 PASS.
- Red then green collision fixture: long and short both initially exited at TP; after minimal correction both exit at SL. Clean-env socket-denied adjacent short lifecycle suite: 5 PASS plus 2 subtests. Golden backtest fixture: 2 PASS.
- Clean-env socket-denied `tests.unit.test_epic01_evaluation_gate_characterization`: 3 PASS, **pinning defects**, not validating desired WFO/Fusion behavior.
- 2026-10-15 EPIC-01 follow-up: socket-denied, credential-empty pytest of calendar WFO, next-available execution, SL-collision and existing golden suites: **8 PASS, 1 XFAIL, 2 subtests PASS**. XFAIL is the independently specified bar-60-close 100 versus bar-61-open 110 causal execution defect; it is not a passing acceptance test. Five of the passing tests cover calendar windows and wiring. No real economic outcomes were opened.
- 2026-10-15 signal/trade identity follow-up: socket-denied red fixture had one failure for a linked trade 15 minutes after its signal; after the minimum identity correction, the focused two tests passed. Adjacent socket-denied identity, next-available, SL-collision and golden suite: **5 PASS, 1 XFAIL, 2 subtests PASS**. XFAIL is still the same-bar execution defect. No broker adapter or future outcome was used.
- 2026-10-15 train-only WFO gate: a network-denied, outcome-free three-row fixture reproduced an optimizer call on the unpartitioned history before outer WFO; the desired train-only assertion is **XFAIL**, not PASS. The optimizer was mocked, so no economic optimization or future result was opened. Next safe task: replace the full-data pre-WFO parameter path with per-window train-only optimization; keep T05 NO-GO until causal backtest and qualified data exist.
- 2026-10-15 WFO replay wiring: independent synthetic tests first failed 3/3, proving the analyzer ignored the supplied backtester/strategy and returned fabricated neutral metrics on error. The bounded offline correction now requires an explicit strategy, uses the supplied backtester where present, forwards the strategy into OOS replay, and propagates replay errors. Credential-empty, socket-denied focused suite: **8 PASS, 1 XFAIL**; the XFAIL still proves full-history optimization before WFO. No economic optimization or real outcome was run. T05-S02 remains FAIL and the epic remains NO-GO.
- 2026-10-15 missing-strategy gate: network-denied red fixture proved the orchestrator advanced to data loading and Hyperopt with no supplied strategy. It now returns an explicit error before either operation. Focused credential-empty, socket-denied suite: **9 PASS, 2 XFAIL**. The XFAILs are unchanged full-history optimization and same-bar execution, not accepted behavior. T05-S02 and T04-S04 remain FAIL; no economic result was opened.
- 2026-10-15 end-of-data execution fixture: a separate closed-candle synthetic case produced an accepted trade from an intent on the final bar, where no later executable bar exists. After correcting the assertion to inspect the backtester's actual trade counter, the isolated socket-denied suite reports **2 XFAIL** (same-bar price and last-bar orphan). This extends the causal correction's required behavior; it is not a runtime or economic validation and T04-S04 remains FAIL.
- 2026-10-15 repeated-WFO isolation: a synthetic fake-adapter test first failed because reusing one analyzer accumulated prior OOS results/windows and changed the reported consistency score. Resetting per-run state at invocation made the deterministic rerun equal. Credential-empty, socket-denied adjacent suite: **10 PASS, 3 XFAIL**; the unchanged XFAILs are full-history optimization, same-bar fill and last-bar orphan. No economic data or broker path was used. T05-S02 remains FAIL.
- 2026-10-16 zero-window WFO gate: a synthetic test first showed that an asset with no valid OOS window could be reported with zero-valued performance. The analyzer now raises an explicit no-window error instead; the existing calendar-mode wiring test was updated to expect it. Credential-empty, socket-denied adjacent suite: **11 PASS, 3 XFAIL**. This prevents one false report but does not fix train/test leakage or causal backtest fills; T05-S02 stays FAIL.
- 2026-10-16 next-open bracket audit: four synthetic BUY/SELL cases first reproduced accepted entries after the opening gap crossed their predeclared stop or target (**4 FAIL**). A bounded offline-only correction rejects flat/add intents in that condition; the credential-empty, socket-denied gap-bracket, next-available, existing-position gap-stop, collision and golden suite then reported **13 PASS, 2 subtests PASS**. Reversal entries and real exchange gap behavior remain unverified; no production trading behavior or economic outcome was changed.
- 2026-10-16 dual-clock replay audit: two synthetic cases first showed `_validate_data` accepting a timestamp column that disagreed with its `DatetimeIndex` or contained `NaT` (**2 FAIL**). The offline backtester now rejects these ambiguous clocks before replay; a matching-clock control and adjacent credential-empty, socket-denied suite report **16 PASS, 2 subtests PASS**. This does not establish whether any local CSV timestamp denotes candle open or close; numeric timestamp columns without explicit unit may now fail closed rather than being guessed.
- 2026-10-16 bar-order replay audit: two additional synthetic cases first showed the offline backtester accepting duplicate and reversed bar timestamps (**2 FAIL**). It now requires a unique, non-null, strictly increasing `DatetimeIndex`; the credential-empty, socket-denied clock and adjacent suite reports **18 PASS, 2 subtests PASS**. This is a causal-order guard, not source/exchange provenance or an economic result.
- 2026-10-16 train-only WFO repair: the formerly expected-failing fixture became a strict red test when a mock analyzer supplied only its first two of three rows; Hyperopt still received all three (**1 FAIL**). The offline orchestrator now calls Hyperopt and CV only inside each outer training-window callback. A second synthetic two-window case verifies separate two- and three-row inputs and window-specific parameters. Credential-empty, socket-denied adjacent WFO suite: **12 PASS**. No real optimization, after-cost result or holdout was opened; inner-CV error handling and qualified-data replay remain gates.
- 2026-10-16 inner-CV error gate: synthetic failures first showed replay exceptions converted into zero-return/one-PF metrics and orchestrator exceptions swallowed (**2 FAIL**). The offline CV engine now propagates replay errors, and the orchestrator also rejects explicit CV error results; credential-empty, socket-denied adjacent WFO suite: **15 PASS**. No actual CV, optimization or economic outcome on local history was run; qualified-data and cost gates remain.
- 2026-10-16 WFO loader repair: two synthetic tests first failed because the orchestrator used the loader's implicit daily/RangeIndex path and `CSVHistoryLoaderAdapter` could not route provenance outside the source directory (**2 FAIL**). The offline orchestrator now requires an explicit timeframe, asks for the datetime-indexed frame, and directs generated provenance to its results directory. The loader's minute-frame coverage arithmetic uses the declared interval rather than always one minute; a complete 96-bar synthetic 15m day is accepted without writing provenance into its input directory. Credential-empty, socket-denied adjacent WFO suite: **18 PASS**. No frozen input or real market outcome was changed or opened.
- 2026-10-16 next-observed-open repair: isolated source change queues closed-bar intents and executes at the next observed open using known prior-bar volume; final-bar intents remain unfilled, with separate signal/fill timestamps. The price fixture was corrected to inspect returned metrics rather than the cleared internal trade list. Updated short-entry fee/SL expectations and intentionally rebaselined the synthetic golden (367 trades versus old 368; no real outcomes). A second synthetic fixture verifies same-direction cooldown at fill time. Credential-empty, socket-denied adjacent backtest suite: **15 PASS, 2 subtests PASS**. Remaining blockers: unqualified candle timestamp/lineage, gap-stop pricing, WFO full-history optimizer leak and P0 broker/runtime gates. No live path changed.
- 2026-10-16 opening-gap stop repair: independent long/short fake-bar fixtures first failed because an existing stop crossed at the open was filled at the better trigger price (95 instead of 90 long; 105 instead of 110 short). The offline backtester now applies the worse opening price for such SL exits while retaining high/low and SL priority for intrabar hits. Credential-empty, socket-denied adjacent suite: **13 PASS, 2 subtests PASS**; the synthetic golden remains stable. This does not prove exchange fill behavior or authorize a baseline run. Crossed protective levels on a newly opened position and bar timestamp provenance remain unresolved.
- Clean-env `tests.unit.test_opportunity_radar_v1`: 10 PASS; six-row real observed-cohort replay output hash matched its prior handover.
- P0 separate worktree self-test `TEST_ISOLATION_PASS`; six allowlisted suites 44 PASS / 1 FAIL. P0 protected-hash checker 7/7 PASS. `git diff --check` PASS. No authenticated broker request, order, runner restart or deployment was made by EPIC-01.
