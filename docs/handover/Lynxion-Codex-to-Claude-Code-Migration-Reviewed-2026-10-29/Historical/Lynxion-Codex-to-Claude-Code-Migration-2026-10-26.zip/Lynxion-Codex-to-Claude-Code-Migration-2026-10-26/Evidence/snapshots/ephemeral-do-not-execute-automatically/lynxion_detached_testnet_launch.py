"""Explicit operator-directed launch; unchanged source/journals and safety gates."""
import os, subprocess, sys, json
from pathlib import Path
from datetime import datetime, timezone
root=Path('/Users/mojtaba.rahbari/Sites/python/lynxion-ets')
inventory=subprocess.run(['/bin/ps','-axo','pid=,command='],capture_output=True,text=True,check=True)
for line in inventory.stdout.splitlines():
    if 'run_trading_system.py' in line and 'python' in line.lower() and ' -c ' not in line:
        raise SystemExit('EXISTING_RUNNER_REFUSE_DUPLICATE')
env=dict(os.environ)
env.update(BINGX_TESTNET='true',BROKER_TESTNET='true',LIVE_TRADING='false',DEFAULT_BROKER='bingx',
           LIVE_ORDER_JOURNAL_PATH=str(root/'data/live_order_journal.json'))
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
log=root/'logs'/('runner-testnet-'+stamp+'.log')
with log.open('x') as output:
    process=subprocess.Popen([sys.executable,'-B','-u','run_trading_system.py','--mode','production','--auto-detect'],
        cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps({'pid':process.pid,'stdout_log':str(log),'source':'958dbd7','testnet_pinned':True}))
