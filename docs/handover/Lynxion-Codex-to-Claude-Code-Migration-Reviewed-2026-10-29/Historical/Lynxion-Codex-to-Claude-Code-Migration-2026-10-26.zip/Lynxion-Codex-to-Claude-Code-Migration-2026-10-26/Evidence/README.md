# Migration evidence / راهنمای شواهد انتقال

Generated 2026-10-26T12:06:15.794456+00:00. Main0649178 / primary958dbd7.
This is a redacted documentation snapshot, NOT a complete code/data backup or readiness certificate.
این پوشه آرشیو مستندات پاک‌سازی‌شده است؛ نه بکاپ کامل داده/کد و نه مجوز انتشار.

## Read first / ابتدا بخوانید

- ../Lynxion-Comprehensive-Handover-Codex-to-Claude-Code-English.md
- ../Lynxion-Comprehensive-Handover-Codex-to-Claude-Code-Persian.md
- snapshots/main/docs/engineering/POST_PILOT2_EXECUTION_RECOVERY_HANDOVER.md (latest top)
- snapshots/main/docs/engineering/POST_PILOT2_EXECUTION_RECOVERY_BOARD.md
- snapshots/main/docs/engineering/LYNXION_EPIC_01_TRADING_V1.md
- snapshots/main/docs/research/LYNXION_RESEARCH_BACKLOG.md
- snapshots/primary/docs/research/LYNXION_RESEARCH_TASK_BOARD.md
- snapshots/primary/docs/LYNXION_PROGRESS_LEDGER.md (older/current-task text may be stale)
- snapshots/main/docs/research/TRADING_INTELLIGENCE_VNEXT_BOARD.md
- snapshots/main/docs/research/OPPORTUNITY_RADAR_V1_HANDOVER.md

## Coverage / پوشش

1450 snapshots; 701 historical task Markdown snapshots, including nested task folders.
All discovered .md files under primary/main docs/tasks/research are included, excluding this generated output tree and symlinks.
Additional existing worktree board/backlog/handover/ledger/roadmap variants are preserved separately.
No raw CSV/JSONL cohort, full operational journal, .env, private raw chat, binary screenshots, or Git object database was exported.
Selected isolation harnesses and temporary helper scripts are documentation evidence only; do not auto-execute them.
The detached launch helper has a documented precheck sequencing defect and is NOT approved for reuse.
Some repository-relative links point to artifacts absent from a given checkout. See Document-Index.md and missing-or-skipped.json; do not invent missing evidence.

## Integrity / تمامیت

source-manifest.json records source paths, original/export SHA256 and redaction count.
Package-SHA256.json records generated package hashes (excluding itself and ZIP).
Snapshots may be redacted, so original and export hashes can differ. Redactions never modify the source.
Secret scan checks current local secret values and Telegram/private-key patterns; it is not a guarantee against every historical unknown secret.
Keep package local/private; do not treat it as approved for public publication.
Source MD reading/export is documentary only; no sealed data cohorts were parsed or outcomes recomputed.

## Status / وضعیت

No runner PID at11:55:33UTC; exact journal unknown still present at11:55:43UTC.
No fresh broker calls in report generation. Earlier11:36–11:39UTC VST visibility is dated.
No code/deployment/secret/journal/cohort changes or tests executed in report preparation.
Seven packages / thirty scenarios verified8PASS1FAIL21BLOCKED; R01–R26 complete.
Eleven DONE refers only to the historical outcome-blind research/documentation queue, not completion of Lynxion.
Existing Codex automation was NOT disabled or modified; explicitly transfer single ownership before autonomous Claude work.
