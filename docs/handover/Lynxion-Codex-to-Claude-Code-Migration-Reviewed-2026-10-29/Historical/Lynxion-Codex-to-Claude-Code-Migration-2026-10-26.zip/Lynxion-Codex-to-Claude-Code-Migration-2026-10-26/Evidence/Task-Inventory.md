# Historical task inventory / وظایف تاریخی

No status inferred from filename. Open each exact source; later dated canonical decisions supersede stale tasks. This retains all discovered nested task Markdown, not just top-level files.

| Checkout | Task document | First heading |
|---|---|---|
| primary | [tasks/00-Lynxion ETS - Start Codex.md](snapshots/primary/tasks/00-Lynxion ETS - Start Codex.md) | LYNXION — AUTONOMOUS ENGINEERING TAKEOVER |
| primary | [tasks/00-Lynxion ETS — Canonical Project Context & Engineering Handover.md](snapshots/primary/tasks/00-Lynxion ETS — Canonical Project Context & Engineering Handover.md) | Lynxion ETS — Canonical Project Context & Engineering Handover |
| primary | [tasks/00-right-path.md](snapshots/primary/tasks/00-right-path.md) | LYNXION — AUTONOMOUS SUPERVISOR DIRECTIVE |
| primary | [tasks/1k-event/research/external_signal_study/reports/EXTRACTION_REPORT.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/EXTRACTION_REPORT.md) | LYNXION EXTERNAL SIGNAL FORENSIC EXTRACTION REPORT |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2024-11.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2024-11.md) | LYNXION FORENSIC EXTRACTION REPORT — 2024-11 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2024-12.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2024-12.md) | LYNXION FORENSIC EXTRACTION REPORT — 2024-12 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-01.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-01.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-01 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-05.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-05.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-05 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-06.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-06.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-06 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-07.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-07.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-07 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-08.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-08.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-08 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-09.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-09.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-09 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-10.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-10.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-10 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-11.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-11.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-11 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-12.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2025-12.md) | LYNXION FORENSIC EXTRACTION REPORT — 2025-12 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2026-08.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2026-08.md) | LYNXION FORENSIC EXTRACTION REPORT — 2026-08 |
| primary | [tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2026-09.md](snapshots/primary/tasks/1k-event/research/external_signal_study/reports/monthly/EXTRACTION_REPORT_2026-09.md) | LYNXION FORENSIC EXTRACTION REPORT — 2026-09 |
| primary | [tasks/1k-event/research/external_signal_study/temporal_forensic_v2/manifests/v2_run_manifest.md](snapshots/primary/tasks/1k-event/research/external_signal_study/temporal_forensic_v2/manifests/v2_run_manifest.md) | Lynxion External Signal Temporal Evolution Forensic Review — V2 Run Manifest |
| primary | [tasks/1k-event/research/external_signal_study/temporal_forensic_v2/reports/LATEST_1K_EVENT_PROFILE.md](snapshots/primary/tasks/1k-event/research/external_signal_study/temporal_forensic_v2/reports/LATEST_1K_EVENT_PROFILE.md) | Lynxion External Signal Temporal Evolution Forensic Review — Latest 1K_EVENT Candidate Generation Profile |
| primary | [tasks/1k-event/research/external_signal_study/temporal_forensic_v2/reports/TEMPORAL_EVOLUTION_REPORT.md](snapshots/primary/tasks/1k-event/research/external_signal_study/temporal_forensic_v2/reports/TEMPORAL_EVOLUTION_REPORT.md) | Lynxion External Signal Temporal Evolution Forensic Review — Temporal Evolution Report |
| primary | [tasks/1k-event/research/external_signal_study/temporal_forensic_v2/reports/V2_DATA_QUALITY_REPORT.md](snapshots/primary/tasks/1k-event/research/external_signal_study/temporal_forensic_v2/reports/V2_DATA_QUALITY_REPORT.md) | Lynxion External Signal Temporal Evolution Forensic Review — Data Quality & Integrity Report |
| primary | [tasks/EPIC-EDGE-VALIDATION.md](snapshots/primary/tasks/EPIC-EDGE-VALIDATION.md) | Edge Validation & Profitability Program |
| primary | [tasks/epic-impls/task0045-profitability-root-cause-audit.md](snapshots/primary/tasks/epic-impls/task0045-profitability-root-cause-audit.md) | LYNXION ETS — PROFITABILITY ROOT CAUSE FORENSIC AUDIT |
| primary | [tasks/epic-impls/task0046-p1.1-causal-validation-report.md](snapshots/primary/tasks/epic-impls/task0046-p1.1-causal-validation-report.md) | LYNXION ETS — TASK0046: P1.1 CAUSAL VALIDATION & PRE-IMPLEMENTATION GATE |
| primary | [tasks/epic-impls/task0047-p1.1-post-implementation-verification-report.md](snapshots/primary/tasks/epic-impls/task0047-p1.1-post-implementation-verification-report.md) | P1.1 POST-IMPLEMENTATION VERIFICATION REPORT |
| primary | [tasks/epic-impls/task0048-p1.1-profitability-impact-forensic-analysis-report.md](snapshots/primary/tasks/epic-impls/task0048-p1.1-profitability-impact-forensic-analysis-report.md) | LYNXION ETS — TASK0048: P1.1 PROFITABILITY IMPACT & ROOT-CAUSE FORENSIC ANALYSIS |
| primary | [tasks/epic-impls/task0049-p1.2-trigger-exit-execution-forensic-verification-report.md](snapshots/primary/tasks/epic-impls/task0049-p1.2-trigger-exit-execution-forensic-verification-report.md) | LYNXION ETS — TASK0049: P1.2 TRIGGER-EXIT EXECUTION CAUSAL VERIFICATION |
| primary | [tasks/epic-impls/task0050-p1.3-position-sizing-loss-attribution-forensic-audit-report.md](snapshots/primary/tasks/epic-impls/task0050-p1.3-position-sizing-loss-attribution-forensic-audit-report.md) | LYNXION ETS — TASK0050: P1.3 POSITION SIZING & LOSS ATTRIBUTION FORENSIC AUDIT |
| primary | [tasks/epic-impls/task0051-p1.4-position-sizing-cap-bypass-root-cause-verification-report.md](snapshots/primary/tasks/epic-impls/task0051-p1.4-position-sizing-cap-bypass-root-cause-verification-report.md) | LYNXION ETS — TASK0051: P1.4 POSITION-SIZING CAP BYPASS ROOT-CAUSE VERIFICATION |
| primary | [tasks/epic-impls/task0052-p1.5-cooldown-enforcement-forensic-audit-report.md](snapshots/primary/tasks/epic-impls/task0052-p1.5-cooldown-enforcement-forensic-audit-report.md) | LYNXION ETS — TASK0052: P1.5 COOLDOWN ENFORCEMENT FORENSIC AUDIT |
| primary | [tasks/epic-impls/task0053-p1.6-cooldown-causal-attribution-fix-readiness-report.md](snapshots/primary/tasks/epic-impls/task0053-p1.6-cooldown-causal-attribution-fix-readiness-report.md) | LYNXION ETS — TASK0053: P1.6 COOLDOWN CAUSAL ATTRIBUTION & FIX READINESS REPORT |
| primary | [tasks/epic-impls/task0054-p1.7-position-sizing-cooldown-control-audit-report.md](snapshots/primary/tasks/epic-impls/task0054-p1.7-position-sizing-cooldown-control-audit-report.md) | LYNXION ETS — TASK0054: P1.7 POSITION SIZING & COOLDOWN CONTROL FORENSIC AUDIT |
| primary | [tasks/epic-impls/task0055-p1.8-risk-manager-instantiation-dataset-reconciliation-report.md](snapshots/primary/tasks/epic-impls/task0055-p1.8-risk-manager-instantiation-dataset-reconciliation-report.md) | LYNXION ETS — TASK0055: P1.8 RISK MANAGER INSTANTIATION & DATASET RECONCILIATION REPORT |
| primary | [tasks/epic-impls/task0056-p1.9-position-sizing-cooldown-control-closure-audit.md](snapshots/primary/tasks/epic-impls/task0056-p1.9-position-sizing-cooldown-control-closure-audit.md) | LYNXION ETS — TASK0056: P1.9 POSITION SIZING & COOLDOWN CONTROL CLOSURE AUDIT |
| primary | [tasks/epic-impls/task0057-p2-cooldown-remediation-report.md](snapshots/primary/tasks/epic-impls/task0057-p2-cooldown-remediation-report.md) | LYNXION ETS — TASK0057: P2 COOLDOWN CONTROL REMEDIATION REPORT |
| primary | [tasks/epic-impls/task0058-p2-post-remediation-forensic-validation.md](snapshots/primary/tasks/epic-impls/task0058-p2-post-remediation-forensic-validation.md) | LYNXION ETS — TASK0058: P2 POST-REMEDIATION FORENSIC VALIDATION REPORT |
| primary | [tasks/epic-impls/task0059-residual-profitability-forensic-audit.md](snapshots/primary/tasks/epic-impls/task0059-residual-profitability-forensic-audit.md) | LYNXION ETS — TASK0059: RESIDUAL PROFITABILITY FORENSIC AUDIT REPORT |
| primary | [tasks/epic-impls/task0060-exit-management-forensic-audit.md](snapshots/primary/tasks/epic-impls/task0060-exit-management-forensic-audit.md) | LYNXION ETS — TASK0060: EXIT MANAGEMENT FORENSIC AUDIT REPORT |
| primary | [tasks/epic-impls/task0060-strategy-strictness-advisory-report.md](snapshots/primary/tasks/epic-impls/task0060-strategy-strictness-advisory-report.md) | LYNXION ETS — STRATEGY STRICTNESS AUDIT & ADVISORY REPORT |
| primary | [tasks/epic-impls/task0061-residual-edge-forensic-audit.md](snapshots/primary/tasks/epic-impls/task0061-residual-edge-forensic-audit.md) | LYNXION ETS — TASK0061: RESIDUAL EDGE FORENSIC AUDIT REPORT |
| primary | [tasks/epic-impls/task0062-controlled-regime-forensic-validation.md](snapshots/primary/tasks/epic-impls/task0062-controlled-regime-forensic-validation.md) | LYNXION ETS — TASK0062: CONTROLLED REGIME FORENSIC VALIDATION & OUT-OF-SAMPLE STABILITY AUDIT |
| primary | [tasks/epic-impls/task0063-prospective-forward-validation-gate.md](snapshots/primary/tasks/epic-impls/task0063-prospective-forward-validation-gate.md) | LYNXION ETS — TASK0063: PROSPECTIVE FORWARD VALIDATION GATE REPORT |
| primary | [tasks/epic-impls/task0064-p3-prospective-validation-report.md](snapshots/primary/tasks/epic-impls/task0064-p3-prospective-validation-report.md) | LYNXION ETS — TASK0064: P3 PROSPECTIVE FORWARD VALIDATION REPORT |
| primary | [tasks/epic-impls/task0065-prospective-validation-gate-execution.md](snapshots/primary/tasks/epic-impls/task0065-prospective-validation-gate-execution.md) | LYNXION ETS — TASK0065: PROSPECTIVE VALIDATION GATE EXECUTION REPORT |
| primary | [tasks/epic-impls/task0066-prospective-validation-execution-log.md](snapshots/primary/tasks/epic-impls/task0066-prospective-validation-execution-log.md) | LYNXION ETS — TASK0066: PROSPECTIVE VALIDATION EXECUTION LOG & AUDIT |
| primary | [tasks/epic-impls/task0067-prospective-validation-checkpoint1.md](snapshots/primary/tasks/epic-impls/task0067-prospective-validation-checkpoint1.md) | LYNXION ETS — TASK0067: PROSPECTIVE VALIDATION CHECKPOINT #1 REPORT |
| primary | [tasks/epic-impls/task0068-prospective-validation-checkpoint2.md](snapshots/primary/tasks/epic-impls/task0068-prospective-validation-checkpoint2.md) | LYNXION ETS — TASK0068: PROSPECTIVE VALIDATION CHECKPOINT #2 REPORT |
| primary | [tasks/epic-impls/task0069-prospective-execution-start-diagnostic.md](snapshots/primary/tasks/epic-impls/task0069-prospective-execution-start-diagnostic.md) | LYNXION ETS — TASK0069: PROSPECTIVE VALIDATION EXECUTION-START DIAGNOSTIC REPORT |
| primary | [tasks/epic-impls/task0070-passive-prospective-monitoring-log.md](snapshots/primary/tasks/epic-impls/task0070-passive-prospective-monitoring-log.md) | LYNXION ETS — TASK0070: PASSIVE PROSPECTIVE MONITORING LOG |
| primary | [tasks/epic-impls/task0071-validation-liveness-zero-trade-investigation.md](snapshots/primary/tasks/epic-impls/task0071-validation-liveness-zero-trade-investigation.md) | LYNXION ETS — TASK0071: VALIDATION LIVENESS & ZERO-TRADE INVESTIGATION REPORT |
| primary | [tasks/epic-impls/task0072-validation-hard-runtime-evidence.md](snapshots/primary/tasks/epic-impls/task0072-validation-hard-runtime-evidence.md) | LYNXION ETS — TASK0072: HARD RUNTIME EVIDENCE INVESTIGATION REPORT |
| primary | [tasks/epic-impls/task0073-heartbeatguard-forensic-audit.md](snapshots/primary/tasks/epic-impls/task0073-heartbeatguard-forensic-audit.md) | LYNXION ETS — TASK0073: HEARTBEATGUARD FORENSIC AUDIT & ROOT-CAUSE INVESTIGATION REPORT |
| primary | [tasks/epic-impls/task0074-heartbeatguard-remediation-design.md](snapshots/primary/tasks/epic-impls/task0074-heartbeatguard-remediation-design.md) | LYNXION ETS — TASK0074: HEARTBEATGUARD REMEDIATION DESIGN & VALIDATION IMPACT REPORT |
| primary | [tasks/epic-impls/task0075-heartbeatguard-remediation-implementation.md](snapshots/primary/tasks/epic-impls/task0075-heartbeatguard-remediation-implementation.md) | LYNXION ETS — TASK0075: HEARTBEATGUARD REMEDIATION IMPLEMENTATION REPORT |
| primary | [tasks/epic-impls/task0076-live-heartbeat-liveness-audit.md](snapshots/primary/tasks/epic-impls/task0076-live-heartbeat-liveness-audit.md) | LYNXION ETS — TASK0076: POST-REMEDIATION LIVE HEARTBEAT LIVENESS AUDIT REPORT |
| primary | [tasks/epic-impls/task0077-prospective-attribution-integrity.md](snapshots/primary/tasks/epic-impls/task0077-prospective-attribution-integrity.md) | TASK0077 — Prospective Attribution Integrity |
| primary | [tasks/f01_offline_risk_sizing_verification.md](snapshots/primary/tasks/f01_offline_risk_sizing_verification.md) | F01 — offline intent-to-order risk-sizing verification |
| primary | [tasks/old/IN+PROGRESS.md](snapshots/primary/tasks/old/IN+PROGRESS.md) | Audit Report on Performance Metric Validity & Empirical Provenance |
| primary | [tasks/old/In-progress-FOR-GPT.md](snapshots/primary/tasks/old/In-progress-FOR-GPT.md) | 1. IS SymbolHealthState EPHEMERAL OR PERSISTED? |
| primary | [tasks/old/Prompt 1 — SEV-1 Incident Root Cause Elimination (Highest Priority).md](snapshots/primary/tasks/old/Prompt 1 — SEV-1 Incident Root Cause Elimination (Highest Priority).md) | Lynxion ETS – SEV-1 Critical Incident: Unauthorized Order Placement & Missing Stop-Loss Elimination |
| primary | [tasks/old/Prompt 2 — Final Phase 2 Completion Audit & Production Readiness.md](snapshots/primary/tasks/old/Prompt 2 — Final Phase 2 Completion Audit & Production Readiness.md) | Lynxion ETS – Final Phase 2 Completion Audit |
| primary | [tasks/old/TP+SL.md](snapshots/primary/tasks/old/TP+SL.md) | Lynxion ETS — Phase 3.1 |
| primary | [tasks/old/evaluates/evaluate-part1.md](snapshots/primary/tasks/old/evaluates/evaluate-part1.md) | Observed Problems From Live Trading Analysis |
| primary | [tasks/old/fixed.prompt.p1,2,3.md](snapshots/primary/tasks/old/fixed.prompt.p1,2,3.md) | Lynxion ETS – SEV-1 Production Incident Reconstruction |
| primary | [tasks/old/future_bug_fixes_roadmap.md](snapshots/primary/tasks/old/future_bug_fixes_roadmap.md) | Future Bug Fixes & Performance Optimization Roadmap |
| primary | [tasks/old/in-progress.md](snapshots/primary/tasks/old/in-progress.md) | Executive Verification Summary |
| primary | [tasks/old/market+shuck.md](snapshots/primary/tasks/old/market+shuck.md) | Research Prompt – Portfolio-Level Shock Protection (Future Phase) |
| primary | [tasks/old/part1/0task80-momentum-spike-watcher/task80-momentum-spike-watcher.md](snapshots/primary/tasks/old/part1/0task80-momentum-spike-watcher/task80-momentum-spike-watcher.md) | ✅ FINAL SCRIPT |
| primary | [tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-01-target.md](snapshots/primary/tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-01-target.md) | 1️⃣ Where do the initial parameters come from when starting live trading? |
| primary | [tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-02-confirmation.md](snapshots/primary/tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-02-confirmation.md) | 🧠 Mental Model (Read This First) |
| primary | [tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-03-lifecycle-mamangement-code-sample.md](snapshots/primary/tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-03-lifecycle-mamangement-code-sample.md) | 🧠 FINAL PROMPT (Implementation / Handoff Prompt) |
| primary | [tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-backtest-to-paper-trading.md](snapshots/primary/tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-backtest-to-paper-trading.md) | 🎯 Final Objective |
| primary | [tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-dynamic-parameter-lifecycle-management-complete-task.md](snapshots/primary/tasks/old/part1/0task86-dynamic-parameter-lifecycle-management/task86-dynamic-parameter-lifecycle-management-complete-task.md) | 🚀 TASK 81: Dynamic Parameter Lifecycle Management System |
| primary | [tasks/old/part1/task100-sl-tp-governence-forensic-optimization.md](snapshots/primary/tasks/old/part1/task100-sl-tp-governence-forensic-optimization.md) | 1️⃣ Forensic logging is inactive (`forensic.log` is empty) |
| primary | [tasks/old/part1/task101-confidence-survivability-and-risk-integrity.md](snapshots/primary/tasks/old/part1/task101-confidence-survivability-and-risk-integrity.md) | INPUT |
| primary | [tasks/old/part1/task102-.env-optimization[NEW-BRANCH].md](snapshots/primary/tasks/old/part1/task102-.env-optimization[NEW-BRANCH].md) | Professional .env Refactor & Governance Prompt (Hedge-Fund Grade) |
| primary | [tasks/old/part1/task103-env-enhancement-part2.md](snapshots/primary/tasks/old/part1/task103-env-enhancement-part2.md) | Hedge-Fund Grade `.env` → Central Config Migration & Project-Wide Refactor |
| primary | [tasks/old/part1/task103-env-enhancement-part3.md](snapshots/primary/tasks/old/part1/task103-env-enhancement-part3.md) | 🔒 FINAL LOCKED PROMPT |
| primary | [tasks/old/part1/task103-env-enhancement-part4.md](snapshots/primary/tasks/old/part1/task103-env-enhancement-part4.md) | (no heading) |
| primary | [tasks/old/part1/task103-env-enhancement.md](snapshots/primary/tasks/old/part1/task103-env-enhancement.md) | 🏦 Hedge-Fund Configuration Architecture & `.env` Governance Prompt |
| primary | [tasks/old/part1/task103-recheck-and-finalize-env-to-config.md](snapshots/primary/tasks/old/part1/task103-recheck-and-finalize-env-to-config.md) | CRITICAL EXECUTION REALITY RULE |
| primary | [tasks/old/part1/task104-backtest-optimization-part0.md](snapshots/primary/tasks/old/part1/task104-backtest-optimization-part0.md) | 🟢 BASELINE BACKTEST VALIDATION PROMPT |
| primary | [tasks/old/part1/task104-backtest-optimization-part00.md](snapshots/primary/tasks/old/part1/task104-backtest-optimization-part00.md) | 🟢 BASELINE BACKTEST VALIDATION PROMPT |
| primary | [tasks/old/part1/task104-backtest-optimization-part1.md](snapshots/primary/tasks/old/part1/task104-backtest-optimization-part1.md) | 🧠 FINAL ARCHITECTURE-AWARE AUDIT PROMPT (Evidence-Based) |
| primary | [tasks/old/part1/task104-backtest-optimization-part2.md](snapshots/primary/tasks/old/part1/task104-backtest-optimization-part2.md) | ✅ FINAL PROMPT — Hyperopt-Ready Backtest Hardening (Corrected) |
| primary | [tasks/old/part1/task104-backtest-optimization-part3.md](snapshots/primary/tasks/old/part1/task104-backtest-optimization-part3.md) | ✅ PRE-HYPEROPT TRADE DENSITY & SIGNAL QUALITY PROMPT |
| primary | [tasks/old/part1/task104-backtest-optimization-part4.md](snapshots/primary/tasks/old/part1/task104-backtest-optimization-part4.md) | ✅ FINAL BASELINE PROMPT — BACKTEST EXECUTION ALIGNMENT (PRE-HYPEROPT) |
| primary | [tasks/old/part1/task104-backtest-optimization-part5.md](snapshots/primary/tasks/old/part1/task104-backtest-optimization-part5.md) | 🔑 Clear answer (no ambiguity) |
| primary | [tasks/old/part1/task105-strategies-alignment-before-after-changes.md](snapshots/primary/tasks/old/part1/task105-strategies-alignment-before-after-changes.md) | 2️⃣ What this result definitively proves (no speculation) |
| primary | [tasks/old/part1/task105-strategies-alignment-part1.md](snapshots/primary/tasks/old/part1/task105-strategies-alignment-part1.md) | ✅ STRATEGY → EXECUTIONINTENT MINIMAL BRIDGE PROMPT |
| primary | [tasks/old/part1/task105-strategies-alignment.md](snapshots/primary/tasks/old/part1/task105-strategies-alignment.md) | 🔴 IMPORTANT ALIGNMENT (READ ONCE) |
| primary | [tasks/old/part1/task37-flow-tuning/COMPREHENSIVE-ANALYSIS-PRO.1.0.md](snapshots/primary/tasks/old/part1/task37-flow-tuning/COMPREHENSIVE-ANALYSIS-PRO.1.0.md) | COMPREHENSIVE ANALYSIS REPORT - PROJECT OVERVIEW |
| primary | [tasks/old/part1/task37-flow-tuning/COMPREHENSIVE-ANALYSIS-STRATEGIES.1.0.md](snapshots/primary/tasks/old/part1/task37-flow-tuning/COMPREHENSIVE-ANALYSIS-STRATEGIES.1.0.md) | COMPREHENSIVE ANALYSIS REPORT - STRATEGIES SYSTEM |
| primary | [tasks/old/part1/task37-flow-tuning/COMPREHENSIVE-ANALYSIS-WATCHERS.1.0.md](snapshots/primary/tasks/old/part1/task37-flow-tuning/COMPREHENSIVE-ANALYSIS-WATCHERS.1.0.md) | COMPREHENSIVE ANALYSIS REPORT - WATCHERS SYSTEM |
| primary | [tasks/old/part1/task37-flow-tuning/requests.md](snapshots/primary/tasks/old/part1/task37-flow-tuning/requests.md) | All Critical Rules Implemented |
| primary | [tasks/old/part1/task49-decision-flow-audit.md](snapshots/primary/tasks/old/part1/task49-decision-flow-audit.md) | Decision Flow, Strategy Ownership & Architecture Audit |
| primary | [tasks/old/part1/task74-audit-flows.md](snapshots/primary/tasks/old/part1/task74-audit-flows.md) | 1 — Watcher Audit |
| primary | [tasks/old/part1/task84-env-to-config.md](snapshots/primary/tasks/old/part1/task84-env-to-config.md) | 🎯 Design Goals |
| primary | [tasks/old/part1/task85-backtest-to-paper-trading.md](snapshots/primary/tasks/old/part1/task85-backtest-to-paper-trading.md) | 🎯 Final Objective |
| primary | [tasks/old/part1/task87-comprehensive-backtest-finalization-part2.md](snapshots/primary/tasks/old/part1/task87-comprehensive-backtest-finalization-part2.md) | Comprehensive Backtest Finalization for All Strategies |
| primary | [tasks/old/part1/task87-comprehensive-backtest-finalization-part3.md](snapshots/primary/tasks/old/part1/task87-comprehensive-backtest-finalization-part3.md) | Comprehensive Backtest Finalization for All Strategies |
| primary | [tasks/old/part1/task87-comprehensive-backtest-finalization-part4.md](snapshots/primary/tasks/old/part1/task87-comprehensive-backtest-finalization-part4.md) | Comprehensive Backtest Finalization for All Strategies |
| primary | [tasks/old/part1/task87-comprehensive-backtest-finalization.md](snapshots/primary/tasks/old/part1/task87-comprehensive-backtest-finalization.md) | Comprehensive Backtest Finalization for All Strategies |
| primary | [tasks/old/part1/task88-comprehensive-backtest-finalization-part5.md](snapshots/primary/tasks/old/part1/task88-comprehensive-backtest-finalization-part5.md) | Comprehensive Backtest Finalization for All Strategies |
| primary | [tasks/old/part1/task89-institutional-production-readiness-part2.md](snapshots/primary/tasks/old/part1/task89-institutional-production-readiness-part2.md) | Comprehensive Backtest Finalization for All Strategies |
| primary | [tasks/old/part1/task89-institutional-production-readiness.md](snapshots/primary/tasks/old/part1/task89-institutional-production-readiness.md) | Comprehensive Backtest Finalization for All Strategies |
| primary | [tasks/old/part1/task90-institutional-production-checking-and-cleanup.md](snapshots/primary/tasks/old/part1/task90-institutional-production-checking-and-cleanup.md) | (no heading) |
| primary | [tasks/old/part1/task91-runner-comperhensive.md](snapshots/primary/tasks/old/part1/task91-runner-comperhensive.md) | (no heading) |
| primary | [tasks/old/part1/task92-address-the-issues.md](snapshots/primary/tasks/old/part1/task92-address-the-issues.md) | 🏛 INSTITUTIONAL INTERPRETATION OF YOUR RESULT |
| primary | [tasks/old/part1/task93-pre-forensic-optimization-phase-part2.md](snapshots/primary/tasks/old/part1/task93-pre-forensic-optimization-phase-part2.md) | 🎯 PURPOSE |
| primary | [tasks/old/part1/task93-pre-forensic-optimization-phase-part3.md](snapshots/primary/tasks/old/part1/task93-pre-forensic-optimization-phase-part3.md) | Institutional Review Response — Pre-Forensic Phase Claim |
| primary | [tasks/old/part1/task93-pre-forensic-optimization-phase-part4.md](snapshots/primary/tasks/old/part1/task93-pre-forensic-optimization-phase-part4.md) | 🔹 FINAL PROMPT — PRE-FORENSIC INSTITUTIONAL COMPLETION AUDIT |
| primary | [tasks/old/part1/task93-pre-forensic-optimization-phase.md](snapshots/primary/tasks/old/part1/task93-pre-forensic-optimization-phase.md) | 🔹 Logging Prompt — Pre-Forensic Optimization Phase |
| primary | [tasks/old/part1/task94-pre-forensic-force-to-code-part2.md](snapshots/primary/tasks/old/part1/task94-pre-forensic-force-to-code-part2.md) | Reality Check From Your Logs |
| primary | [tasks/old/part1/task94-pre-forensic-force-to-code-part3.md](snapshots/primary/tasks/old/part1/task94-pre-forensic-force-to-code-part3.md) | 🎯 ADVANCED FORENSIC PROMPT — STRATEGY FILTERING GOVERNANCE |
| primary | [tasks/old/part1/task94-pre-forensic-force-to-code.md](snapshots/primary/tasks/old/part1/task94-pre-forensic-force-to-code.md) | 🔹 FINAL PRE-FORENSIC UPGRADE PROMPT |
| primary | [tasks/old/part1/task95-discover-the-logs.md](snapshots/primary/tasks/old/part1/task95-discover-the-logs.md) | Role Definition |
| primary | [tasks/old/part1/task96-revise-tp-sl.md](snapshots/primary/tasks/old/part1/task96-revise-tp-sl.md) | (no heading) |
| primary | [tasks/old/part1/task96-risk-mode_position-sizeing-sl-tp-fixer-master-prompt.md](snapshots/primary/tasks/old/part1/task96-risk-mode_position-sizeing-sl-tp-fixer-master-prompt.md) | (no heading) |
| primary | [tasks/old/part1/task96-risk-mode_position-sizeing-sl-tp-fixer.md](snapshots/primary/tasks/old/part1/task96-risk-mode_position-sizeing-sl-tp-fixer.md) | 🛠️ HEDGE FUND SYSTEM IMPROVEMENT PROMPT SUITE |
| primary | [tasks/old/part1/task97-revise-tp-sl-cleanup.md](snapshots/primary/tasks/old/part1/task97-revise-tp-sl-cleanup.md) | (no heading) |
| primary | [tasks/old/part1/task97-timeframe-arch-redesign.md](snapshots/primary/tasks/old/part1/task97-timeframe-arch-redesign.md) | (no heading) |
| primary | [tasks/old/part1/task97-to-sl-validator-enhancement.md](snapshots/primary/tasks/old/part1/task97-to-sl-validator-enhancement.md) | (no heading) |
| primary | [tasks/old/part1/task98-clean-code-simplify.md](snapshots/primary/tasks/old/part1/task98-clean-code-simplify.md) | (no heading) |
| primary | [tasks/old/part1/task99-watcher-engine-fusion-strategy-optimization.md](snapshots/primary/tasks/old/part1/task99-watcher-engine-fusion-strategy-optimization.md) | (no heading) |
| primary | [tasks/old/part2/2026+07+15+strategy+audit.md](snapshots/primary/tasks/old/part2/2026+07+15+strategy+audit.md) | Strategy Preservation Audit |
| primary | [tasks/old/part2/AUDIT-IN-PROGRESS.md](snapshots/primary/tasks/old/part2/AUDIT-IN-PROGRESS.md) | (no heading) |
| primary | [tasks/old/part2/Post-Validation Production Audit.md](snapshots/primary/tasks/old/part2/Post-Validation Production Audit.md) | Post-Validation Production Audit Report |
| primary | [tasks/old/part2/README-task0003.md](snapshots/primary/tasks/old/part2/README-task0003.md) | Lynxion-ETS: Task 0003 Resolution & Analysis Report |
| primary | [tasks/old/part2/alpha_qualification_report.md](snapshots/primary/tasks/old/part2/alpha_qualification_report.md) | Walk-Forward Alpha Qualification Report |
| primary | [tasks/old/part2/backtest_engine_certification_report.md](snapshots/primary/tasks/old/part2/backtest_engine_certification_report.md) | Backtest Engine Certification Report |
| primary | [tasks/old/part2/binance_collector_tech_doc.md](snapshots/primary/tasks/old/part2/binance_collector_tech_doc.md) | Binance Futures Market Data Collector: Technical Documentation |
| primary | [tasks/old/part2/feature_validation_report.md](snapshots/primary/tasks/old/part2/feature_validation_report.md) | Quantitative Feature Validation Report (NGLS) |
| primary | [tasks/old/part2/lynxion_ets_v2_production_blueprint.md](snapshots/primary/tasks/old/part2/lynxion_ets_v2_production_blueprint.md) | Lynxion-ETS v2 Production Architecture Blueprint |
| primary | [tasks/old/part2/market_data_architecture_spec.md](snapshots/primary/tasks/old/part2/market_data_architecture_spec.md) | Market Data Architecture Specification |
| primary | [tasks/old/part2/multi_timeframe_research_architecture.md](snapshots/primary/tasks/old/part2/multi_timeframe_research_architecture.md) | Multi-Timeframe Research Architecture & Design Specification (Sprint 1 - Part 2) |
| primary | [tasks/old/part2/ngls_feature_pipeline_documentation.md](snapshots/primary/tasks/old/part2/ngls_feature_pipeline_documentation.md) | Next Generation Liquidity Sweep (NGLS) Feature Pipeline: Technical Documentation |
| primary | [tasks/old/part2/ngls_scientific_evaluation_report.md](snapshots/primary/tasks/old/part2/ngls_scientific_evaluation_report.md) | Scientific Validation Report: Next Generation Liquidity Sweep (NGLS) |
| primary | [tasks/old/part2/order_book_reconstruction_documentation.md](snapshots/primary/tasks/old/part2/order_book_reconstruction_documentation.md) | L2 Order Book Reconstruction Engine: Technical Documentation |
| primary | [tasks/old/part2/quantitative_research_charter.md](snapshots/primary/tasks/old/part2/quantitative_research_charter.md) | Quantitative Research Charter & Investment Committee Report (Lynxion-ETS Stage 2) |
| primary | [tasks/old/part2/replay_engine_documentation.md](snapshots/primary/tasks/old/part2/replay_engine_documentation.md) | Deterministic Replay Engine & Validation Layer: Technical Documentation |
| primary | [tasks/old/part2/scientific_validation_report.md](snapshots/primary/tasks/old/part2/scientific_validation_report.md) | Scientific Validation Report: Strategy & Profitability Audit (Phase 1–5) |
| primary | [tasks/old/part2/scientific_validation_report_followup.md](snapshots/primary/tasks/old/part2/scientific_validation_report_followup.md) | Systematic Strategy Attribution & Quantitative Research Roadmap (Follow-Up Report) |
| primary | [tasks/old/part2/task0001-do-the-detective-part1.md](snapshots/primary/tasks/old/part2/task0001-do-the-detective-part1.md) | 1. SYSTEM ARCHITECTURE ANALYSIS |
| primary | [tasks/old/part2/task0002-agy-multi-strategy-problem.md](snapshots/primary/tasks/old/part2/task0002-agy-multi-strategy-problem.md) | Priority 1 (Highest) |
| primary | [tasks/old/part2/task0003-agy-same-orders.md](snapshots/primary/tasks/old/part2/task0003-agy-same-orders.md) | (no heading) |
| primary | [tasks/old/part2/task0004-agy-s2.md](snapshots/primary/tasks/old/part2/task0004-agy-s2.md) | (no heading) |
| primary | [tasks/old/part2/task0004-agy-scientifically-validate-report-followup.md](snapshots/primary/tasks/old/part2/task0004-agy-scientifically-validate-report-followup.md) | (no heading) |
| primary | [tasks/old/part2/task0004-agy-scientifically-validate.md](snapshots/primary/tasks/old/part2/task0004-agy-scientifically-validate.md) | (no heading) |
| primary | [tasks/old/part2/task0005+start7.md](snapshots/primary/tasks/old/part2/task0005+start7.md) | 1. Replay Domain Model |
| primary | [tasks/old/part2/task0005+start8.md](snapshots/primary/tasks/old/part2/task0005+start8.md) | (no heading) |
| primary | [tasks/old/part2/task0005-start1.md](snapshots/primary/tasks/old/part2/task0005-start1.md) | (no heading) |
| primary | [tasks/old/part2/task0005-start2.md](snapshots/primary/tasks/old/part2/task0005-start2.md) | (no heading) |
| primary | [tasks/old/part2/task0005-start3.md](snapshots/primary/tasks/old/part2/task0005-start3.md) | (no heading) |
| primary | [tasks/old/part2/task0005-start4.md](snapshots/primary/tasks/old/part2/task0005-start4.md) | (no heading) |
| primary | [tasks/old/part2/task0005-start5.md](snapshots/primary/tasks/old/part2/task0005-start5.md) | (no heading) |
| primary | [tasks/old/part2/task0005-start6.md](snapshots/primary/tasks/old/part2/task0005-start6.md) | (no heading) |
| primary | [tasks/old/part2/task0006-start1.md](snapshots/primary/tasks/old/part2/task0006-start1.md) | (no heading) |
| primary | [tasks/old/part2/task0007 DONE.md](snapshots/primary/tasks/old/part2/task0007 DONE.md) | 1. Walk Forward Evaluation Engine |
| primary | [tasks/old/part2/task0008+ngls+part1 DONE.md](snapshots/primary/tasks/old/part2/task0008+ngls+part1 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0008+ngls+part2 DONE.md](snapshots/primary/tasks/old/part2/task0008+ngls+part2 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0008+ngls+part3 DONE.md](snapshots/primary/tasks/old/part2/task0008+ngls+part3 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0008+ngls+part4 DONE.md](snapshots/primary/tasks/old/part2/task0008+ngls+part4 DONE.md) | 1. Architectural Blueprint |
| primary | [tasks/old/part2/task0008+ngls+part5 DONE.md](snapshots/primary/tasks/old/part2/task0008+ngls+part5 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0009+strategy+ngls+part1 DONE.md](snapshots/primary/tasks/old/part2/task0009+strategy+ngls+part1 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0009+strategy+ngls+part2.md](snapshots/primary/tasks/old/part2/task0009+strategy+ngls+part2.md) | (no heading) |
| primary | [tasks/old/part2/task0009+strategy+ngls+part3 DONE.md](snapshots/primary/tasks/old/part2/task0009+strategy+ngls+part3 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0009+strategy+ngls+part4 DONE.md](snapshots/primary/tasks/old/part2/task0009+strategy+ngls+part4 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part1 DONE.md](snapshots/primary/tasks/old/part2/task0010+migation+part1 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part2 DONE.md](snapshots/primary/tasks/old/part2/task0010+migation+part2 DONE.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part3.md](snapshots/primary/tasks/old/part2/task0010+migation+part3.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part4.md](snapshots/primary/tasks/old/part2/task0010+migation+part4.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part5.md](snapshots/primary/tasks/old/part2/task0010+migation+part5.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part6.md](snapshots/primary/tasks/old/part2/task0010+migation+part6.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part7.md](snapshots/primary/tasks/old/part2/task0010+migation+part7.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part8.md](snapshots/primary/tasks/old/part2/task0010+migation+part8.md) | (no heading) |
| primary | [tasks/old/part2/task0010+migation+part9.md](snapshots/primary/tasks/old/part2/task0010+migation+part9.md) | (no heading) |
| primary | [tasks/old/part2/task0011+migation+part1.md](snapshots/primary/tasks/old/part2/task0011+migation+part1.md) | (no heading) |
| primary | [tasks/old/part2/task0011+migation+part2.md](snapshots/primary/tasks/old/part2/task0011+migation+part2.md) | Execution Policy |
| primary | [tasks/old/part2/task0011+migation+part3.md](snapshots/primary/tasks/old/part2/task0011+migation+part3.md) | (no heading) |
| primary | [tasks/old/part2/task0011+migation+part4.md](snapshots/primary/tasks/old/part2/task0011+migation+part4.md) |  |
| primary | [tasks/old/part2/task0011+migation+part5.md](snapshots/primary/tasks/old/part2/task0011+migation+part5.md) | (no heading) |
| primary | [tasks/old/part2/task0011+migation+part6.md](snapshots/primary/tasks/old/part2/task0011+migation+part6.md) | NGDP Architecture Design Audit |
| primary | [tasks/old/part2/task0012+papare+part1.md](snapshots/primary/tasks/old/part2/task0012+papare+part1.md) | Task: Production Hardening & Paper Trading Launch Preparation |
| primary | [tasks/old/part2/task0012+papare+part2 DONE.md](snapshots/primary/tasks/old/part2/task0012+papare+part2 DONE.md) | NGDP & Paper Trading Safety Implementation Task (Part 2) - DONE |
| primary | [tasks/old/part2/task0012-prapare-part3 DONE.md](snapshots/primary/tasks/old/part2/task0012-prapare-part3 DONE.md) | Supervised Paper Trading Prep - Part 3 DONE |
| primary | [tasks/old/part2/task0012-prepare-part4 DONE.md](snapshots/primary/tasks/old/part2/task0012-prepare-part4 DONE.md) | Production Readiness Audit - Part 4 DONE |
| primary | [tasks/old/part2/task0012-prepare-part5 DONE.md](snapshots/primary/tasks/old/part2/task0012-prepare-part5 DONE.md) | Market Data Ingestion Duplication Audit - Part 5 DONE |
| primary | [tasks/old/part2/task0012-prepare-part6 DONE.md](snapshots/primary/tasks/old/part2/task0012-prepare-part6 DONE.md) | Dependency Graph and Consumer Audit - Part 6 DONE |
| primary | [tasks/old/part2/task0012-prepare-part۷ DONE.md](snapshots/primary/tasks/old/part2/task0012-prepare-part۷ DONE.md) | Final Architecture Approval Review - Part 7 DONE |
| primary | [tasks/old/part2/task0012-prepare-part۸.md](snapshots/primary/tasks/old/part2/task0012-prepare-part۸.md) | (no heading) |
| primary | [tasks/old/part2/task0013-broker-validation-part1 DONE.md](snapshots/primary/tasks/old/part2/task0013-broker-validation-part1 DONE.md) | BingX VST Validation - Part 1 DONE |
| primary | [tasks/old/part2/task0013-broker-validation-part2 DONE.md](snapshots/primary/tasks/old/part2/task0013-broker-validation-part2 DONE.md) | BingX VST Campaign - Part 2 DONE |
| primary | [tasks/old/part2/task0013-broker-validation-part۳ DONE.md](snapshots/primary/tasks/old/part2/task0013-broker-validation-part۳ DONE.md) | Controlled Multi-Position Paper Trading - Part 3 DONE |
| primary | [tasks/old/part2/task0014-fix-order-part1.md](snapshots/primary/tasks/old/part2/task0014-fix-order-part1.md) | (no heading) |
| primary | [tasks/old/part2/task0014-fix-order-part۲.md](snapshots/primary/tasks/old/part2/task0014-fix-order-part۲.md) | (no heading) |
| primary | [tasks/old/part2/task0015-remidation-part1-INPROGRESS.md](snapshots/primary/tasks/old/part2/task0015-remidation-part1-INPROGRESS.md) | (no heading) |
| primary | [tasks/old/part2/task0015-remidation-part2.md](snapshots/primary/tasks/old/part2/task0015-remidation-part2.md) | (no heading) |
| primary | [tasks/old/part2/task0015-remidation-part3.md](snapshots/primary/tasks/old/part2/task0015-remidation-part3.md) | (no heading) |
| primary | [tasks/old/part2/task0015-remidation-part4.md](snapshots/primary/tasks/old/part2/task0015-remidation-part4.md) | (no heading) |
| primary | [tasks/old/part2/task0015-remidation-part5.md](snapshots/primary/tasks/old/part2/task0015-remidation-part5.md) | Validation Scope |
| primary | [tasks/old/part2/venue_normalization_domain_doc.md](snapshots/primary/tasks/old/part2/venue_normalization_domain_doc.md) | Market Venue Normalization: Domain Documentation |
| primary | [tasks/old/part3/README.md](snapshots/primary/tasks/old/part3/README.md) | Tasks Directory |
| primary | [tasks/old/part3/README_SEV1_XMR.md](snapshots/primary/tasks/old/part3/README_SEV1_XMR.md) | SEV-1 Incident Report: XMRUSDT Rapid Sequential Re-Entry & Notification Silence |
| primary | [tasks/old/part3/alpha_qualification_report.md](snapshots/primary/tasks/old/part3/alpha_qualification_report.md) | Walk-Forward Alpha Qualification Report |
| primary | [tasks/old/part3/feature_validation_report.md](snapshots/primary/tasks/old/part3/feature_validation_report.md) | Quantitative Feature Validation Report (NGLS) |
| primary | [tasks/old/part3/final-runtime-validation-INPROGRESS.md](snapshots/primary/tasks/old/part3/final-runtime-validation-INPROGRESS.md) | (no heading) |
| primary | [tasks/old/part3/report+2026+07+20.md](snapshots/primary/tasks/old/part3/report+2026+07+20.md) | 1. Executive Stress Verdict & Decision Matrix |
| primary | [tasks/old/part3/report+strategies+2026+07+19.md](snapshots/primary/tasks/old/part3/report+strategies+2026+07+19.md) | Key Audit Deliverables Summary |
| primary | [tasks/old/part3/task0001-trade-quality-part1.md](snapshots/primary/tasks/old/part3/task0001-trade-quality-part1.md) | Lynxion ETS – Phase 2: Production Trade Quality & Profitability Optimization |
| primary | [tasks/old/part3/task0001-trade-quality-part2.md](snapshots/primary/tasks/old/part3/task0001-trade-quality-part2.md) | Lynxion ETS – Phase 2: Production Implementation Framework |
| primary | [tasks/old/part3/task0016+edge+measurement+part1.md](snapshots/primary/tasks/old/part3/task0016+edge+measurement+part1.md) | Phase 1 — Edge Measurement |
| primary | [tasks/old/part3/task0016+edge+measurement+part2.md](snapshots/primary/tasks/old/part3/task0016+edge+measurement+part2.md) | (no heading) |
| primary | [tasks/old/part3/task0016+edge+measurement+part3+INPROGRESS.md](snapshots/primary/tasks/old/part3/task0016+edge+measurement+part3+INPROGRESS.md) | (no heading) |
| primary | [tasks/old/part3/task0017+signal+improvement+part1.md](snapshots/primary/tasks/old/part3/task0017+signal+improvement+part1.md) | (no heading) |
| primary | [tasks/old/part3/task0018+alpha+part1.md](snapshots/primary/tasks/old/part3/task0018+alpha+part1.md) | (no heading) |
| primary | [tasks/old/part3/task0018+alpha+part2.md](snapshots/primary/tasks/old/part3/task0018+alpha+part2.md) | (no heading) |
| primary | [tasks/old/part3/task0018+alpha+part3.md](snapshots/primary/tasks/old/part3/task0018+alpha+part3.md) | (no heading) |
| primary | [tasks/old/part3/task0018+alpha+part4.md](snapshots/primary/tasks/old/part3/task0018+alpha+part4.md) | Phase 1 — Historical Risk Overlay Simulation |
| primary | [tasks/old/part3/task0018+alpha+part5.md](snapshots/primary/tasks/old/part3/task0018+alpha+part5.md) | Non-Negotiable Constraints |
| primary | [tasks/old/part3/task0040+position+part1+inprogress.md](snapshots/primary/tasks/old/part3/task0040+position+part1+inprogress.md) | (no heading) |
| primary | [tasks/old/part3/task0042+position+part1.md](snapshots/primary/tasks/old/part3/task0042+position+part1.md) | (no heading) |
| primary | [tasks/old/part3/task0042+position+part2.md](snapshots/primary/tasks/old/part3/task0042+position+part2.md) | (no heading) |
| primary | [tasks/old/part3/task0043-position-size-entry-point-INPROGRESS.md](snapshots/primary/tasks/old/part3/task0043-position-size-entry-point-INPROGRESS.md) | (no heading) |
| primary | [tasks/old/part3/task0044-p0.1-future-metadata-verification-report.md](snapshots/primary/tasks/old/part3/task0044-p0.1-future-metadata-verification-report.md) | P0.1 FUTURE-METADATA VERIFICATION REPORT |
| primary | [tasks/old/part3/task0044-p0.1-post-implementation-data-validation-report.md](snapshots/primary/tasks/old/part3/task0044-p0.1-post-implementation-data-validation-report.md) | P0.1 POST-IMPLEMENTATION DATA VALIDATION REPORT |
| primary | [tasks/old/part3/task0044-profitability-forensic-audit-phase2-final.md](snapshots/primary/tasks/old/part3/task0044-profitability-forensic-audit-phase2-final.md) | PROFITABILITY FORENSIC AUDIT — PHASE 2 |
| primary | [tasks/old/part3/task0044-profitability-forensic-audit-phase2.md](snapshots/primary/tasks/old/part3/task0044-profitability-forensic-audit-phase2.md) | PROFITABILITY FORENSIC AUDIT — PHASE 2 |
| primary | [tasks/old/part3/task0044-profitability-forensic-audit.md](snapshots/primary/tasks/old/part3/task0044-profitability-forensic-audit.md) | LYNXION ETS — PROFITABILITY FORENSIC AUDIT & MINIMAL OPTIMIZATION REPORT |
| primary | [tasks/old/part4/LYNXION_PROJECT_CONTEXT.md](snapshots/primary/tasks/old/part4/LYNXION_PROJECT_CONTEXT.md) | LYNXION ETS — MASTER PROJECT CONTEXT & ENGINEERING HANDOVER DOCUMENTATION |
| primary | [tasks/old/part4/task0045-profitability-root-cause-audit.md](snapshots/primary/tasks/old/part4/task0045-profitability-root-cause-audit.md) | LYNXION ETS — PROFITABILITY ROOT CAUSE FORENSIC AUDIT |
| primary | [tasks/old/part4/task0046-p1.1-causal-validation-report.md](snapshots/primary/tasks/old/part4/task0046-p1.1-causal-validation-report.md) | LYNXION ETS — TASK0046: P1.1 CAUSAL VALIDATION & PRE-IMPLEMENTATION GATE |
| primary | [tasks/old/part4/task0047-p1.1-post-implementation-verification-report.md](snapshots/primary/tasks/old/part4/task0047-p1.1-post-implementation-verification-report.md) | P1.1 POST-IMPLEMENTATION VERIFICATION REPORT |
| primary | [tasks/old/part4/task0048-p1.1-profitability-impact-forensic-analysis-report.md](snapshots/primary/tasks/old/part4/task0048-p1.1-profitability-impact-forensic-analysis-report.md) | LYNXION ETS — TASK0048: P1.1 PROFITABILITY IMPACT & ROOT-CAUSE FORENSIC ANALYSIS |
| primary | [tasks/old/part4/task0049-p1.2-trigger-exit-execution-forensic-verification-report.md](snapshots/primary/tasks/old/part4/task0049-p1.2-trigger-exit-execution-forensic-verification-report.md) | LYNXION ETS — TASK0049: P1.2 TRIGGER-EXIT EXECUTION CAUSAL VERIFICATION |
| primary | [tasks/old/part4/task0050-p1.3-position-sizing-loss-attribution-forensic-audit-report.md](snapshots/primary/tasks/old/part4/task0050-p1.3-position-sizing-loss-attribution-forensic-audit-report.md) | LYNXION ETS — TASK0050: P1.3 POSITION SIZING & LOSS ATTRIBUTION FORENSIC AUDIT |
| primary | [tasks/old/part4/task0051-p1.4-position-sizing-cap-bypass-root-cause-verification-report.md](snapshots/primary/tasks/old/part4/task0051-p1.4-position-sizing-cap-bypass-root-cause-verification-report.md) | LYNXION ETS — TASK0051: P1.4 POSITION-SIZING CAP BYPASS ROOT-CAUSE VERIFICATION |
| primary | [tasks/old/part4/task0052-p1.5-cooldown-enforcement-forensic-audit-report.md](snapshots/primary/tasks/old/part4/task0052-p1.5-cooldown-enforcement-forensic-audit-report.md) | LYNXION ETS — TASK0052: P1.5 COOLDOWN ENFORCEMENT FORENSIC AUDIT |
| primary | [tasks/old/part4/task0053-p1.6-cooldown-causal-attribution-fix-readiness-report.md](snapshots/primary/tasks/old/part4/task0053-p1.6-cooldown-causal-attribution-fix-readiness-report.md) | LYNXION ETS — TASK0053: P1.6 COOLDOWN CAUSAL ATTRIBUTION & FIX READINESS REPORT |
| primary | [tasks/old/part4/task0054-p1.7-position-sizing-cooldown-control-audit-report.md](snapshots/primary/tasks/old/part4/task0054-p1.7-position-sizing-cooldown-control-audit-report.md) | LYNXION ETS — TASK0054: P1.7 POSITION SIZING & COOLDOWN CONTROL FORENSIC AUDIT |
| primary | [tasks/old/part4/task0055-p1.8-risk-manager-instantiation-dataset-reconciliation-report.md](snapshots/primary/tasks/old/part4/task0055-p1.8-risk-manager-instantiation-dataset-reconciliation-report.md) | LYNXION ETS — TASK0055: P1.8 RISK MANAGER INSTANTIATION & DATASET RECONCILIATION REPORT |
| primary | [tasks/old/part4/task0056-p1.9-position-sizing-cooldown-control-closure-audit.md](snapshots/primary/tasks/old/part4/task0056-p1.9-position-sizing-cooldown-control-closure-audit.md) | LYNXION ETS — TASK0056: P1.9 POSITION SIZING & COOLDOWN CONTROL CLOSURE AUDIT |
| primary | [tasks/old/part4/task0057-p2-cooldown-remediation-report.md](snapshots/primary/tasks/old/part4/task0057-p2-cooldown-remediation-report.md) | LYNXION ETS — TASK0057: P2 COOLDOWN CONTROL REMEDIATION REPORT |
| primary | [tasks/old/part4/task0058-p2-post-remediation-forensic-validation.md](snapshots/primary/tasks/old/part4/task0058-p2-post-remediation-forensic-validation.md) | LYNXION ETS — TASK0058: P2 POST-REMEDIATION FORENSIC VALIDATION REPORT |
| primary | [tasks/old/part4/task0059-residual-profitability-forensic-audit.md](snapshots/primary/tasks/old/part4/task0059-residual-profitability-forensic-audit.md) | LYNXION ETS — TASK0059: RESIDUAL PROFITABILITY FORENSIC AUDIT REPORT |
| primary | [tasks/old/part4/task0060-exit-management-forensic-audit.md](snapshots/primary/tasks/old/part4/task0060-exit-management-forensic-audit.md) | LYNXION ETS — TASK0060: EXIT MANAGEMENT FORENSIC AUDIT REPORT |
| primary | [tasks/old/part4/task0060-strategy-strictness-advisory-report.md](snapshots/primary/tasks/old/part4/task0060-strategy-strictness-advisory-report.md) | LYNXION ETS — STRATEGY STRICTNESS AUDIT & ADVISORY REPORT |
| primary | [tasks/old/part4/task0061-residual-edge-forensic-audit.md](snapshots/primary/tasks/old/part4/task0061-residual-edge-forensic-audit.md) | LYNXION ETS — TASK0061: RESIDUAL EDGE FORENSIC AUDIT REPORT |
| primary | [tasks/old/part4/task0062-controlled-regime-forensic-validation.md](snapshots/primary/tasks/old/part4/task0062-controlled-regime-forensic-validation.md) | LYNXION ETS — TASK0062: CONTROLLED REGIME FORENSIC VALIDATION & OUT-OF-SAMPLE STABILITY AUDIT |
| primary | [tasks/old/part4/task0063-prospective-forward-validation-gate.md](snapshots/primary/tasks/old/part4/task0063-prospective-forward-validation-gate.md) | LYNXION ETS — TASK0063: PROSPECTIVE FORWARD VALIDATION GATE REPORT |
| primary | [tasks/old/part4/task0064-p3-prospective-validation-report.md](snapshots/primary/tasks/old/part4/task0064-p3-prospective-validation-report.md) | LYNXION ETS — TASK0064: P3 PROSPECTIVE FORWARD VALIDATION REPORT |
| primary | [tasks/old/part4/task0065-prospective-validation-gate-execution.md](snapshots/primary/tasks/old/part4/task0065-prospective-validation-gate-execution.md) | LYNXION ETS — TASK0065: PROSPECTIVE VALIDATION GATE EXECUTION REPORT |
| primary | [tasks/old/part4/task0066-prospective-validation-execution-log.md](snapshots/primary/tasks/old/part4/task0066-prospective-validation-execution-log.md) | LYNXION ETS — TASK0066: PROSPECTIVE VALIDATION EXECUTION LOG & AUDIT |
| primary | [tasks/old/part4/task0067-prospective-validation-checkpoint1.md](snapshots/primary/tasks/old/part4/task0067-prospective-validation-checkpoint1.md) | LYNXION ETS — TASK0067: PROSPECTIVE VALIDATION CHECKPOINT #1 REPORT |
| primary | [tasks/old/part4/task0068-prospective-validation-checkpoint2.md](snapshots/primary/tasks/old/part4/task0068-prospective-validation-checkpoint2.md) | LYNXION ETS — TASK0068: PROSPECTIVE VALIDATION CHECKPOINT #2 REPORT |
| primary | [tasks/old/part4/task0069-prospective-execution-start-diagnostic.md](snapshots/primary/tasks/old/part4/task0069-prospective-execution-start-diagnostic.md) | LYNXION ETS — TASK0069: PROSPECTIVE VALIDATION EXECUTION-START DIAGNOSTIC REPORT |
| primary | [tasks/old/part4/task0070-passive-prospective-monitoring-log.md](snapshots/primary/tasks/old/part4/task0070-passive-prospective-monitoring-log.md) | LYNXION ETS — TASK0070: PASSIVE PROSPECTIVE MONITORING LOG |
| primary | [tasks/old/part4/task0071-validation-liveness-zero-trade-investigation.md](snapshots/primary/tasks/old/part4/task0071-validation-liveness-zero-trade-investigation.md) | LYNXION ETS — TASK0071: VALIDATION LIVENESS & ZERO-TRADE INVESTIGATION REPORT |
| primary | [tasks/old/part4/task0072-validation-hard-runtime-evidence.md](snapshots/primary/tasks/old/part4/task0072-validation-hard-runtime-evidence.md) | LYNXION ETS — TASK0072: HARD RUNTIME EVIDENCE INVESTIGATION REPORT |
| primary | [tasks/old/part4/task0073-heartbeatguard-forensic-audit.md](snapshots/primary/tasks/old/part4/task0073-heartbeatguard-forensic-audit.md) | LYNXION ETS — TASK0073: HEARTBEATGUARD FORENSIC AUDIT & ROOT-CAUSE INVESTIGATION REPORT |
| primary | [tasks/old/part4/task0074-heartbeatguard-remediation-design.md](snapshots/primary/tasks/old/part4/task0074-heartbeatguard-remediation-design.md) | LYNXION ETS — TASK0074: HEARTBEATGUARD REMEDIATION DESIGN & VALIDATION IMPACT REPORT |
| primary | [tasks/old/part4/task0075-heartbeatguard-remediation-implementation.md](snapshots/primary/tasks/old/part4/task0075-heartbeatguard-remediation-implementation.md) | LYNXION ETS — TASK0075: HEARTBEATGUARD REMEDIATION IMPLEMENTATION REPORT |
| primary | [tasks/old/part4/task0076-live-heartbeat-liveness-audit.md](snapshots/primary/tasks/old/part4/task0076-live-heartbeat-liveness-audit.md) | LYNXION ETS — TASK0076: POST-REMEDIATION LIVE HEARTBEAT LIVENESS AUDIT REPORT |
| primary | [tasks/old/task001-start-again.md](snapshots/primary/tasks/old/task001-start-again.md) | TASK0045 — PROFITABILITY VALIDATION & P1 REVIEW |
| primary | [tasks/old/task002.md](snapshots/primary/tasks/old/task002.md) | Lynxion ETS — Task0047 |
| primary | [tasks/part3/task0077-telemetry-deployment-cohort-timestamp.md](snapshots/primary/tasks/part3/task0077-telemetry-deployment-cohort-timestamp.md) | LYNXION ETS — TASK0077: TELEMETRY DEPLOYMENT & COHORT TIMESTAMP ESTABLISHMENT REPORT |
| primary | [tasks/part3/task0078-prospective-decision-telemetry-log.md](snapshots/primary/tasks/part3/task0078-prospective-decision-telemetry-log.md) | LYNXION ETS — TASK0078: PROSPECTIVE DECISION TELEMETRY LOG REPORT |
| primary | [tasks/part3/task0079-prospective-cohort-execution-ledger.md](snapshots/primary/tasks/part3/task0079-prospective-cohort-execution-ledger.md) | TASK-0079: Prospective Cohort Execution Ledger (Live Continuous Audit) |
| primary | [tasks/part3/task0080-prospective-validation-checkpoint1.md](snapshots/primary/tasks/part3/task0080-prospective-validation-checkpoint1.md) | LYNXION ETS — TASK0080: PROSPECTIVE VALIDATION CHECKPOINT #1 AUDIT REPORT |
| primary | [tasks/part3/task0081-prospective-validation-checkpoint2.md](snapshots/primary/tasks/part3/task0081-prospective-validation-checkpoint2.md) | LYNXION ETS — TASK0081: PROSPECTIVE VALIDATION CHECKPOINT #2 AUDIT REPORT |
| primary | [tasks/part3/task0082-prospective-validation-checkpoint3.md](snapshots/primary/tasks/part3/task0082-prospective-validation-checkpoint3.md) | TASK-0082: Prospective Validation Checkpoint #3 (N = 56) |
| primary | [tasks/part3/task0083-prospective-validation-checkpoint4.md](snapshots/primary/tasks/part3/task0083-prospective-validation-checkpoint4.md) | TASK-0083: Prospective Validation Checkpoint #4 (N = 81) |
| primary | [tasks/part3/task0084-prospective-cohort-acceptance-gate.md](snapshots/primary/tasks/part3/task0084-prospective-cohort-acceptance-gate.md) | TASK-0084: Prospective Validation Cohort #1 Final Acceptance & Forensic Review (N ≥ 100) |
| primary | [tasks/part3/task0085-prospective-cohort2-execution-roadmap.md](snapshots/primary/tasks/part3/task0085-prospective-cohort2-execution-roadmap.md) | TASK-0085: Prospective Validation Cohort #2 Execution Roadmap (N = 100) |
| primary | [tasks/part3/task0086-cohort2-checkpoint-audit.md](snapshots/primary/tasks/part3/task0086-cohort2-checkpoint-audit.md) | Prospective Validation Cohort #2 Interim Checkpoint Audit ($N = 57$) |
| primary | [tasks/research/edge-candidate-register-v1.md](snapshots/primary/tasks/research/edge-candidate-register-v1.md) | Edge Candidate Register v1 |
| primary | [tasks/research/edge-candidate-register-v10.md](snapshots/primary/tasks/research/edge-candidate-register-v10.md) | Edge Candidate Register v10 — C-11 Prospective Severe Funding Rebound |
| primary | [tasks/research/edge-candidate-register-v11.md](snapshots/primary/tasks/research/edge-candidate-register-v11.md) | Edge Candidate Register v11 — C-12 Cross-Symbol Funding Generalization |
| primary | [tasks/research/edge-candidate-register-v12.md](snapshots/primary/tasks/research/edge-candidate-register-v12.md) | Edge Candidate Register v12 — C-13 Temporal Funding Generalization |
| primary | [tasks/research/edge-candidate-register-v13.md](snapshots/primary/tasks/research/edge-candidate-register-v13.md) | Edge Candidate Register v13 — C-14 Long-Horizon Time-Series Momentum |
| primary | [tasks/research/edge-candidate-register-v14.md](snapshots/primary/tasks/research/edge-candidate-register-v14.md) | Edge Candidate Register v14 — C-15 Independent Long-Only Trend Holdout |
| primary | [tasks/research/edge-candidate-register-v15.md](snapshots/primary/tasks/research/edge-candidate-register-v15.md) | Edge Candidate Register v15 — C-16 OI-Confirmed Price Impulse |
| primary | [tasks/research/edge-candidate-register-v16.md](snapshots/primary/tasks/research/edge-candidate-register-v16.md) | Edge Candidate Register v16 — C-17 OI-Flush Exhaustion Reversal |
| primary | [tasks/research/edge-candidate-register-v17.md](snapshots/primary/tasks/research/edge-candidate-register-v17.md) | Edge Candidate Register v17 — C-18 Near-Book Depth Imbalance |
| primary | [tasks/research/edge-candidate-register-v18.md](snapshots/primary/tasks/research/edge-candidate-register-v18.md) | Edge Candidate Register v18 — C-19 Liquidity-Withdrawal Differential |
| primary | [tasks/research/edge-candidate-register-v19.md](snapshots/primary/tasks/research/edge-candidate-register-v19.md) | Edge Candidate Register v19 — C-20 Symmetric Premium-Basis Convergence |
| primary | [tasks/research/edge-candidate-register-v2.md](snapshots/primary/tasks/research/edge-candidate-register-v2.md) | Edge Candidate Register v2 |
| primary | [tasks/research/edge-candidate-register-v20.md](snapshots/primary/tasks/research/edge-candidate-register-v20.md) | Edge Candidate Register v20 — C-21 Aggressive Taker-Flow Continuation |
| primary | [tasks/research/edge-candidate-register-v21.md](snapshots/primary/tasks/research/edge-candidate-register-v21.md) | Edge Candidate Register v21 — C-22 Independent Taker-Flow Confirmation |
| primary | [tasks/research/edge-candidate-register-v22.md](snapshots/primary/tasks/research/edge-candidate-register-v22.md) | Edge Candidate Register v22 — C-23 Delta-Neutral Positive-Funding Carry |
| primary | [tasks/research/edge-candidate-register-v23.md](snapshots/primary/tasks/research/edge-candidate-register-v23.md) | Edge Candidate Register v23 — C-24 Delta-Neutral Basis Convergence |
| primary | [tasks/research/edge-candidate-register-v24.md](snapshots/primary/tasks/research/edge-candidate-register-v24.md) | Edge Candidate Register v24 — C-25 Independent Basis-Convergence Confirmation |
| primary | [tasks/research/edge-candidate-register-v25.md](snapshots/primary/tasks/research/edge-candidate-register-v25.md) | Edge Candidate Register v25 — C-26 BTC-Lead / Alt-Underreaction |
| primary | [tasks/research/edge-candidate-register-v26.md](snapshots/primary/tasks/research/edge-candidate-register-v26.md) | Edge Candidate Register v26 — C-27 Concentrated Aggressor Exhaustion |
| primary | [tasks/research/edge-candidate-register-v27.md](snapshots/primary/tasks/research/edge-candidate-register-v27.md) | Edge Candidate Register v27 — C-28 Volatility-Sweep Rejection |
| primary | [tasks/research/edge-candidate-register-v28.md](snapshots/primary/tasks/research/edge-candidate-register-v28.md) | Edge Candidate Register v28 — C-29 Top-Trader / Crowd Positioning Divergence |
| primary | [tasks/research/edge-candidate-register-v29.md](snapshots/primary/tasks/research/edge-candidate-register-v29.md) | Edge Candidate Register v29 — C-30 Independent Positioning-Divergence Confirmation |
| primary | [tasks/research/edge-candidate-register-v3.md](snapshots/primary/tasks/research/edge-candidate-register-v3.md) | Edge Candidate Register v3 — C-01/C-02/C-03 Frozen Evaluation |
| primary | [tasks/research/edge-candidate-register-v30.md](snapshots/primary/tasks/research/edge-candidate-register-v30.md) | Edge Candidate Register v30 — C-31 Spot-Led Perpetual Underreaction |
| primary | [tasks/research/edge-candidate-register-v31.md](snapshots/primary/tasks/research/edge-candidate-register-v31.md) | Edge Candidate Register v31 — C-32 Cross-Venue Perpetual Dislocation |
| primary | [tasks/research/edge-candidate-register-v32.md](snapshots/primary/tasks/research/edge-candidate-register-v32.md) | Edge Candidate Register v32 — C-33 Forced-Liquidation Exhaustion |
| primary | [tasks/research/edge-candidate-register-v33.md](snapshots/primary/tasks/research/edge-candidate-register-v33.md) | Edge Candidate Register v33 — C-34 Cross-Venue Aggressive-Flow Divergence |
| primary | [tasks/research/edge-candidate-register-v34.md](snapshots/primary/tasks/research/edge-candidate-register-v34.md) | Edge Candidate Register v34 — C-35 Compression-Release Continuation |
| primary | [tasks/research/edge-candidate-register-v4.md](snapshots/primary/tasks/research/edge-candidate-register-v4.md) | Edge Candidate Register v4 — C-05 Cross-Sectional Momentum |
| primary | [tasks/research/edge-candidate-register-v5.md](snapshots/primary/tasks/research/edge-candidate-register-v5.md) | Edge Candidate Register v5 — C-06 Market-Neutral Extreme Reversal |
| primary | [tasks/research/edge-candidate-register-v6.md](snapshots/primary/tasks/research/edge-candidate-register-v6.md) | Edge Candidate Register v6 — C-07 Volume-Confirmed Acceleration |
| primary | [tasks/research/edge-candidate-register-v7.md](snapshots/primary/tasks/research/edge-candidate-register-v7.md) | Edge Candidate Register v7 — C-08 Daily Relative-Strength Continuation |
| primary | [tasks/research/edge-candidate-register-v8.md](snapshots/primary/tasks/research/edge-candidate-register-v8.md) | Edge Candidate Register v8 — C-09 BTC-Regime Long Relative Strength |
| primary | [tasks/research/edge-candidate-register-v9.md](snapshots/primary/tasks/research/edge-candidate-register-v9.md) | Edge Candidate Register v9 — C-10 Extreme-Negative Funding Rebound |
| primary | [tasks/research/exit-policy-register-v1.md](snapshots/primary/tasks/research/exit-policy-register-v1.md) | Exit Policy Register v1 — Prospective net-profit floor |
| primary | [tasks/research/sequential-edge-research-policy-v1.md](snapshots/primary/tasks/research/sequential-edge-research-policy-v1.md) | Sequential Edge Research Policy v1 |
| primary | [tasks/roadmaps/Multi-exchange symbol discovery.md](snapshots/primary/tasks/roadmaps/Multi-exchange symbol discovery.md) | وضعیت فعلی تو |
| primary | [tasks/roadmaps/comments.md](snapshots/primary/tasks/roadmaps/comments.md) | Live Trading Observations Requiring Investigation |
| primary | [tasks/roadmaps/steps.md](snapshots/primary/tasks/roadmaps/steps.md) | (no heading) |
| primary | [tasks/task0077-telemetry-deployment-cohort-timestamp.md](snapshots/primary/tasks/task0077-telemetry-deployment-cohort-timestamp.md) | LYNXION ETS — TASK0077: TELEMETRY DEPLOYMENT & COHORT TIMESTAMP ESTABLISHMENT REPORT |
| primary | [tasks/task0078-prospective-decision-telemetry-log.md](snapshots/primary/tasks/task0078-prospective-decision-telemetry-log.md) | LYNXION ETS — TASK0078: PROSPECTIVE DECISION TELEMETRY LOG REPORT |
| primary | [tasks/task0078-signal-census.md](snapshots/primary/tasks/task0078-signal-census.md) | TASK0078 — Point-in-Time Signal Census |
| primary | [tasks/task0079-frozen-baseline-prospective-cohort.md](snapshots/primary/tasks/task0079-frozen-baseline-prospective-cohort.md) | TASK0079 — Frozen Baseline Prospective Cohort |
| primary | [tasks/task0079-prospective-cohort-execution-ledger.md](snapshots/primary/tasks/task0079-prospective-cohort-execution-ledger.md) | TASK-0079: Prospective Cohort Execution Ledger (Live Continuous Audit) |
| primary | [tasks/task0080-pre-registered-candidate-research.md](snapshots/primary/tasks/task0080-pre-registered-candidate-research.md) | TASK0080 — Pre-Registered Candidate Research |
| primary | [tasks/task0080-prospective-validation-checkpoint1.md](snapshots/primary/tasks/task0080-prospective-validation-checkpoint1.md) | LYNXION ETS — TASK0080: PROSPECTIVE VALIDATION CHECKPOINT #1 AUDIT REPORT |
| primary | [tasks/task0081-prospective-validation-checkpoint2.md](snapshots/primary/tasks/task0081-prospective-validation-checkpoint2.md) | LYNXION ETS — TASK0081: PROSPECTIVE VALIDATION CHECKPOINT #2 AUDIT REPORT |
| primary | [tasks/task0081-shadow-promotion-gate.md](snapshots/primary/tasks/task0081-shadow-promotion-gate.md) | TASK0081 — Shadow Promotion Gate |
| primary | [tasks/task0082-decision-dataset-and-counterfactual-lab.md](snapshots/primary/tasks/task0082-decision-dataset-and-counterfactual-lab.md) | TASK0082 — Decision Dataset & Counterfactual Research Lab |
| primary | [tasks/task0082-prospective-validation-checkpoint3.md](snapshots/primary/tasks/task0082-prospective-validation-checkpoint3.md) | TASK-0082: Prospective Validation Checkpoint #3 (N = 56) |
| primary | [tasks/task0083-prospective-validation-checkpoint4.md](snapshots/primary/tasks/task0083-prospective-validation-checkpoint4.md) | TASK-0083: Prospective Validation Checkpoint #4 (N = 81) |
| primary | [tasks/task0084-prospective-cohort-acceptance-gate.md](snapshots/primary/tasks/task0084-prospective-cohort-acceptance-gate.md) | TASK-0084: Prospective Validation Cohort #1 Final Acceptance & Forensic Review (N ≥ 100) |
| primary | [tasks/task0085-prospective-cohort2-execution-roadmap.md](snapshots/primary/tasks/task0085-prospective-cohort2-execution-roadmap.md) | TASK-0085: Prospective Validation Cohort #2 Execution Roadmap (N = 100) |
| primary | [tasks/task0086-cohort2-checkpoint-audit.md](snapshots/primary/tasks/task0086-cohort2-checkpoint-audit.md) | Prospective Validation Cohort #2 Interim Checkpoint Audit ($N = 57$) |
| primary | [tasks/task0087-trailing-stop-profit-lock-verification.md](snapshots/primary/tasks/task0087-trailing-stop-profit-lock-verification.md) | TASK-0087 — Exchange-Side Profit Lock and Trailing Stop Verification |
| primary | [tasks/task0088-strategy-broker-telemetry-runtime-repair.md](snapshots/primary/tasks/task0088-strategy-broker-telemetry-runtime-repair.md) | TASK-0088 — Strategy-to-Broker Telemetry Runtime Repair |
| primary | [tasks/task0089-performance-attribution-report.md](snapshots/primary/tasks/task0089-performance-attribution-report.md) | TASK-0089 — TASK 001 Performance Attribution |
| primary | [tasks/task0090-edge-failure-decomposition-report.md](snapshots/primary/tasks/task0090-edge-failure-decomposition-report.md) | TASK-0090 — TASK 002 Edge Failure Decomposition |
| primary | [tasks/task0091-controlled-edge-research-v2.md](snapshots/primary/tasks/task0091-controlled-edge-research-v2.md) | TASK-0091 — Controlled Edge Research v2 |
| primary | [tasks/task0092-controlled-edge-research-c01-c03.md](snapshots/primary/tasks/task0092-controlled-edge-research-c01-c03.md) | TASK-0092 — Controlled Edge Research C-01/C-02/C-03 |
| primary | [tasks/task0093-cross-sectional-symbol-selection.md](snapshots/primary/tasks/task0093-cross-sectional-symbol-selection.md) | TASK-0093 — Cross-Sectional Symbol Selection C-05 |
| primary | [tasks/task0094-aligned-futures-research-panel.md](snapshots/primary/tasks/task0094-aligned-futures-research-panel.md) | TASK-0094 — Aligned Futures Research Panel |
| primary | [tasks/task0095-market-neutral-extreme-reversal.md](snapshots/primary/tasks/task0095-market-neutral-extreme-reversal.md) | TASK-0095 — Market-Neutral Extreme Reversal C-06 |
| primary | [tasks/task0096-volume-confirmed-acceleration.md](snapshots/primary/tasks/task0096-volume-confirmed-acceleration.md) | TASK-0096 — Volume-Confirmed Acceleration C-07 |
| primary | [tasks/task0097-daily-relative-strength.md](snapshots/primary/tasks/task0097-daily-relative-strength.md) | TASK-0097 — Daily Relative-Strength Continuation C-08 |
| primary | [tasks/task0098-c09-independent-holdout.md](snapshots/primary/tasks/task0098-c09-independent-holdout.md) | TASK-0098 — C-09 Independent Pre-2023 Holdout |
| primary | [tasks/task0099-extreme-negative-funding.md](snapshots/primary/tasks/task0099-extreme-negative-funding.md) | TASK-0099 — Extreme-Negative Funding Rebound C-10 |
| primary | [tasks/task0100-c11-prospective-funding-shadow.md](snapshots/primary/tasks/task0100-c11-prospective-funding-shadow.md) | TASK-0100 — C-11 Prospective Funding Shadow Cohort |
| primary | [tasks/task0101-cross-symbol-funding-generalization.md](snapshots/primary/tasks/task0101-cross-symbol-funding-generalization.md) | TASK-0101 — Cross-Symbol Funding Generalization C-12 |
| primary | [tasks/task0102-temporal-funding-generalization.md](snapshots/primary/tasks/task0102-temporal-funding-generalization.md) | TASK-0102 — Temporal Funding Generalization C-13 |
| primary | [tasks/task0103-long-horizon-time-series-momentum.md](snapshots/primary/tasks/task0103-long-horizon-time-series-momentum.md) | TASK-0103 — Long-Horizon Time-Series Momentum C-14 |
| primary | [tasks/task0104-independent-long-trend-holdout.md](snapshots/primary/tasks/task0104-independent-long-trend-holdout.md) | TASK-0104 — Independent Long-Only Trend Holdout C-15 |
| primary | [tasks/task0105-edge-evidence-synthesis.md](snapshots/primary/tasks/task0105-edge-evidence-synthesis.md) | TASK-0105 — Edge Evidence Synthesis and Sequential Research Gate |
| primary | [tasks/task0106-binance-historical-oi-panel.md](snapshots/primary/tasks/task0106-binance-historical-oi-panel.md) | TASK-0106 — Official Binance Historical OI Metrics Panel |
| primary | [tasks/task0107-oi-confirmed-price-impulse.md](snapshots/primary/tasks/task0107-oi-confirmed-price-impulse.md) | TASK-0107 — OI-Confirmed Price Impulse C-16 |
| primary | [tasks/task0108-oi-flush-exhaustion-reversal.md](snapshots/primary/tasks/task0108-oi-flush-exhaustion-reversal.md) | TASK-0108 — OI-Flush Exhaustion Reversal C-17 |
| primary | [tasks/task0109-binance-historical-bookdepth-panel.md](snapshots/primary/tasks/task0109-binance-historical-bookdepth-panel.md) | TASK-0109 — Official Binance Historical Book-Depth Panel |
| primary | [tasks/task0110-bookdepth-imbalance-c18.md](snapshots/primary/tasks/task0110-bookdepth-imbalance-c18.md) | TASK-0110 — Book-Depth Imbalance C-18 |
| primary | [tasks/task0111-liquidity-withdrawal-c19.md](snapshots/primary/tasks/task0111-liquidity-withdrawal-c19.md) | TASK-0111 — Liquidity-Withdrawal Differential C-19 |
| primary | [tasks/task0112-binance-premium-index-panel.md](snapshots/primary/tasks/task0112-binance-premium-index-panel.md) | TASK-0112 — Official Binance Historical Premium-Index Panel |
| primary | [tasks/task0113-premium-basis-convergence-c20.md](snapshots/primary/tasks/task0113-premium-basis-convergence-c20.md) | TASK-0113 — Symmetric Premium-Basis Convergence C-20 |
| primary | [tasks/task0114-binance-taker-flow-panel.md](snapshots/primary/tasks/task0114-binance-taker-flow-panel.md) | TASK-0114 — Official Binance Historical Taker-Flow Panel |
| primary | [tasks/task0115-taker-flow-continuation-c21.md](snapshots/primary/tasks/task0115-taker-flow-continuation-c21.md) | TASK-0115 — Aggressive Taker-Flow Continuation C-21 |
| primary | [tasks/task0116-independent-taker-flow-c22.md](snapshots/primary/tasks/task0116-independent-taker-flow-c22.md) | TASK-0116 — Independent Taker-Flow Confirmation C-22 |
| primary | [tasks/task0117-cross-family-evidence-synthesis.md](snapshots/primary/tasks/task0117-cross-family-evidence-synthesis.md) | TASK-0117 — Post-C22 Cross-Family Evidence Synthesis |
| primary | [tasks/task0118-binance-spot-panel.md](snapshots/primary/tasks/task0118-binance-spot-panel.md) | TASK-0118 — Official Binance Historical Spot Panel |
| primary | [tasks/task0119-delta-neutral-funding-carry-c23.md](snapshots/primary/tasks/task0119-delta-neutral-funding-carry-c23.md) | TASK-0119 — Delta-Neutral Positive-Funding Carry C-23 |
| primary | [tasks/task0120-post-c23-cross-family-synthesis.md](snapshots/primary/tasks/task0120-post-c23-cross-family-synthesis.md) | TASK-0120 — Post-C23 Cross-Family Evidence Synthesis |
| primary | [tasks/task0121-delta-neutral-basis-convergence-c24.md](snapshots/primary/tasks/task0121-delta-neutral-basis-convergence-c24.md) | TASK-0121 — Delta-Neutral Basis Convergence C-24 |
| primary | [tasks/task0122-post-c24-basis-synthesis.md](snapshots/primary/tasks/task0122-post-c24-basis-synthesis.md) | TASK-0122 — Post-C24 Basis-Convergence Synthesis |
| primary | [tasks/task0123-independent-spot-panel.md](snapshots/primary/tasks/task0123-independent-spot-panel.md) | TASK-0123 — Independent Official Binance Spot Panel |
| primary | [tasks/task0124-independent-basis-convergence-c25.md](snapshots/primary/tasks/task0124-independent-basis-convergence-c25.md) | TASK-0124 — Independent Basis-Convergence Confirmation C-25 |
| primary | [tasks/task0125-post-c25-family-synthesis.md](snapshots/primary/tasks/task0125-post-c25-family-synthesis.md) | TASK-0125 — Post-C25 Family Synthesis |
| primary | [tasks/task0126-btc-lead-alt-underreaction-c26.md](snapshots/primary/tasks/task0126-btc-lead-alt-underreaction-c26.md) | TASK-0126 — BTC-Lead / Alt-Underreaction C-26 |
| primary | [tasks/task0127-aggtrades-feasibility-census.md](snapshots/primary/tasks/task0127-aggtrades-feasibility-census.md) | TASK-0127 — Official Aggregate-Trades Feasibility Census |
| primary | [tasks/task0128-btc-aggtrades-panel.md](snapshots/primary/tasks/task0128-btc-aggtrades-panel.md) | TASK-0128 — Bounded Official BTC Aggregate-Trades Panel |
| primary | [tasks/task0129-recent-bingx-exit-audit.md](snapshots/primary/tasks/task0129-recent-bingx-exit-audit.md) | TASK-0129 — Recent BingX Exit-Management Forensic Audit |
| primary | [tasks/task0130-concentrated-aggressor-exhaustion-c27.md](snapshots/primary/tasks/task0130-concentrated-aggressor-exhaustion-c27.md) | TASK-0130 — Concentrated Aggressor Exhaustion C-27 |
| primary | [tasks/task0131-post-c27-cross-family-synthesis.md](snapshots/primary/tasks/task0131-post-c27-cross-family-synthesis.md) | TASK-0131 — Post-C27 Cross-Family Synthesis |
| primary | [tasks/task0132-leverage-consistency-audit.md](snapshots/primary/tasks/task0132-leverage-consistency-audit.md) | TASK-0132 — Leverage Consistency Audit |
| primary | [tasks/task0133-exit-event-ledger-spec.md](snapshots/primary/tasks/task0133-exit-event-ledger-spec.md) | TASK-0133 — Exit Event Ledger Specification |
| primary | [tasks/task0134-exit-event-ledger-writer.md](snapshots/primary/tasks/task0134-exit-event-ledger-writer.md) | TASK-0134 — Exit Event Ledger Writer |
| primary | [tasks/task0135-fail-closed-leverage-contract.md](snapshots/primary/tasks/task0135-fail-closed-leverage-contract.md) | TASK-0135 — Fail-Closed Authoritative Leverage Contract |
| primary | [tasks/task0136-profit-lock-admission-audit.md](snapshots/primary/tasks/task0136-profit-lock-admission-audit.md) | TASK-0136 — Forward Profit-Lock Candidate Admission Audit |
| primary | [tasks/task0137-forward-exit-observability-integration.md](snapshots/primary/tasks/task0137-forward-exit-observability-integration.md) | TASK-0137 — Forward Exit Observability Integration |
| primary | [tasks/task0138-forward-exit-causal-chain-audit.md](snapshots/primary/tasks/task0138-forward-exit-causal-chain-audit.md) | TASK-0138 — Forward Exit Causal-Chain Audit |
| primary | [tasks/task0139-stop-visibility-state-observability.md](snapshots/primary/tasks/task0139-stop-visibility-state-observability.md) | TASK-0139 — Stop Visibility and State Observability |
| primary | [tasks/task0140-hydration-fill-evidence-audit.md](snapshots/primary/tasks/task0140-hydration-fill-evidence-audit.md) | TASK-0140 — Restart Hydration and Exit-Fill Evidence Audit |
| primary | [tasks/task0141-restart-hydration-observability.md](snapshots/primary/tasks/task0141-restart-hydration-observability.md) | TASK-0141 — Restart Hydration Observability |
| primary | [tasks/task0142-terminal-fill-identity-audit.md](snapshots/primary/tasks/task0142-terminal-fill-identity-audit.md) | TASK-0142 — Terminal Fill Identity Audit |
| primary | [tasks/task0143-position-identity-snapshot-contract.md](snapshots/primary/tasks/task0143-position-identity-snapshot-contract.md) | TASK-0143 — Position Identity Snapshot Contract |
| primary | [tasks/task0144-position-identity-capture-integration.md](snapshots/primary/tasks/task0144-position-identity-capture-integration.md) | TASK-0144 — Position Identity Capture Integration |
| primary | [tasks/task0145-reconciliation-terminal-field-admission.md](snapshots/primary/tasks/task0145-reconciliation-terminal-field-admission.md) | TASK-0145 — Reconciliation Terminal-Field Admission |
| primary | [tasks/task0146-terminal-evidence-extractor.md](snapshots/primary/tasks/task0146-terminal-evidence-extractor.md) | TASK-0146 — Terminal Evidence Extractor |
| primary | [tasks/task0147-reconciliation-terminal-observer-integration.md](snapshots/primary/tasks/task0147-reconciliation-terminal-observer-integration.md) | TASK-0147 — Reconciliation Terminal Observer Integration |
| primary | [tasks/task0148-disconnected-exit-chain-verification.md](snapshots/primary/tasks/task0148-disconnected-exit-chain-verification.md) | TASK-0148 — Disconnected Exit-Evidence Chain Verification |
| primary | [tasks/task0149-terminal-journal-sync-contract.md](snapshots/primary/tasks/task0149-terminal-journal-sync-contract.md) | TASK-0149 — Terminal Journal Synchronization Contract |
| primary | [tasks/task0150-paper-terminal-journal-contract.md](snapshots/primary/tasks/task0150-paper-terminal-journal-contract.md) | TASK-0150 — Paper Terminal Journal Contract |
| primary | [tasks/task0151-forward-exit-evidence-runtime-gate.md](snapshots/primary/tasks/task0151-forward-exit-evidence-runtime-gate.md) | TASK-0151 — Forward Exit-Evidence Runtime Gate |
| primary | [tasks/task0152-forward-exit-cohort-auditor.md](snapshots/primary/tasks/task0152-forward-exit-cohort-auditor.md) | TASK-0152 — Forward Exit Cohort Gate Auditor |
| primary | [tasks/task0153-stop-visibility-failure-attribution.md](snapshots/primary/tasks/task0153-stop-visibility-failure-attribution.md) | TASK-0153 — Stop Visibility Failure Attribution |
| primary | [tasks/task0154-stop-identity-query-evidence-contract.md](snapshots/primary/tasks/task0154-stop-identity-query-evidence-contract.md) | TASK-0154 — Stop Identity and Query-Evidence Contract |
| primary | [tasks/task0155-forward-cohort-commit-guard.md](snapshots/primary/tasks/task0155-forward-cohort-commit-guard.md) | TASK-0155 — Forward Cohort Commit Guard |
| primary | [tasks/task0156-stop-identity-runtime-activation.md](snapshots/primary/tasks/task0156-stop-identity-runtime-activation.md) | TASK-0156 — Stop-Identity Runtime Activation |
| primary | [tasks/task0157-post-c31-mechanism-selection.md](snapshots/primary/tasks/task0157-post-c31-mechanism-selection.md) | TASK-0157 — Post-C31 Mechanism Selection |
| primary | [tasks/task0158-cross-venue-dislocation-preregistration.md](snapshots/primary/tasks/task0158-cross-venue-dislocation-preregistration.md) | TASK-0158 — Cross-Venue Perpetual Dislocation Preregistration |
| primary | [tasks/task0159-cross-venue-public-book-collector.md](snapshots/primary/tasks/task0159-cross-venue-public-book-collector.md) | TASK-0159 — Cross-Venue Public-Book Collector |
| primary | [tasks/task0160-c32-endpoint-semantics-review.md](snapshots/primary/tasks/task0160-c32-endpoint-semantics-review.md) | TASK-0160 — C-32 Endpoint Semantics Review |
| primary | [tasks/task0161-post-c32-mechanism-selection.md](snapshots/primary/tasks/task0161-post-c32-mechanism-selection.md) | TASK-0161 — Post-C32 Mechanism Selection |
| primary | [tasks/task0162-forced-liquidation-exhaustion-preregistration.md](snapshots/primary/tasks/task0162-forced-liquidation-exhaustion-preregistration.md) | TASK-0162 — Forced-Liquidation Exhaustion Preregistration |
| primary | [tasks/task0163-forced-liquidation-event-collector.md](snapshots/primary/tasks/task0163-forced-liquidation-event-collector.md) | TASK-0163 — Forced-Liquidation Event Collector |
| primary | [tasks/task0164-forced-liquidation-collector-review.md](snapshots/primary/tasks/task0164-forced-liquidation-collector-review.md) | TASK-0164 — Forced-Liquidation Collector Review |
| primary | [tasks/task0165-forced-liquidation-collector-activation.md](snapshots/primary/tasks/task0165-forced-liquidation-collector-activation.md) | TASK-0165 — Forced-Liquidation Collector Activation |
| primary | [tasks/task0166-c33-collection-auditor.md](snapshots/primary/tasks/task0166-c33-collection-auditor.md) | TASK-0166 — C-33 Collection Auditor |
| primary | [tasks/task0167-c33-forward-warmup-materializer.md](snapshots/primary/tasks/task0167-c33-forward-warmup-materializer.md) | TASK-0167 — C-33 Forward Warmup Materializer |
| primary | [tasks/task0168-c33-live-warmup-snapshot.md](snapshots/primary/tasks/task0168-c33-live-warmup-snapshot.md) | TASK-0168 — C-33 Live Warmup Snapshot |
| primary | [tasks/task0169-c33-snapshot-verifier.md](snapshots/primary/tasks/task0169-c33-snapshot-verifier.md) | TASK-0169 — C-33 Snapshot Verifier |
| primary | [tasks/task0170-c33-sparse-checkpoint-cadence.md](snapshots/primary/tasks/task0170-c33-sparse-checkpoint-cadence.md) | TASK-0170 — C-33 Sparse Checkpoint Cadence |
| primary | [tasks/task0171-next-independent-edge-selection.md](snapshots/primary/tasks/task0171-next-independent-edge-selection.md) | TASK-0171 — Next Independent Edge Selection |
| primary | [tasks/task0172-preregister-cross-venue-flow-c34.md](snapshots/primary/tasks/task0172-preregister-cross-venue-flow-c34.md) | TASK-0172 — Preregister C-34 Cross-Venue Aggressive-Flow Divergence |
| primary | [tasks/task0173-implement-cross-venue-flow-c34.md](snapshots/primary/tasks/task0173-implement-cross-venue-flow-c34.md) | TASK-0173 — Implement C-34 Cross-Venue Flow Evaluator |
| primary | [tasks/task0174-review-and-open-cross-venue-flow-c34.md](snapshots/primary/tasks/task0174-review-and-open-cross-venue-flow-c34.md) | TASK-0174 — Review and Open C-34 |
| primary | [tasks/task0175-cross-family-stop-decision.md](snapshots/primary/tasks/task0175-cross-family-stop-decision.md) | TASK-0175 — Cross-Family Synthesis and Historical Stop Decision |
| primary | [tasks/task0176-new-source-feasibility-review.md](snapshots/primary/tasks/task0176-new-source-feasibility-review.md) | TASK-0176 — New Public Source Feasibility Review |
| primary | [tasks/task0177-active-forward-exit-cohort-audit.md](snapshots/primary/tasks/task0177-active-forward-exit-cohort-audit.md) | TASK-0177 — Active forward-exit cohort audit |
| primary | [tasks/task0178-forward-exit-mutation-latency-diagnosis.md](snapshots/primary/tasks/task0178-forward-exit-mutation-latency-diagnosis.md) | TASK-0178 — Forward-exit mutation latency diagnosis |
| primary | [tasks/task0179-fail-closed-stop-mutation-contract.md](snapshots/primary/tasks/task0179-fail-closed-stop-mutation-contract.md) | TASK-0179 — Fail-closed stop-mutation correction contract |
| primary | [tasks/task0180-extended-bingx-exit-audit-preregistration.md](snapshots/primary/tasks/task0180-extended-bingx-exit-audit-preregistration.md) | TASK-0180 — Extended recent BingX exit audit preregistration |
| primary | [tasks/task0181-stop-failure-classification.md](snapshots/primary/tasks/task0181-stop-failure-classification.md) | TASK-0181 — Stop-failure classification primitive |
| primary | [tasks/task0182-bounded-stop-retry-consumer.md](snapshots/primary/tasks/task0182-bounded-stop-retry-consumer.md) | TASK-0182 — Bounded stop-retry consumer |
| primary | [tasks/task0183-priority-rate-limiter-primitive.md](snapshots/primary/tasks/task0183-priority-rate-limiter-primitive.md) | TASK-0183 — Bounded FIFO priority rate-limiter primitive |
| primary | [tasks/task0184-stop-priority-admission-wiring.md](snapshots/primary/tasks/task0184-stop-priority-admission-wiring.md) | TASK-0184 — Stop priority-admission wiring |
| primary | [tasks/task0185-stop-admission-independent-review.md](snapshots/primary/tasks/task0185-stop-admission-independent-review.md) | TASK-0185 — Stop-admission independent review |
| primary | [tasks/task0186-c33-100-bucket-checkpoint.md](snapshots/primary/tasks/task0186-c33-100-bucket-checkpoint.md) | TASK-0186 — C-33 100-bucket prospective checkpoint |
| primary | [tasks/task0187-predeployment-forward-cohort-audit.md](snapshots/primary/tasks/task0187-predeployment-forward-cohort-audit.md) | TASK-0187 — Pre-deployment forward-cohort audit |
| primary | [tasks/task0188-controlled-stop-fix-deployment-runbook.md](snapshots/primary/tasks/task0188-controlled-stop-fix-deployment-runbook.md) | TASK-0188 — Controlled stop-fix deployment runbook |
| primary | [tasks/task0189-preregister-prospective-net-floor.md](snapshots/primary/tasks/task0189-preregister-prospective-net-floor.md) | TASK-0189 — Preregister prospective net-profit floor |
| primary | [tasks/task0190-shadow-net-floor-math.md](snapshots/primary/tasks/task0190-shadow-net-floor-math.md) | TASK-0190 — Shadow net-floor math |
| primary | [tasks/task0191-causal-shadow-transitions.md](snapshots/primary/tasks/task0191-causal-shadow-transitions.md) | TASK-0191 — Causal shadow transitions |
| primary | [tasks/task0192-shadow-lifecycle-input-binding.md](snapshots/primary/tasks/task0192-shadow-lifecycle-input-binding.md) | TASK-0192 — Shadow lifecycle input binding |
| primary | [tasks/task0193-shadow-fee-provenance-gap.md](snapshots/primary/tasks/task0193-shadow-fee-provenance-gap.md) | TASK-0193 — Shadow fee-provenance contract audit |
| primary | [tasks/task0194-entry-fee-evidence-extractor.md](snapshots/primary/tasks/task0194-entry-fee-evidence-extractor.md) | TASK-0194 — Entry-fee evidence extractor |
| primary | [tasks/task0195-fee-schedule-snapshot-contract.md](snapshots/primary/tasks/task0195-fee-schedule-snapshot-contract.md) | TASK-0195 — Pre-activation fee-schedule snapshot contract |
| primary | [tasks/task0196-shadow-position-cost-binding.md](snapshots/primary/tasks/task0196-shadow-position-cost-binding.md) | TASK-0196 — Shadow position grouping and cost binding |
| primary | [tasks/task0197-terminal-linkage-cost-attribution-contract.md](snapshots/primary/tasks/task0197-terminal-linkage-cost-attribution-contract.md) | TASK-0197 — Authoritative terminal linkage and cost attribution contract |
| primary | [tasks/task0198-terminal-causal-linkage.md](snapshots/primary/tasks/task0198-terminal-causal-linkage.md) | TASK-0198 — Terminal causal linkage implementation |
| primary | [tasks/task0199-funding-slippage-input-contract.md](snapshots/primary/tasks/task0199-funding-slippage-input-contract.md) | TASK-0199 — Funding and slippage input contract |
| primary | [tasks/task0200-paired-position-outcome.md](snapshots/primary/tasks/task0200-paired-position-outcome.md) | TASK-0200 — Paired per-position outcome economics |
| primary | [tasks/task0201-state-funding-outcome-binding.md](snapshots/primary/tasks/task0201-state-funding-outcome-binding.md) | TASK-0201 — State, funding, and paired-outcome binding |
| primary | [tasks/task0202-shadow-minimum-coverage-gate.md](snapshots/primary/tasks/task0202-shadow-minimum-coverage-gate.md) | TASK-0202 — Frozen shadow minimum-coverage gate |
| primary | [tasks/task0203-shadow-aggregate-protocol.md](snapshots/primary/tasks/task0203-shadow-aggregate-protocol.md) | TASK-0203 — Frozen shadow aggregate protocol |
| primary | [tasks/task0204-shadow-aggregate-evaluator.md](snapshots/primary/tasks/task0204-shadow-aggregate-evaluator.md) | TASK-0204 — Deterministic shadow aggregate evaluator |
| primary | [tasks/task0205-shadow-evaluator-independent-review.md](snapshots/primary/tasks/task0205-shadow-evaluator-independent-review.md) | TASK-0205 — Shadow evaluator independent review |
| primary | [tasks/task0206-exit-shadow-artifact-freeze.md](snapshots/primary/tasks/task0206-exit-shadow-artifact-freeze.md) | TASK-0206 — Exit-shadow artifact freeze and activation blockers |
| primary | [tasks/task0207-exit-shadow-activation-gate.md](snapshots/primary/tasks/task0207-exit-shadow-activation-gate.md) | TASK-0207 — Exit-shadow activation-readiness gate |
| primary | [tasks/task0208-c33-collection-liveness-incident.md](snapshots/primary/tasks/task0208-c33-collection-liveness-incident.md) | TASK-0208 — C-33 collection liveness incident |
| primary | [tasks/task0209-c33-public-collector-resume-runbook.md](snapshots/primary/tasks/task0209-c33-public-collector-resume-runbook.md) | TASK-0209 — C-33 public collector resume runbook |
| primary | [tasks/task0210-c33-resume-verifier.md](snapshots/primary/tasks/task0210-c33-resume-verifier.md) | TASK-0210 — C-33 resume verifier |
| primary | [tasks/task0211-edge-search-admission-audit.md](snapshots/primary/tasks/task0211-edge-search-admission-audit.md) | TASK-0211 — Edge-search admission audit |
| primary | [tasks/task0212-local-data-independence-audit.md](snapshots/primary/tasks/task0212-local-data-independence-audit.md) | TASK-0212 — Local data independence audit |
| primary | [tasks/task0213-c33-resume-commit-binding.md](snapshots/primary/tasks/task0213-c33-resume-commit-binding.md) | TASK-0213 — C-33 resume commit binding |
| primary | [tasks/task0214-c33-resume-preflight-freeze.md](snapshots/primary/tasks/task0214-c33-resume-preflight-freeze.md) | TASK-0214 — C-33 resume preflight freeze |
| primary | [tasks/task0215-c33-preflight-integrity-verifier.md](snapshots/primary/tasks/task0215-c33-preflight-integrity-verifier.md) | TASK-0215 — C-33 preflight integrity verifier |
| primary | [tasks/task0216-prospective-roadmap-runtime-gate.md](snapshots/primary/tasks/task0216-prospective-roadmap-runtime-gate.md) | TASK-0216 — Prospective roadmap runtime gate |
| primary | [tasks/task0217-c33-controlled-resume.md](snapshots/primary/tasks/task0217-c33-controlled-resume.md) | TASK-0217 — C-33 controlled resume |
| primary | [tasks/task0218-c33-transient-reconnect.md](snapshots/primary/tasks/task0218-c33-transient-reconnect.md) | TASK-0218 — C-33 transient reconnect |
| primary | [tasks/task0219-c33-reconnect-recovery.md](snapshots/primary/tasks/task0219-c33-reconnect-recovery.md) | TASK-0219 — C-33 reconnect recovery |
| primary | [tasks/task0220-c33-500-bucket-checkpoint.md](snapshots/primary/tasks/task0220-c33-500-bucket-checkpoint.md) | TASK-0220 — C-33 500-bucket prospective checkpoint |
| primary | [tasks/task0221-c33-reconnect-observability.md](snapshots/primary/tasks/task0221-c33-reconnect-observability.md) | TASK-0221 — C-33 reconnect observability |
| primary | [tasks/task0222-c33-diagnostic-reload-recovery.md](snapshots/primary/tasks/task0222-c33-diagnostic-reload-recovery.md) | TASK-0222 — C-33 diagnostic reload recovery |
| primary | [tasks/task0223-investor-release-track.md](snapshots/primary/tasks/task0223-investor-release-track.md) | TASK-0223 — Investor release track |
| primary | [tasks/task0224-investor-release-gap-assessment.md](snapshots/primary/tasks/task0224-investor-release-gap-assessment.md) | TASK-0224 — Investor release gap assessment |
| primary | [tasks/task0225-investor-demo-state-isolation.md](snapshots/primary/tasks/task0225-investor-demo-state-isolation.md) | TASK-0225 — Investor demo state isolation |
| primary | [tasks/task0226-fail-closed-investor-demo-launcher.md](snapshots/primary/tasks/task0226-fail-closed-investor-demo-launcher.md) | TASK-0226 — Fail-closed investor demo launcher |
| primary | [tasks/task0227-controlled-investor-vst-order.md](snapshots/primary/tasks/task0227-controlled-investor-vst-order.md) | TASK-0227 — Controlled investor-visible VST order |
| primary | [tasks/task0228-investor-cost-adjusted-baseline.md](snapshots/primary/tasks/task0228-investor-cost-adjusted-baseline.md) | TASK-0228 — Investor-release cost-adjusted baseline |
| primary | [tasks/task0229-investor-and-agent-readmes.md](snapshots/primary/tasks/task0229-investor-and-agent-readmes.md) | TASK-0229 — Investor and agent review READMEs |
| primary | [tasks/task0230-investor-demo-research-separation.md](snapshots/primary/tasks/task0230-investor-demo-research-separation.md) | TASK-0230 — Investor-demo and research-data separation |
| primary | [tasks/task0231-current-vst-runtime-activation.md](snapshots/primary/tasks/task0231-current-vst-runtime-activation.md) | TASK-0231 — Current VST runtime activation |
| primary | [tasks/task0232-lynxion-vst-10x-launcher.md](snapshots/primary/tasks/task0232-lynxion-vst-10x-launcher.md) | TASK-0232 — Lynxion VST 10x launcher |
| primary | [tasks/task0233-execution-stablecoin-guard-runtime-repair.md](snapshots/primary/tasks/task0233-execution-stablecoin-guard-runtime-repair.md) | TASK-0233 — Execution stablecoin guard runtime repair |
| primary | [tasks/task0234-investor-release-evidence-freeze.md](snapshots/primary/tasks/task0234-investor-release-evidence-freeze.md) | TASK-0234 — Investor release evidence freeze |
| primary | [tasks/task0235-investor-baseline-input-freeze.md](snapshots/primary/tasks/task0235-investor-baseline-input-freeze.md) | TASK-0235 — Investor baseline input freeze |
| primary | [tasks/task0236-mfe-mae-provenance-coverage-audit.md](snapshots/primary/tasks/task0236-mfe-mae-provenance-coverage-audit.md) | TASK-0236 — MFE/MAE provenance and coverage audit |
| primary | [tasks/task0237-excursion-linkage-coverage.md](snapshots/primary/tasks/task0237-excursion-linkage-coverage.md) | TASK-0237 — Excursion linkage coverage |
| primary | [tasks/task0238-entry-versus-exit-classification.md](snapshots/primary/tasks/task0238-entry-versus-exit-classification.md) | TASK-0238 — Entry opportunity versus exit giveback classification |
| primary | [tasks/task0239-small-notional-mean-reversion-decomposition-preregistration.md](snapshots/primary/tasks/task0239-small-notional-mean-reversion-decomposition-preregistration.md) | TASK-0239 — Small-notional and MeanReversion causal decomposition preregistration |
| primary | [tasks/task0240-small-notional-mean-reversion-decomposition-outcome.md](snapshots/primary/tasks/task0240-small-notional-mean-reversion-decomposition-outcome.md) | TASK-0240 — Small-notional and MeanReversion decomposition outcome |
| primary | [tasks/task0241-preregister-c35-compression-release.md](snapshots/primary/tasks/task0241-preregister-c35-compression-release.md) | TASK-0241 — Preregister C-35 compression-release continuation |
| primary | [tasks/task0242-c35-boundary-contract-clarification.md](snapshots/primary/tasks/task0242-c35-boundary-contract-clarification.md) | TASK-0242 — C-35 boundary contract clarification |
| primary | [tasks/task0243-c35-causal-signal-evaluator.md](snapshots/primary/tasks/task0243-c35-causal-signal-evaluator.md) | TASK-0243 — C-35 causal signal evaluator |
| primary | [tasks/task0244-c35-public-candle-collector.md](snapshots/primary/tasks/task0244-c35-public-candle-collector.md) | TASK-0244 — C-35 public append-only candle collector |
| primary | [tasks/task0245-c35-activation-integrity-manifest.md](snapshots/primary/tasks/task0245-c35-activation-integrity-manifest.md) | TASK-0245 — C-35 activation integrity manifest |
| primary | [tasks/task0246-c35-controlled-public-activation.md](snapshots/primary/tasks/task0246-c35-controlled-public-activation.md) | TASK-0246 — C-35 controlled public activation |
| primary | [tasks/task0247-c35-candle-ledger-verifier.md](snapshots/primary/tasks/task0247-c35-candle-ledger-verifier.md) | TASK-0247 — C-35 candle-ledger verifier |
| primary | [tasks/task0248-c35-signal-state-append-contract.md](snapshots/primary/tasks/task0248-c35-signal-state-append-contract.md) | TASK-0248 — C-35 signal-state append contract |
| primary | [tasks/task0249-c35-signal-evaluation-bridge.md](snapshots/primary/tasks/task0249-c35-signal-evaluation-bridge.md) | TASK-0249 — C-35 signal-evaluation bridge |
| primary | [tasks/task0250-c35-first-controlled-evaluation.md](snapshots/primary/tasks/task0250-c35-first-controlled-evaluation.md) | TASK-0250 — C-35 first controlled evaluation |
| primary | [tasks/task0251-c35-outcome-resolver-core.md](snapshots/primary/tasks/task0251-c35-outcome-resolver-core.md) | TASK-0251 — C-35 outcome resolver core |
| primary | [tasks/task0252-c35-public-funding-collector.md](snapshots/primary/tasks/task0252-c35-public-funding-collector.md) | TASK-0252 — C-35 public funding collector |
| primary | [tasks/task0253-c35-funding-activation-preflight.md](snapshots/primary/tasks/task0253-c35-funding-activation-preflight.md) | TASK-0253 — C-35 funding activation preflight |
| primary | [tasks/task0254-c35-controlled-funding-activation.md](snapshots/primary/tasks/task0254-c35-controlled-funding-activation.md) | TASK-0254 — C-35 controlled funding activation |
| primary | [tasks/task0255-c35-funding-overlap-verifier-repair.md](snapshots/primary/tasks/task0255-c35-funding-overlap-verifier-repair.md) | TASK-0255 — C-35 funding overlap verifier repair |
| primary | [tasks/task0256-c35-hourly-evidence-checkpoint.md](snapshots/primary/tasks/task0256-c35-hourly-evidence-checkpoint.md) | TASK-0256 — C-35 hourly evidence checkpoint |
| primary | [tasks/task0257-c35-decision-evidence-contract.md](snapshots/primary/tasks/task0257-c35-decision-evidence-contract.md) | TASK-0257 — C-35 decision evidence contract |
| primary | [tasks/task0258-c35-decision-provenance-integration.md](snapshots/primary/tasks/task0258-c35-decision-provenance-integration.md) | TASK-0258 — C-35 decision provenance integration |
| primary | [tasks/task0259-c35-decision-provenance-activation.md](snapshots/primary/tasks/task0259-c35-decision-provenance-activation.md) | TASK-0259 — C-35 decision provenance activation |
| primary | [tasks/task0260-c35-outcome-orchestration.md](snapshots/primary/tasks/task0260-c35-outcome-orchestration.md) | TASK-0260 — C-35 outcome orchestration and aggregate sealing |
| primary | [tasks/task0261-c35-aggregate-unseal-gate.md](snapshots/primary/tasks/task0261-c35-aggregate-unseal-gate.md) | TASK-0261 — C-35 aggregate unseal gate |
| primary | [tasks/task0262-c35-signal-ledger-integrity.md](snapshots/primary/tasks/task0262-c35-signal-ledger-integrity.md) | TASK-0262 — C-35 signal-ledger integrity gate |
| primary | [tasks/task0263-c35-decision-ledger-integrity.md](snapshots/primary/tasks/task0263-c35-decision-ledger-integrity.md) | TASK-0263 — C-35 decision-ledger integrity |
| primary | [tasks/task0264-c35-decision-candle-binding.md](snapshots/primary/tasks/task0264-c35-decision-candle-binding.md) | TASK-0264 — C-35 decision-to-candle binding |
| primary | [tasks/task0265-c35-unseal-integrity-chain.md](snapshots/primary/tasks/task0265-c35-unseal-integrity-chain.md) | TASK-0265 — C-35 unseal integrity chain |
| primary | [tasks/task0266-c35-outcome-source-binding.md](snapshots/primary/tasks/task0266-c35-outcome-source-binding.md) | TASK-0266 — C-35 outcome-to-source binding |
| primary | [tasks/task0267-c35-unseal-source-binding.md](snapshots/primary/tasks/task0267-c35-unseal-source-binding.md) | TASK-0267 — C-35 unseal-to-source binding |
| primary | [tasks/task0268-c35-aggregate-math-preregistration.md](snapshots/primary/tasks/task0268-c35-aggregate-math-preregistration.md) | TASK-0268 — C-35 aggregate-math preregistration |
| primary | [tasks/task0269-c35-frozen-aggregate-evaluator.md](snapshots/primary/tasks/task0269-c35-frozen-aggregate-evaluator.md) | TASK-0269 — C-35 frozen aggregate evaluator |
| primary | [tasks/task0270-c35-aggregate-activation-preflight.md](snapshots/primary/tasks/task0270-c35-aggregate-activation-preflight.md) | TASK-0270 — C-35 aggregate activation preflight |
| primary | [tasks/task0271-c35-evaluator-preflight-wiring.md](snapshots/primary/tasks/task0271-c35-evaluator-preflight-wiring.md) | TASK-0271 — C-35 evaluator preflight wiring |
| primary | [tasks/task0272-c35-hourly-orchestrator.md](snapshots/primary/tasks/task0272-c35-hourly-orchestrator.md) | TASK-0272 — C-35 hourly public orchestrator |
| primary | [tasks/task0273-c35-signal-throughput-checkpoint.md](snapshots/primary/tasks/task0273-c35-signal-throughput-checkpoint.md) | TASK-0273 — C-35 signal-throughput checkpoint |
| primary | [tasks/task0274-c35-throughput-pipeline-integration.md](snapshots/primary/tasks/task0274-c35-throughput-pipeline-integration.md) | TASK-0274 — C-35 throughput pipeline integration |
| primary | [tasks/task0275-exit-shadow-static-readiness-refresh.md](snapshots/primary/tasks/task0275-exit-shadow-static-readiness-refresh.md) | TASK-0275 — Exit-shadow static readiness refresh |
| primary | [tasks/task0276-exit-shadow-empty-cohort.md](snapshots/primary/tasks/task0276-exit-shadow-empty-cohort.md) | TASK-0276 — Exit-shadow new empty cohort |
| primary | [tasks/task0277-exit-shadow-bingx-fee-snapshot.md](snapshots/primary/tasks/task0277-exit-shadow-bingx-fee-snapshot.md) | TASK-0277 — Exit-shadow BingX public fee snapshot |
| primary | [tasks/task0278-exit-shadow-replacement-cohort.md](snapshots/primary/tasks/task0278-exit-shadow-replacement-cohort.md) | TASK-0278 — Exit-shadow post-fee replacement cohort |
| primary | [tasks/task0279-c35-hourly-checkpoint-41.md](snapshots/primary/tasks/task0279-c35-hourly-checkpoint-41.md) | TASK-0279 — C-35 hourly checkpoint at 41 decisions |
| primary | [tasks/task0280-c35-hourly-checkpoint-42.md](snapshots/primary/tasks/task0280-c35-hourly-checkpoint-42.md) | TASK-0280 — C-35 hourly checkpoint at 42 decisions |
| primary | [tasks/task0281-c35-hourly-checkpoint-45.md](snapshots/primary/tasks/task0281-c35-hourly-checkpoint-45.md) | TASK-0281 — C-35 hourly checkpoint at 45 decisions |
| primary | [tasks/task0282-c35-hourly-checkpoint-46.md](snapshots/primary/tasks/task0282-c35-hourly-checkpoint-46.md) | TASK-0282 — C-35 hourly checkpoint at 46 decisions |
| primary | [tasks/task0283-c35-checkpoint-47-c11-refresh.md](snapshots/primary/tasks/task0283-c35-checkpoint-47-c11-refresh.md) | TASK-0283 — C-35 checkpoint 47 and scheduled C-11 refresh |
| primary | [tasks/task0284-c35-hourly-checkpoint-48.md](snapshots/primary/tasks/task0284-c35-hourly-checkpoint-48.md) | TASK-0284 — C-35 hourly checkpoint at 48 decisions |
| primary | [tasks/task0285-c35-hourly-checkpoint-49.md](snapshots/primary/tasks/task0285-c35-hourly-checkpoint-49.md) | TASK-0285 — C-35 hourly checkpoint at 49 decisions |
| primary | [tasks/task0286-c35-hourly-checkpoint-50.md](snapshots/primary/tasks/task0286-c35-hourly-checkpoint-50.md) | TASK-0286 — C-35 hourly checkpoint at 50 decisions |
| primary | [tasks/task0287-c35-checkpoint-51-c33-liveness.md](snapshots/primary/tasks/task0287-c35-checkpoint-51-c33-liveness.md) | TASK-0287 — C-35 checkpoint 51 and C-33 liveness |
| primary | [tasks/task0288-c35-hourly-checkpoint-52.md](snapshots/primary/tasks/task0288-c35-hourly-checkpoint-52.md) | TASK-0288 — C-35 hourly checkpoint at 52 decisions |
| primary | [tasks/task0289-exit-shadow-readiness-evidence-integration.md](snapshots/primary/tasks/task0289-exit-shadow-readiness-evidence-integration.md) | TASK-0289 — Exit-shadow readiness evidence integration |
| primary | [tasks/task0290-c35-hourly-checkpoint-53.md](snapshots/primary/tasks/task0290-c35-hourly-checkpoint-53.md) | TASK-0290 — C-35 hourly checkpoint at 53 decisions |
| primary | [tasks/task0291-c35-hourly-checkpoint-54.md](snapshots/primary/tasks/task0291-c35-hourly-checkpoint-54.md) | TASK-0291 — C-35 hourly checkpoint at 54 decisions |
| primary | [tasks/task0292-c35-first-prospective-signal.md](snapshots/primary/tasks/task0292-c35-first-prospective-signal.md) | TASK-0292 — C-35 first prospective signal |
| primary | [tasks/task0293-c35-unresolved-signal-orchestration-fix.md](snapshots/primary/tasks/task0293-c35-unresolved-signal-orchestration-fix.md) | TASK-0293 — C-35 unresolved-signal orchestration fix |
| primary | [tasks/task0294-c35-first-outcome-second-signal.md](snapshots/primary/tasks/task0294-c35-first-outcome-second-signal.md) | TASK-0294 — C-35 first outcome and second signal |
| primary | [tasks/task0295-c35-second-positive-outcome.md](snapshots/primary/tasks/task0295-c35-second-positive-outcome.md) | TASK-0295 — C-35 second prospective outcome |
| primary | [tasks/task0296-c35-hourly-checkpoint-59.md](snapshots/primary/tasks/task0296-c35-hourly-checkpoint-59.md) | TASK-0296 — C-35 hourly checkpoint at 59 decisions |
| primary | [tasks/task0297-c35-hourly-checkpoint-60.md](snapshots/primary/tasks/task0297-c35-hourly-checkpoint-60.md) | TASK-0297 — C-35 hourly checkpoint at 60 decisions |
| primary | [tasks/task0298-c35-hourly-checkpoint-61.md](snapshots/primary/tasks/task0298-c35-hourly-checkpoint-61.md) | TASK-0298 — C-35 hourly checkpoint at 61 decisions |
| primary | [tasks/task0299-c35-hourly-checkpoint-62.md](snapshots/primary/tasks/task0299-c35-hourly-checkpoint-62.md) | TASK-0299 — C-35 hourly checkpoint at 62 decisions |
| primary | [tasks/task0300-c35-checkpoint-63-c11-refresh.md](snapshots/primary/tasks/task0300-c35-checkpoint-63-c11-refresh.md) | TASK-0300 — C-35 checkpoint 63 and scheduled C-11 refresh |
| primary | [tasks/task0301-c35-hourly-checkpoint-64.md](snapshots/primary/tasks/task0301-c35-hourly-checkpoint-64.md) | TASK-0301 — C-35 hourly checkpoint at 64 decisions |
| primary | [tasks/task0302-c35-hourly-checkpoint-65.md](snapshots/primary/tasks/task0302-c35-hourly-checkpoint-65.md) | TASK-0302 — C-35 hourly checkpoint at 65 decisions |
| primary | [tasks/task0303-c35-hourly-checkpoint-67.md](snapshots/primary/tasks/task0303-c35-hourly-checkpoint-67.md) | TASK-0303 — C-35 hourly checkpoint at 67 decisions |
| primary | [tasks/task0304-c35-hourly-checkpoint-68.md](snapshots/primary/tasks/task0304-c35-hourly-checkpoint-68.md) | TASK-0304 — C-35 hourly checkpoint at 68 decisions |
| primary | [tasks/task0305-c35-hourly-checkpoint-69.md](snapshots/primary/tasks/task0305-c35-hourly-checkpoint-69.md) | TASK-0305 — C-35 hourly checkpoint at 69 decisions |
| primary | [tasks/task0306-c35-hourly-checkpoint-70.md](snapshots/primary/tasks/task0306-c35-hourly-checkpoint-70.md) | TASK-0306 — C-35 hourly checkpoint at 70 decisions |
| primary | [tasks/task0307-c35-hourly-checkpoint-71.md](snapshots/primary/tasks/task0307-c35-hourly-checkpoint-71.md) | TASK-0307 — C-35 hourly checkpoint at 71 decisions |
| primary | [tasks/task0308-c35-hourly-checkpoint-72.md](snapshots/primary/tasks/task0308-c35-hourly-checkpoint-72.md) | TASK-0308 — C-35 hourly checkpoint at 72 decisions |
| primary | [tasks/task0309-c35-hourly-checkpoint-73.md](snapshots/primary/tasks/task0309-c35-hourly-checkpoint-73.md) | TASK-0309 — C-35 hourly checkpoint at 73 decisions |
| primary | [tasks/task0310-c35-hourly-checkpoint-74.md](snapshots/primary/tasks/task0310-c35-hourly-checkpoint-74.md) | TASK-0310 — C-35 hourly checkpoint at 74 decisions |
| primary | [tasks/task0311-c35-hourly-checkpoint-75.md](snapshots/primary/tasks/task0311-c35-hourly-checkpoint-75.md) | TASK-0311 — C-35 hourly checkpoint at 75 decisions |
| primary | [tasks/task0312-c35-hourly-checkpoint-77.md](snapshots/primary/tasks/task0312-c35-hourly-checkpoint-77.md) | TASK-0312 — C-35 hourly checkpoint at 77 decisions |
| primary | [tasks/task0313-c35-hourly-checkpoint-78.md](snapshots/primary/tasks/task0313-c35-hourly-checkpoint-78.md) | TASK-0313 — C-35 hourly checkpoint at 78 decisions |
| primary | [tasks/task0314-c35-checkpoint-79-and-c11-candidate.md](snapshots/primary/tasks/task0314-c35-checkpoint-79-and-c11-candidate.md) | TASK-0314 — C-35 checkpoint 79 and C-11 prospective candidate |
| primary | [tasks/task0315-c35-hourly-checkpoint-80.md](snapshots/primary/tasks/task0315-c35-hourly-checkpoint-80.md) | TASK-0315 — C-35 hourly checkpoint at 80 decisions |
| primary | [tasks/task0316-c35-hourly-checkpoint-81.md](snapshots/primary/tasks/task0316-c35-hourly-checkpoint-81.md) | TASK-0316 — C-35 hourly checkpoint at 81 decisions |
| primary | [tasks/task0317-c35-hourly-checkpoint-82.md](snapshots/primary/tasks/task0317-c35-hourly-checkpoint-82.md) | TASK-0317 — C-35 hourly checkpoint at 82 decisions |
| primary | [tasks/task0318-c35-hourly-checkpoint-83.md](snapshots/primary/tasks/task0318-c35-hourly-checkpoint-83.md) | TASK-0318 — C-35 hourly checkpoint at 83 decisions |
| primary | [tasks/task0319-c35-hourly-checkpoint-84.md](snapshots/primary/tasks/task0319-c35-hourly-checkpoint-84.md) | TASK-0319 — C-35 hourly checkpoint at 84 decisions |
| primary | [tasks/task0320-c35-hourly-checkpoint-85.md](snapshots/primary/tasks/task0320-c35-hourly-checkpoint-85.md) | TASK-0320 — C-35 hourly checkpoint at 85 decisions |
| primary | [tasks/task0321-c35-hourly-checkpoint-86.md](snapshots/primary/tasks/task0321-c35-hourly-checkpoint-86.md) | TASK-0321 — C-35 hourly checkpoint at 86 decisions |
| primary | [tasks/task0322-c35-checkpoint-87-and-c11-refresh.md](snapshots/primary/tasks/task0322-c35-checkpoint-87-and-c11-refresh.md) | TASK-0322 — C-35 checkpoint 87 and due C-11 refresh |
| primary | [tasks/task0323-c35-hourly-checkpoint-88.md](snapshots/primary/tasks/task0323-c35-hourly-checkpoint-88.md) | TASK-0323 — C-35 hourly checkpoint at 88 decisions |
| primary | [tasks/task0324-roadmap-and-project-context-reconciliation.md](snapshots/primary/tasks/task0324-roadmap-and-project-context-reconciliation.md) | TASK-0324 — Roadmap and project-context reconciliation |
| primary | [tasks/task0325-ai-context-handoff-pack.md](snapshots/primary/tasks/task0325-ai-context-handoff-pack.md) | TASK-0325 — AI context handoff pack |
| primary | [tasks/task0326-remove-superseded-misleading-documents.md](snapshots/primary/tasks/task0326-remove-superseded-misleading-documents.md) | TASK-0326 — Remove superseded misleading documents |
| primary | [tasks/task0327-single-file-ai-handoff.md](snapshots/primary/tasks/task0327-single-file-ai-handoff.md) | TASK-0327 — Complete single-file AI handoff |
| primary | [tasks/task0328-task-doc-directory-separation.md](snapshots/primary/tasks/task0328-task-doc-directory-separation.md) | TASK-0328 — Task/document directory separation |
| primary | [tasks/task0329-c35-hourly-checkpoint-89.md](snapshots/primary/tasks/task0329-c35-hourly-checkpoint-89.md) | TASK-0329 — C-35 hourly checkpoint at 89 decisions |
| primary | [tasks/task0330-edge-acceleration-decision-gate.md](snapshots/primary/tasks/task0330-edge-acceleration-decision-gate.md) | TASK-0330 — Edge acceleration decision gate |
| primary | [tasks/task0331-c33-stale-session-recovery.md](snapshots/primary/tasks/task0331-c33-stale-session-recovery.md) | TASK-0331 — C-33 stale-session recovery guard |
| primary | [tasks/task0332-c33-controlled-liveness-restore.md](snapshots/primary/tasks/task0332-c33-controlled-liveness-restore.md) | TASK-0332 — C-33 controlled collector liveness restore |
| primary | [tasks/task0333-c35-hourly-checkpoint-90.md](snapshots/primary/tasks/task0333-c35-hourly-checkpoint-90.md) | TASK-0333 — C-35 hourly checkpoint at 90 decisions |
| primary | [tasks/task0334-bingx-nonfinite-exposure-admission.md](snapshots/primary/tasks/task0334-bingx-nonfinite-exposure-admission.md) | TASK-0334 — BingX non-finite exposure admission guard |
| primary | [tasks/task0335-nonfinite-order-risk-admission.md](snapshots/primary/tasks/task0335-nonfinite-order-risk-admission.md) | TASK-0335 — Non-finite order risk admission guard |
| primary | [tasks/task0336-c35-hourly-checkpoint-91.md](snapshots/primary/tasks/task0336-c35-hourly-checkpoint-91.md) | TASK-0336 — C-35 hourly checkpoint at 91 decisions |
| primary | [tasks/task0337-c35-hourly-checkpoint-92.md](snapshots/primary/tasks/task0337-c35-hourly-checkpoint-92.md) | TASK-0337 — C-35 hourly checkpoint at 92 decisions |
| primary | [tasks/task0338-c35-hourly-checkpoint-93.md](snapshots/primary/tasks/task0338-c35-hourly-checkpoint-93.md) | TASK-0338 — C-35 hourly checkpoint at 93 decisions |
| primary | [tasks/task0339-c35-hourly-checkpoint-94.md](snapshots/primary/tasks/task0339-c35-hourly-checkpoint-94.md) | TASK-0339 — C-35 hourly checkpoint at 94 decisions |
| primary | [tasks/task0340-c11-third-outcome-c35-checkpoint-95.md](snapshots/primary/tasks/task0340-c11-third-outcome-c35-checkpoint-95.md) | TASK-0340 — C-11 third outcome and C-35 checkpoint 95 |
| primary | [tasks/task0341-c35-hourly-checkpoint-96.md](snapshots/primary/tasks/task0341-c35-hourly-checkpoint-96.md) | TASK-0341 — C-35 hourly checkpoint at 96 decisions |
| primary | [tasks/task0342-c35-hourly-checkpoint-97.md](snapshots/primary/tasks/task0342-c35-hourly-checkpoint-97.md) | TASK-0342 — C-35 hourly checkpoint at 97 decisions |
| primary | [tasks/task0343-c35-hourly-checkpoint-98.md](snapshots/primary/tasks/task0343-c35-hourly-checkpoint-98.md) | TASK-0343 — C-35 hourly checkpoint at 98 decisions |
| primary | [tasks/task0344-c35-hourly-checkpoint-99.md](snapshots/primary/tasks/task0344-c35-hourly-checkpoint-99.md) | TASK-0344 — C-35 hourly checkpoint at 99 decisions |
| primary | [tasks/task0345-c35-hourly-checkpoint-100.md](snapshots/primary/tasks/task0345-c35-hourly-checkpoint-100.md) | TASK-0345 — C-35 hourly checkpoint at 100 decisions |
| primary | [tasks/task0346-c35-hourly-checkpoint-101.md](snapshots/primary/tasks/task0346-c35-hourly-checkpoint-101.md) | TASK-0346 — C-35 hourly checkpoint at 101 decisions |
| primary | [tasks/task0347-c35-hourly-checkpoint-102.md](snapshots/primary/tasks/task0347-c35-hourly-checkpoint-102.md) | TASK-0347 — C-35 hourly checkpoint at 102 decisions |
| primary | [tasks/task0348-c35-hourly-checkpoint-103.md](snapshots/primary/tasks/task0348-c35-hourly-checkpoint-103.md) | TASK-0348 — C-35 hourly checkpoint at 103 decisions |
| primary | [tasks/task0349-c35-hourly-checkpoint-104.md](snapshots/primary/tasks/task0349-c35-hourly-checkpoint-104.md) | TASK-0349 — C-35 hourly checkpoint at 104 decisions |
| primary | [tasks/task0350-c35-hourly-checkpoint-105.md](snapshots/primary/tasks/task0350-c35-hourly-checkpoint-105.md) | TASK-0350 — C-35 hourly checkpoint at 105 decisions |
| primary | [tasks/task0351-c35-hourly-checkpoint-106.md](snapshots/primary/tasks/task0351-c35-hourly-checkpoint-106.md) | TASK-0351 — C-35 hourly checkpoint at 106 decisions |
| primary | [tasks/task0352-c35-hourly-checkpoint-108.md](snapshots/primary/tasks/task0352-c35-hourly-checkpoint-108.md) | TASK-0352 — C-35 hourly checkpoint at 108 decisions |
| primary | [tasks/task0353-c35-hourly-checkpoint-109.md](snapshots/primary/tasks/task0353-c35-hourly-checkpoint-109.md) | TASK-0353 — C-35 hourly checkpoint at 109 decisions |
| primary | [tasks/task0354-c11-new-candidate-c35-111.md](snapshots/primary/tasks/task0354-c11-new-candidate-c35-111.md) | TASK-0354 — C-11 new candidate and C-35 checkpoint at 111 decisions |
| primary | [tasks/task0355-c35-hourly-checkpoint-112.md](snapshots/primary/tasks/task0355-c35-hourly-checkpoint-112.md) | TASK-0355 — C-35 hourly checkpoint at 112 decisions |
| primary | [tasks/task0356-c33-1000-bucket-checkpoint.md](snapshots/primary/tasks/task0356-c33-1000-bucket-checkpoint.md) | TASK-0356 — C-33 crosses the 1,000-bucket checkpoint |
| primary | [tasks/task0357-c35-hourly-checkpoint-114.md](snapshots/primary/tasks/task0357-c35-hourly-checkpoint-114.md) | TASK-0357 — C-35 hourly checkpoint at 114 decisions |
| primary | [tasks/task0358-exit-shadow-readiness-and-c35-115.md](snapshots/primary/tasks/task0358-exit-shadow-readiness-and-c35-115.md) | TASK-0358 — Exit-shadow readiness and C-35 checkpoint at 115 |
| primary | [tasks/task0359-exit-shadow-read-only-runtime-preflight.md](snapshots/primary/tasks/task0359-exit-shadow-read-only-runtime-preflight.md) | TASK-0359 — Exit-shadow read-only runtime preflight |
| primary | [tasks/task0360-c35-recovered-checkpoint-118.md](snapshots/primary/tasks/task0360-c35-recovered-checkpoint-118.md) | TASK-0360 — C-35 recovered hourly checkpoint at 118 decisions |
| primary | [tasks/task0361-c35-catchup-124-c11-boundary-check.md](snapshots/primary/tasks/task0361-c35-catchup-124-c11-boundary-check.md) | TASK-0361 — C-35 catch-up to 124 and C-11 boundary check |
| primary | [tasks/task0362-c35-hourly-checkpoint-125.md](snapshots/primary/tasks/task0362-c35-hourly-checkpoint-125.md) | TASK-0362 — C-35 hourly checkpoint at 125 decisions |
| primary | [tasks/task0363-c35-hourly-checkpoint-126.md](snapshots/primary/tasks/task0363-c35-hourly-checkpoint-126.md) | TASK-0363 — C-35 hourly checkpoint at 126 decisions |
| primary | [tasks/task0364-c35-coverage-refresh-no-new-decision.md](snapshots/primary/tasks/task0364-c35-coverage-refresh-no-new-decision.md) | TASK-0364 — C-35 coverage refresh with no new closed decision hour |
| primary | [tasks/task0365-c35-hourly-checkpoint-128.md](snapshots/primary/tasks/task0365-c35-hourly-checkpoint-128.md) | TASK-0365 — C-35 hourly checkpoint at 128 decisions |
| primary | [tasks/task0366-c35-coverage-refresh-128.md](snapshots/primary/tasks/task0366-c35-coverage-refresh-128.md) | TASK-0366 — C-35 coverage refresh at 128 completed decisions |
| primary | [tasks/task0367-autonomous-edge-mission-and-a1-data-gate.md](snapshots/primary/tasks/task0367-autonomous-edge-mission-and-a1-data-gate.md) | TASK-0367 — Autonomous edge mission and A1 data gate |
| primary | [tasks/task0368-a1-exploratory-feasibility-contract.md](snapshots/primary/tasks/task0368-a1-exploratory-feasibility-contract.md) | TASK-0368 — A1 exploratory mean-reversion plus aggressive-flow contract |
| primary | [tasks/task0369-a1-exploratory-falsification.md](snapshots/primary/tasks/task0369-a1-exploratory-falsification.md) | TASK-0369 — A1 exploratory aggressive-flow falsification |
| primary | [tasks/task0370-funding-state-feasibility-and-c35-130.md](snapshots/primary/tasks/task0370-funding-state-feasibility-and-c35-130.md) | TASK-0370 — Funding-state feasibility and C-35 checkpoint 130 |
| primary | [tasks/task0371-momentum-feasibility-and-c35-131.md](snapshots/primary/tasks/task0371-momentum-feasibility-and-c35-131.md) | TASK-0371 — Time-series momentum feasibility and C-35 checkpoint 131 |
| primary | [tasks/task0372-liquidation-oi-feasibility-c11-outcome.md](snapshots/primary/tasks/task0372-liquidation-oi-feasibility-c11-outcome.md) | TASK-0372 — Liquidation/OI feasibility, C-11 outcome, and C-35 checkpoint 132 |
| primary | [tasks/task0373-order-flow-toxicity-feasibility-c35-133.md](snapshots/primary/tasks/task0373-order-flow-toxicity-feasibility-c35-133.md) | TASK-0373 — Order-flow toxicity feasibility and C-35 checkpoint 133 |
| primary | [tasks/task0374-five-family-portfolio-verdict-c35-134.md](snapshots/primary/tasks/task0374-five-family-portfolio-verdict-c35-134.md) | TASK-0374 — Five-family portfolio verdict and C-35 checkpoint 134 |
| primary | [tasks/task0375-leverage-correctness-state-reconciliation-c35-135.md](snapshots/primary/tasks/task0375-leverage-correctness-state-reconciliation-c35-135.md) | TASK-0375 — Leverage correctness-state reconciliation and C-35 checkpoint 135 |
| primary | [tasks/task0376-exit-shadow-recorded-blocker-reporting-c35-coverage.md](snapshots/primary/tasks/task0376-exit-shadow-recorded-blocker-reporting-c35-coverage.md) | TASK-0376 — Exit-shadow recorded-blocker reporting and C-35 coverage refresh |
| primary | [tasks/task0377-external-history-coverage-gate-c35-137.md](snapshots/primary/tasks/task0377-external-history-coverage-gate-c35-137.md) | TASK-0377 — External historical-data coverage gate and C-35 checkpoint 137 |
| primary | [tasks/task0378-historical-market-type-semantics-audit-c35-138.md](snapshots/primary/tasks/task0378-historical-market-type-semantics-audit-c35-138.md) | TASK-0378 — Historical market-type semantics audit and C-35 checkpoint 138 |
| primary | [tasks/task0379-official-market-type-mapping-c11-c35.md](snapshots/primary/tasks/task0379-official-market-type-mapping-c11-c35.md) | TASK-0379 — Official historical market-type mapping and frozen cohort refresh |
| primary | [tasks/task0380-historical-market-contract-c35-149.md](snapshots/primary/tasks/task0380-historical-market-contract-c35-149.md) | TASK-0380 — Fail-closed historical market contract and C-35 checkpoint 149 |
| primary | [tasks/task0381-integrate-historical-market-routing-c35-150.md](snapshots/primary/tasks/task0381-integrate-historical-market-routing-c35-150.md) | TASK-0381 — Integrate fail-closed historical market routing and C-35 checkpoint 150 |
| primary | [tasks/task0382-new-edge-lead-tournament.md](snapshots/primary/tasks/task0382-new-edge-lead-tournament.md) | TASK-0382 — New edge lead tournament |
| primary | [tasks/task0383-lead-a-provenance-gate.md](snapshots/primary/tasks/task0383-lead-a-provenance-gate.md) | TASK-0383 — Lead-A profit-giveback provenance gate |
| primary | [tasks/task0384-lead-b-temporal-readiness.md](snapshots/primary/tasks/task0384-lead-b-temporal-readiness.md) | TASK-0384 — Lead-B quarter-hour temporal-resolution gate |
| primary | [tasks/task0385-lead-b-replication-preregistration.md](snapshots/primary/tasks/task0385-lead-b-replication-preregistration.md) | TASK-0385 — Lead-B quarter-hour replication preregistration |
| primary | [tasks/task0386-lead-b-quarter-hour-replication.md](snapshots/primary/tasks/task0386-lead-b-quarter-hour-replication.md) | TASK-0386 — Lead-B quarter-hour flow replication |
| primary | [tasks/task0387-lead-b-economic-holdout-preregistration.md](snapshots/primary/tasks/task0387-lead-b-economic-holdout-preregistration.md) | TASK-0387 — Lead-B economic holdout preregistration |
| primary | [tasks/task0388-lead-b-economic-holdout-verdict.md](snapshots/primary/tasks/task0388-lead-b-economic-holdout-verdict.md) | TASK-0388 — Lead-B economic holdout verdict |
| primary | [tasks/task0389-c35-hourly-and-c33-freshness.md](snapshots/primary/tasks/task0389-c35-hourly-and-c33-freshness.md) | TASK-0389 — C-35 hourly integrity and C-33 freshness alert |
| primary | [tasks/task0390-c35-throughput-gate.md](snapshots/primary/tasks/task0390-c35-throughput-gate.md) | TASK-0390 — C-35 frozen throughput gate |
| primary | [tasks/task0391-funding-clock-data-readiness.md](snapshots/primary/tasks/task0391-funding-clock-data-readiness.md) | TASK-0391 — Funding Settlement market-quality data readiness |
| primary | [tasks/task0392-funding-clock-preregistration.md](snapshots/primary/tasks/task0392-funding-clock-preregistration.md) | TASK-0392 — Funding Settlement market-quality preregistration |
| primary | [tasks/task0393-funding-clock-verdict.md](snapshots/primary/tasks/task0393-funding-clock-verdict.md) | TASK-0393 — Funding Settlement market-quality verdict |
| primary | [tasks/task0394-rescue-ladder-funding-evidence-synthesis.md](snapshots/primary/tasks/task0394-rescue-ladder-funding-evidence-synthesis.md) | TASK-0394 — Rescue Ladder and Funding evidence synthesis |
| primary | [tasks/task0395-c33-collector-freshness-restoration.md](snapshots/primary/tasks/task0395-c33-collector-freshness-restoration.md) | TASK-0395 — C-33 collector freshness restoration |
| primary | [tasks/task0396-c33-post-resume-productivity.md](snapshots/primary/tasks/task0396-c33-post-resume-productivity.md) | TASK-0396 — C-33 post-resume productivity verification |
| primary | [tasks/task0397-single-runner-invariant-refresh.md](snapshots/primary/tasks/task0397-single-runner-invariant-refresh.md) | TASK-0397 — Single-runner invariant refresh |
| primary | [tasks/task0398-nonfinite-sltp-sanitization.md](snapshots/primary/tasks/task0398-nonfinite-sltp-sanitization.md) | TASK-0398 — Non-finite SL/TP sanitization |
| primary | [tasks/task0399-bingx-final-numeric-admission.md](snapshots/primary/tasks/task0399-bingx-final-numeric-admission.md) | TASK-0399 — BingX final exchange-boundary numeric admission |
| primary | [tasks/task0400-bingx-final-entry-contract.md](snapshots/primary/tasks/task0400-bingx-final-entry-contract.md) | TASK-0400 — BingX final entry-contract admission |
| primary | [tasks/task0401-bingx-final-identity-contract.md](snapshots/primary/tasks/task0401-bingx-final-identity-contract.md) | TASK-0401 — BingX final symbol and position identity contract |
| primary | [tasks/task0402-bingx-final-client-order-id-contract.md](snapshots/primary/tasks/task0402-bingx-final-client-order-id-contract.md) | TASK-0402 — BingX final client-order-id contract |
| primary | [tasks/task0403-bingx-limit-time-in-force-contract.md](snapshots/primary/tasks/task0403-bingx-limit-time-in-force-contract.md) | TASK-0403 — BingX limit-order time-in-force contract |
| primary | [tasks/task0404-bingx-client-order-id-field.md](snapshots/primary/tasks/task0404-bingx-client-order-id-field.md) | TASK-0404 — BingX client-order-id request field |
| primary | [tasks/task0405-bingx-order-response-identity.md](snapshots/primary/tasks/task0405-bingx-order-response-identity.md) | TASK-0405 — BingX order-response identity |
| primary | [tasks/task0406-bingx-precision-safe-order-id.md](snapshots/primary/tasks/task0406-bingx-precision-safe-order-id.md) | TASK-0406 — BingX precision-safe order identity |
| primary | [tasks/task0407-bingx-adapter-retry-idempotency.md](snapshots/primary/tasks/task0407-bingx-adapter-retry-idempotency.md) | TASK-0407 — BingX adapter retry idempotency |
| primary | [tasks/task0408-bingx-missing-order-id-reconciliation.md](snapshots/primary/tasks/task0408-bingx-missing-order-id-reconciliation.md) | TASK-0408 — BingX missing-order-id reconciliation |
| primary | [tasks/task0409-bingx-limit-protection-contract.md](snapshots/primary/tasks/task0409-bingx-limit-protection-contract.md) | TASK-0409 — BingX LIMIT attached-protection contract |
| primary | [tasks/task0410-bingx-limit-protection-verification-gate.md](snapshots/primary/tasks/task0410-bingx-limit-protection-verification-gate.md) | TASK-0410 — BingX LIMIT protection verification gate |
| primary | [tasks/task0411-bingx-conditional-conflict-identity.md](snapshots/primary/tasks/task0411-bingx-conditional-conflict-identity.md) | TASK-0411 — BingX conditional-conflict identity |
| primary | [tasks/task0412-bingx-conditional-final-gate.md](snapshots/primary/tasks/task0412-bingx-conditional-final-gate.md) | TASK-0412 — BingX conditional final gate |
| primary | [tasks/task0413-bingx-blacklist-precedence.md](snapshots/primary/tasks/task0413-bingx-blacklist-precedence.md) | TASK-0413 — BingX blacklist precedence regression |
| primary | [tasks/task0414-bingx-vst-limit-protection-verification.md](snapshots/primary/tasks/task0414-bingx-vst-limit-protection-verification.md) | TASK-0414 — BingX VST LIMIT protection verification |
| primary | [tasks/task0415-c35-228-decision-checkpoint.md](snapshots/primary/tasks/task0415-c35-228-decision-checkpoint.md) | TASK-0415 — C-35 frozen checkpoint at 228 decisions |
| primary | [tasks/task0416-historical-provider-failure-cache-initialization.md](snapshots/primary/tasks/task0416-historical-provider-failure-cache-initialization.md) | TASK-0416 — Historical-provider failure-cache initialization |
| primary | [tasks/task0417-c35-230-decision-checkpoint.md](snapshots/primary/tasks/task0417-c35-230-decision-checkpoint.md) | TASK-0417 — C-35 frozen checkpoint at 230 decisions |
| primary | [tasks/task0418-automatic-forward-cohort-rotation.md](snapshots/primary/tasks/task0418-automatic-forward-cohort-rotation.md) | TASK-0418 — Automatic forward-cohort rotation |
| primary | [tasks/task0419-c35-231-decision-checkpoint.md](snapshots/primary/tasks/task0419-c35-231-decision-checkpoint.md) | TASK-0419 — C-35 frozen checkpoint at 231 decisions |
| primary | [tasks/task0420-c35-232-decision-checkpoint.md](snapshots/primary/tasks/task0420-c35-232-decision-checkpoint.md) | TASK-0420 — C-35 frozen checkpoint at 232 decisions |
| primary | [tasks/task0421-c11-refresh-c35-234-checkpoint.md](snapshots/primary/tasks/task0421-c11-refresh-c35-234-checkpoint.md) | TASK-0421 — C-11 due refresh and C-35 checkpoint at 234 decisions |
| primary | [tasks/task0422-c35-235-decision-checkpoint.md](snapshots/primary/tasks/task0422-c35-235-decision-checkpoint.md) | TASK-0422 — C-35 frozen checkpoint at 235 decisions |
| primary | [tasks/task0423-c35-236-decision-checkpoint.md](snapshots/primary/tasks/task0423-c35-236-decision-checkpoint.md) | TASK-0423 — C-35 frozen checkpoint at 236 decisions |
| primary | [tasks/task0424-c35-237-decision-checkpoint.md](snapshots/primary/tasks/task0424-c35-237-decision-checkpoint.md) | TASK-0424 — C-35 frozen checkpoint at 237 decisions |
| primary | [tasks/task0425-c35-238-decision-checkpoint.md](snapshots/primary/tasks/task0425-c35-238-decision-checkpoint.md) | TASK-0425 — C-35 frozen checkpoint at 238 decisions |
| primary | [tasks/task0426-c35-239-decision-checkpoint.md](snapshots/primary/tasks/task0426-c35-239-decision-checkpoint.md) | TASK-0426 — C-35 frozen checkpoint at 239 decisions |
| primary | [tasks/task0427-c35-240-decision-throughput-checkpoint.md](snapshots/primary/tasks/task0427-c35-240-decision-throughput-checkpoint.md) | TASK-0427 — C-35 throughput checkpoint at 240 decisions |
| primary | [tasks/task0428-c35-241-decision-checkpoint.md](snapshots/primary/tasks/task0428-c35-241-decision-checkpoint.md) | TASK-0428 — C-35 frozen checkpoint at 241 decisions |
| primary | [tasks/task0429-c35-242-decision-checkpoint.md](snapshots/primary/tasks/task0429-c35-242-decision-checkpoint.md) | TASK-0429 — C-35 frozen checkpoint at 242 decisions |
| primary | [tasks/task0430-c35-243-decision-checkpoint.md](snapshots/primary/tasks/task0430-c35-243-decision-checkpoint.md) | TASK-0430 — C-35 frozen checkpoint at 243 decisions |
| primary | [tasks/task0431-c35-244-decision-checkpoint.md](snapshots/primary/tasks/task0431-c35-244-decision-checkpoint.md) | TASK-0431 — C-35 frozen checkpoint at 244 decisions |
| primary | [tasks/task0432-string-symbol-execution-boundary.md](snapshots/primary/tasks/task0432-string-symbol-execution-boundary.md) | TASK-0432 — Raw string symbol execution-boundary robustness |
| primary | [tasks/task0433-c11-refresh-c35-248-checkpoint.md](snapshots/primary/tasks/task0433-c11-refresh-c35-248-checkpoint.md) | TASK-0433 — C-11 refresh and C-35 248-decision checkpoint |
| primary | [tasks/task0434-vst-exact-cap-float-drift.md](snapshots/primary/tasks/task0434-vst-exact-cap-float-drift.md) | TASK-0434 — VST exact-cap float-drift correction |
| primary | [tasks/task0435-c35-248-liveness-checkpoint.md](snapshots/primary/tasks/task0435-c35-248-liveness-checkpoint.md) | TASK-0435 — C-35 248-decision liveness checkpoint |
| primary | [tasks/task0436-bingx-leverage-rejection-diagnostics.md](snapshots/primary/tasks/task0436-bingx-leverage-rejection-diagnostics.md) | TASK-0436 — BingX margin/leverage rejection diagnostics |
| primary | [tasks/task0437-c35-249-decision-checkpoint.md](snapshots/primary/tasks/task0437-c35-249-decision-checkpoint.md) | TASK-0437 — C-35 frozen checkpoint at 249 decisions |
| primary | [tasks/task0438-unknown-exit-idempotency.md](snapshots/primary/tasks/task0438-unknown-exit-idempotency.md) | TASK-0438 — Independent unknown-exit reconciliation identity |
| primary | [tasks/task0439-c35-251-decision-checkpoint.md](snapshots/primary/tasks/task0439-c35-251-decision-checkpoint.md) | TASK-0439 — C-35 frozen checkpoint at 251 decisions |
| primary | [tasks/task0440-bingx-margin-write-short-circuit.md](snapshots/primary/tasks/task0440-bingx-margin-write-short-circuit.md) | TASK-0440 — BingX margin-write short circuit |
| primary | [tasks/task0441-c35-252-decision-checkpoint.md](snapshots/primary/tasks/task0441-c35-252-decision-checkpoint.md) | TASK-0441 — C-35 frozen checkpoint at 252 decisions |
| primary | [tasks/task0442-unverified-price-fail-closed.md](snapshots/primary/tasks/task0442-unverified-price-fail-closed.md) | TASK-0442 — Fail closed without a verified execution price |
| primary | [tasks/task0443-c35-255-decision-checkpoint.md](snapshots/primary/tasks/task0443-c35-255-decision-checkpoint.md) | TASK-0443 — C-35 frozen checkpoint at 255 decisions |
| primary | [tasks/task0444-telegram-config-fail-fast.md](snapshots/primary/tasks/task0444-telegram-config-fail-fast.md) | TASK-0444 — Telegram configuration fail-fast and HTML subject safety |
| primary | [tasks/task0445-c11-refresh-c35-256-checkpoint.md](snapshots/primary/tasks/task0445-c11-refresh-c35-256-checkpoint.md) | TASK-0445 — C-11 refresh and C-35 256-decision checkpoint |
| primary | [tasks/task0446-reconciliation-symbol-identity.md](snapshots/primary/tasks/task0446-reconciliation-symbol-identity.md) | TASK-0446 — Reconciliation terminal-order symbol identity |
| primary | [tasks/task0447-c35-257-decision-checkpoint.md](snapshots/primary/tasks/task0447-c35-257-decision-checkpoint.md) | TASK-0447 — C-35 frozen checkpoint at 257 decisions |
| primary | [tasks/task0448-filled-exit-evidence-only.md](snapshots/primary/tasks/task0448-filled-exit-evidence-only.md) | TASK-0448 — Filled-only position-closure evidence |
| primary | [tasks/task0449-c35-258-decision-checkpoint.md](snapshots/primary/tasks/task0449-c35-258-decision-checkpoint.md) | TASK-0449 — C-35 frozen checkpoint at 258 decisions |
| primary | [tasks/task0450-telegram-credential-removal.md](snapshots/primary/tasks/task0450-telegram-credential-removal.md) | TASK-0450 — Remove Embedded Telegram Credential |
| primary | [tasks/task0451-c35-259-decision-checkpoint.md](snapshots/primary/tasks/task0451-c35-259-decision-checkpoint.md) | TASK-0451 — C-35 frozen checkpoint at 259 decisions |
| primary | [tasks/task0452-c35-260-decision-checkpoint.md](snapshots/primary/tasks/task0452-c35-260-decision-checkpoint.md) | TASK-0452 — C-35 frozen checkpoint at 260 decisions |
| primary | [tasks/task0453-c35-c11-refresh-c33-recovery.md](snapshots/primary/tasks/task0453-c35-c11-refresh-c33-recovery.md) | TASK-0453 — Frozen cohort refresh and C-33 collector recovery |
| primary | [tasks/task0454-phase3a-input-audit.md](snapshots/primary/tasks/task0454-phase3a-input-audit.md) | TASK-0454 — Phase 3A input and identifiability audit |
| primary | [tasks/task0455-c35-284-decision-checkpoint.md](snapshots/primary/tasks/task0455-c35-284-decision-checkpoint.md) | TASK-0455 — C-35 frozen checkpoint at 284 decisions |
| primary | [tasks/task0456-phase3a-source-reconciliation.md](snapshots/primary/tasks/task0456-phase3a-source-reconciliation.md) | TASK-0456 — Phase 3A source reconciliation |
| primary | [tasks/task0457-phase3a-close-and-cohort-refresh.md](snapshots/primary/tasks/task0457-phase3a-close-and-cohort-refresh.md) | TASK-0457 — Phase 3A closure and frozen-cohort refresh |
| primary | [tasks/trade_features-task.md](snapshots/primary/tasks/trade_features-task.md) | TASK: Persistent Trade Research Dataset / Background Trade Feature Collector |
